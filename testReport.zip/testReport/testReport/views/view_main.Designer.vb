﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TestReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.swProject = New System.Windows.Forms.ComboBox()
        Me.releaseDate = New System.Windows.Forms.DateTimePicker()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.modifiedBy = New System.Windows.Forms.TextBox()
        Me.documentOwner = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.endDate = New System.Windows.Forms.DateTimePicker()
        Me.startDate = New System.Windows.Forms.DateTimePicker()
        Me.testCoordinator = New System.Windows.Forms.ComboBox()
        Me.levelOfTesting = New System.Windows.Forms.ComboBox()
        Me.documentVersion = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.swVersion = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.swRelease = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.swVariant = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.swSRCheck = New System.Windows.Forms.CheckBox()
        Me.swRDP = New System.Windows.Forms.CheckBox()
        Me.swSIT = New System.Windows.Forms.CheckBox()
        Me.swHMA = New System.Windows.Forms.CheckBox()
        Me.swVehicle = New System.Windows.Forms.CheckBox()
        Me.swELK = New System.Windows.Forms.CheckBox()
        Me.swTJA = New System.Windows.Forms.CheckBox()
        Me.swLDW = New System.Windows.Forms.CheckBox()
        Me.swSLA = New System.Windows.Forms.CheckBox()
        Me.swLKS = New System.Windows.Forms.CheckBox()
        Me.swCOM = New System.Windows.Forms.CheckBox()
        Me.swEM = New System.Windows.Forms.CheckBox()
        Me.swDCOM = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.swCoresi = New System.Windows.Forms.RichTextBox()
        Me.swSource = New System.Windows.Forms.RichTextBox()
        Me.swDelivery = New System.Windows.Forms.RichTextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ouputReportLocation = New System.Windows.Forms.TextBox()
        Me.terminal = New System.Windows.Forms.RichTextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.optionDCOMDelta = New System.Windows.Forms.CheckBox()
        Me.optionDCOMRegression = New System.Windows.Forms.CheckBox()
        Me.optionDCOMFull = New System.Windows.Forms.CheckBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.optionEMDelta = New System.Windows.Forms.CheckBox()
        Me.optionEMRegression = New System.Windows.Forms.CheckBox()
        Me.optionEMFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.optionCOMDelta = New System.Windows.Forms.CheckBox()
        Me.optionCOMRegression = New System.Windows.Forms.CheckBox()
        Me.optionCOMFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.optionLDWDelta = New System.Windows.Forms.CheckBox()
        Me.optionLDWRegression = New System.Windows.Forms.CheckBox()
        Me.optionLDWFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.optionLKSDelta = New System.Windows.Forms.CheckBox()
        Me.optionLKSRegression = New System.Windows.Forms.CheckBox()
        Me.optionLKSFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.optionRDPDelta = New System.Windows.Forms.CheckBox()
        Me.optionRDPRegression = New System.Windows.Forms.CheckBox()
        Me.optionRDPFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.optionELKDelta = New System.Windows.Forms.CheckBox()
        Me.optionELKRegression = New System.Windows.Forms.CheckBox()
        Me.optionELKFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.optionTJADelta = New System.Windows.Forms.CheckBox()
        Me.optionTJARegression = New System.Windows.Forms.CheckBox()
        Me.optionTJAFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox21 = New System.Windows.Forms.CheckBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.optionSLADelta = New System.Windows.Forms.CheckBox()
        Me.optionSLARegression = New System.Windows.Forms.CheckBox()
        Me.optionSLAFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox22 = New System.Windows.Forms.CheckBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.optionHMADelta = New System.Windows.Forms.CheckBox()
        Me.optionHMARegression = New System.Windows.Forms.CheckBox()
        Me.optionHMAFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox23 = New System.Windows.Forms.CheckBox()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Panel38 = New System.Windows.Forms.Panel()
        Me.optionVehicleDelta = New System.Windows.Forms.CheckBox()
        Me.optionVehicleRegression = New System.Windows.Forms.CheckBox()
        Me.optionVehicleFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox24 = New System.Windows.Forms.CheckBox()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Panel39 = New System.Windows.Forms.Panel()
        Me.optionSITDelta = New System.Windows.Forms.CheckBox()
        Me.optionSITRegression = New System.Windows.Forms.CheckBox()
        Me.optionSITFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox25 = New System.Windows.Forms.CheckBox()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.optionSRCheckDelta = New System.Windows.Forms.CheckBox()
        Me.optionSRCheckRegression = New System.Windows.Forms.CheckBox()
        Me.optionSRCheckFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox26 = New System.Windows.Forms.CheckBox()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.optionLabTDCOM = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateDCOMFull = New System.Windows.Forms.ComboBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.optionDefectIdDCOMFull = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.optionDefectKindDCOMFull = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.optionPtIdDCOMFull = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.optionFailedDCOMFull = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.optionPassedDCOMFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateDCOMFull = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.optionVersionDCOMFull = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateDCOMRegression = New System.Windows.Forms.ComboBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.optionDefectIdDCOMRegression = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.optionDefectKindDCOMRegression = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.optionPtIdDCOMRegression = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.optionFailedDCOMRegression = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.optionPassedDCOMRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateDCOMRegression = New System.Windows.Forms.ComboBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.optionVersionDCOMRegression = New System.Windows.Forms.ComboBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateDCOMDelta = New System.Windows.Forms.ComboBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.optionDefectIdDCOMDelta = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.optionDefectKindDCOMDelta = New System.Windows.Forms.ComboBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.optionPtIdDCOMDelta = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.optionFailedDCOMDelta = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.optionPassedDCOMDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateDCOMDelta = New System.Windows.Forms.ComboBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.optionVersionDCOMDelta = New System.Windows.Forms.ComboBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.optionLabTEM = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateEMFull = New System.Windows.Forms.ComboBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.optionDefectIdEMFull = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.optionDefectKindEMFull = New System.Windows.Forms.ComboBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.optionPtIdEMFull = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.optionFailedEMFull = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.optionPassedEMFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateEMFull = New System.Windows.Forms.ComboBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.optionVersionEMFull = New System.Windows.Forms.ComboBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.TabPage17 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateEMRegression = New System.Windows.Forms.ComboBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.optionDefectIdEMRegression = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.optionDefectKindEMRegression = New System.Windows.Forms.ComboBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.optionPtIdEMRegression = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.optionFailedEMRegression = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.optionPassedEMRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateEMRegression = New System.Windows.Forms.ComboBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.optionVersionEMRegression = New System.Windows.Forms.ComboBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.TabPage18 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateEMDelta = New System.Windows.Forms.ComboBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.optionDefectIdEMDelta = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.optionDefectKindEMDelta = New System.Windows.Forms.ComboBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.optionPtIdEMDelta = New System.Windows.Forms.TextBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.optionFailedEMDelta = New System.Windows.Forms.TextBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.optionPassedEMDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateEMDelta = New System.Windows.Forms.ComboBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.optionVersionEMDelta = New System.Windows.Forms.ComboBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.optionLabTCOM = New System.Windows.Forms.TextBox()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.TabControl4 = New System.Windows.Forms.TabControl()
        Me.TabPage19 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateCOMFull = New System.Windows.Forms.ComboBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.optionDefectIdCOMFull = New System.Windows.Forms.TextBox()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.optionDefectKindCOMFull = New System.Windows.Forms.ComboBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.optionPtIdCOMFull = New System.Windows.Forms.TextBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.optionFailedCOMFull = New System.Windows.Forms.TextBox()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.optionPassedCOMFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateCOMFull = New System.Windows.Forms.ComboBox()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.optionVersionCOMFull = New System.Windows.Forms.ComboBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.TabPage20 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateCOMRegression = New System.Windows.Forms.ComboBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.optionDefectIdCOMRegression = New System.Windows.Forms.TextBox()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.optionDefectKindCOMRegression = New System.Windows.Forms.ComboBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.optionPtIdCOMRegression = New System.Windows.Forms.TextBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.optionFailedCOMRegression = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.optionPassedCOMRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateCOMRegression = New System.Windows.Forms.ComboBox()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.optionVersionCOMRegression = New System.Windows.Forms.ComboBox()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.TabPage21 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateCOMDelta = New System.Windows.Forms.ComboBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.optionDefectIdCOMDelta = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.optionDefectKindCOMDelta = New System.Windows.Forms.ComboBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.optionPtIdCOMDelta = New System.Windows.Forms.TextBox()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.optionFailedCOMDelta = New System.Windows.Forms.TextBox()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.optionPassedCOMDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateCOMDelta = New System.Windows.Forms.ComboBox()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.optionVersionCOMDelta = New System.Windows.Forms.ComboBox()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.optionLabTLDW = New System.Windows.Forms.TextBox()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.TabControl5 = New System.Windows.Forms.TabControl()
        Me.TabPage22 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateLDWFull = New System.Windows.Forms.ComboBox()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.optionDefectIdLDWFull = New System.Windows.Forms.TextBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.optionDefectKindLDWFull = New System.Windows.Forms.ComboBox()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.optionPtIdLDWFull = New System.Windows.Forms.TextBox()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.optionFailedLDWFull = New System.Windows.Forms.TextBox()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.optionPassedLDWFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateLDWFull = New System.Windows.Forms.ComboBox()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.optionVersionLDWFull = New System.Windows.Forms.ComboBox()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.TabPage23 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateLDWRegression = New System.Windows.Forms.ComboBox()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.optionDefectIdLDWRegression = New System.Windows.Forms.TextBox()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.optionDefectKindLDWRegression = New System.Windows.Forms.ComboBox()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.optionPtIdLDWRegression = New System.Windows.Forms.TextBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.optionFailedLDWRegression = New System.Windows.Forms.TextBox()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.optionPassedLDWRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateLDWRegression = New System.Windows.Forms.ComboBox()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.optionVersionLDWRegression = New System.Windows.Forms.ComboBox()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.TabPage24 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateLDWDelta = New System.Windows.Forms.ComboBox()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.optionDefectIdLDWDelta = New System.Windows.Forms.TextBox()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.optionDefectKindLDWDelta = New System.Windows.Forms.ComboBox()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.optionPtIdLDWDelta = New System.Windows.Forms.TextBox()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.optionFailedLDWDelta = New System.Windows.Forms.TextBox()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.optionPassedLDWDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateLDWDelta = New System.Windows.Forms.ComboBox()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.optionVersionLDWDelta = New System.Windows.Forms.ComboBox()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.optionLabTLKS = New System.Windows.Forms.TextBox()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.TabControl6 = New System.Windows.Forms.TabControl()
        Me.TabPage25 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateLKSFull = New System.Windows.Forms.ComboBox()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.optionDefectIdLKSFull = New System.Windows.Forms.TextBox()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.optionDefectKindLKSFull = New System.Windows.Forms.ComboBox()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.optionPtIdLKSFull = New System.Windows.Forms.TextBox()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.optionFailedLKSFull = New System.Windows.Forms.TextBox()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.optionPassedLKSFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateLKSFull = New System.Windows.Forms.ComboBox()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.optionVersionLKSFull = New System.Windows.Forms.ComboBox()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.TabPage26 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateLKSRegression = New System.Windows.Forms.ComboBox()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.optionDefectIdLKSRegression = New System.Windows.Forms.TextBox()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.optionDefectKindLKSRegression = New System.Windows.Forms.ComboBox()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.optionPtIdLKSRegression = New System.Windows.Forms.TextBox()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.optionFailedLKSRegression = New System.Windows.Forms.TextBox()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.optionPassedLKSRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateLKSRegression = New System.Windows.Forms.ComboBox()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.optionVersionLKSRegression = New System.Windows.Forms.ComboBox()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.TabPage27 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateLKSDelta = New System.Windows.Forms.ComboBox()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.optionDefectIdLKSDelta = New System.Windows.Forms.TextBox()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.optionDefectKindLKSDelta = New System.Windows.Forms.ComboBox()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.optionPtIdLKSDelta = New System.Windows.Forms.TextBox()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.optionFailedLKSDelta = New System.Windows.Forms.TextBox()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.optionPassedLKSDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateLKSDelta = New System.Windows.Forms.ComboBox()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.optionVersionLKSDelta = New System.Windows.Forms.ComboBox()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.optionLabTRDP = New System.Windows.Forms.TextBox()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.TabControl7 = New System.Windows.Forms.TabControl()
        Me.TabPage28 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateRDPFull = New System.Windows.Forms.ComboBox()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.optionDefectIdRDPFull = New System.Windows.Forms.TextBox()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.optionDefectKindRDPFull = New System.Windows.Forms.ComboBox()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.optionPtIdRDPFull = New System.Windows.Forms.TextBox()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.optionFailedRDPFull = New System.Windows.Forms.TextBox()
        Me.Label148 = New System.Windows.Forms.Label()
        Me.optionPassedRDPFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateRDPFull = New System.Windows.Forms.ComboBox()
        Me.Label150 = New System.Windows.Forms.Label()
        Me.optionVersionRDPFull = New System.Windows.Forms.ComboBox()
        Me.Label151 = New System.Windows.Forms.Label()
        Me.TabPage29 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateRDPRegression = New System.Windows.Forms.ComboBox()
        Me.Label152 = New System.Windows.Forms.Label()
        Me.Label153 = New System.Windows.Forms.Label()
        Me.optionDefectIdRDPRegression = New System.Windows.Forms.TextBox()
        Me.Label154 = New System.Windows.Forms.Label()
        Me.optionDefectKindRDPRegression = New System.Windows.Forms.ComboBox()
        Me.Label155 = New System.Windows.Forms.Label()
        Me.optionPtIdRDPRegression = New System.Windows.Forms.TextBox()
        Me.Label156 = New System.Windows.Forms.Label()
        Me.optionFailedRDPRegression = New System.Windows.Forms.TextBox()
        Me.Label157 = New System.Windows.Forms.Label()
        Me.optionPassedRDPRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateRDPRegression = New System.Windows.Forms.ComboBox()
        Me.Label158 = New System.Windows.Forms.Label()
        Me.optionVersionRDPRegression = New System.Windows.Forms.ComboBox()
        Me.Label159 = New System.Windows.Forms.Label()
        Me.TabPage30 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateRDPDelta = New System.Windows.Forms.ComboBox()
        Me.Label160 = New System.Windows.Forms.Label()
        Me.Label161 = New System.Windows.Forms.Label()
        Me.optionDefectIdRDPDelta = New System.Windows.Forms.TextBox()
        Me.Label162 = New System.Windows.Forms.Label()
        Me.optionDefectKindRDPDelta = New System.Windows.Forms.ComboBox()
        Me.Label163 = New System.Windows.Forms.Label()
        Me.optionPtIdRDPDelta = New System.Windows.Forms.TextBox()
        Me.Label164 = New System.Windows.Forms.Label()
        Me.optionFailedRDPDelta = New System.Windows.Forms.TextBox()
        Me.Label165 = New System.Windows.Forms.Label()
        Me.optionPassedRDPDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateRDPDelta = New System.Windows.Forms.ComboBox()
        Me.Label166 = New System.Windows.Forms.Label()
        Me.optionVersionRDPDelta = New System.Windows.Forms.ComboBox()
        Me.Label167 = New System.Windows.Forms.Label()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.optionLabTELK = New System.Windows.Forms.TextBox()
        Me.Label149 = New System.Windows.Forms.Label()
        Me.TabControl8 = New System.Windows.Forms.TabControl()
        Me.TabPage31 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateELKFull = New System.Windows.Forms.ComboBox()
        Me.Label168 = New System.Windows.Forms.Label()
        Me.Label169 = New System.Windows.Forms.Label()
        Me.optionDefectIdELKFull = New System.Windows.Forms.TextBox()
        Me.Label170 = New System.Windows.Forms.Label()
        Me.optionDefectKindELKFull = New System.Windows.Forms.ComboBox()
        Me.Label171 = New System.Windows.Forms.Label()
        Me.optionPtIdELKFull = New System.Windows.Forms.TextBox()
        Me.Label172 = New System.Windows.Forms.Label()
        Me.optionFailedELKFull = New System.Windows.Forms.TextBox()
        Me.Label173 = New System.Windows.Forms.Label()
        Me.optionPassedELKFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateELKFull = New System.Windows.Forms.ComboBox()
        Me.Label174 = New System.Windows.Forms.Label()
        Me.optionVersionELKFull = New System.Windows.Forms.ComboBox()
        Me.Label175 = New System.Windows.Forms.Label()
        Me.TabPage32 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateELKRegression = New System.Windows.Forms.ComboBox()
        Me.Label176 = New System.Windows.Forms.Label()
        Me.Label177 = New System.Windows.Forms.Label()
        Me.optionDefectIdELKRegression = New System.Windows.Forms.TextBox()
        Me.Label178 = New System.Windows.Forms.Label()
        Me.optionDefectKindELKRegression = New System.Windows.Forms.ComboBox()
        Me.Label179 = New System.Windows.Forms.Label()
        Me.optionPtIdELKRegression = New System.Windows.Forms.TextBox()
        Me.Label180 = New System.Windows.Forms.Label()
        Me.optionFailedELKRegression = New System.Windows.Forms.TextBox()
        Me.Label181 = New System.Windows.Forms.Label()
        Me.optionPassedELKRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateELKRegression = New System.Windows.Forms.ComboBox()
        Me.Label182 = New System.Windows.Forms.Label()
        Me.optionVersionELKRegression = New System.Windows.Forms.ComboBox()
        Me.Label183 = New System.Windows.Forms.Label()
        Me.TabPage33 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateELKDelta = New System.Windows.Forms.ComboBox()
        Me.Label184 = New System.Windows.Forms.Label()
        Me.Label185 = New System.Windows.Forms.Label()
        Me.optionDefectIdELKDelta = New System.Windows.Forms.TextBox()
        Me.Label186 = New System.Windows.Forms.Label()
        Me.optionDefectKindELKDelta = New System.Windows.Forms.ComboBox()
        Me.Label187 = New System.Windows.Forms.Label()
        Me.optionPtIdELKDelta = New System.Windows.Forms.TextBox()
        Me.Label188 = New System.Windows.Forms.Label()
        Me.optionFailedELKDelta = New System.Windows.Forms.TextBox()
        Me.Label189 = New System.Windows.Forms.Label()
        Me.optionPassedELKDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateELKDelta = New System.Windows.Forms.ComboBox()
        Me.Label190 = New System.Windows.Forms.Label()
        Me.optionVersionELKDelta = New System.Windows.Forms.ComboBox()
        Me.Label191 = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.optionLabTTJA = New System.Windows.Forms.TextBox()
        Me.Label192 = New System.Windows.Forms.Label()
        Me.TabControl9 = New System.Windows.Forms.TabControl()
        Me.TabPage34 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateTJAFull = New System.Windows.Forms.ComboBox()
        Me.Label193 = New System.Windows.Forms.Label()
        Me.Label194 = New System.Windows.Forms.Label()
        Me.optionDefectIdTJAFull = New System.Windows.Forms.TextBox()
        Me.Label195 = New System.Windows.Forms.Label()
        Me.optionDefectKindTJAFull = New System.Windows.Forms.ComboBox()
        Me.Label196 = New System.Windows.Forms.Label()
        Me.optionPtIdTJAFull = New System.Windows.Forms.TextBox()
        Me.Label197 = New System.Windows.Forms.Label()
        Me.optionFailedTJAFull = New System.Windows.Forms.TextBox()
        Me.Label198 = New System.Windows.Forms.Label()
        Me.optionPassedTJAFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateTJAFull = New System.Windows.Forms.ComboBox()
        Me.Label199 = New System.Windows.Forms.Label()
        Me.optionVersionTJAFull = New System.Windows.Forms.ComboBox()
        Me.Label200 = New System.Windows.Forms.Label()
        Me.TabPage35 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateTJARegression = New System.Windows.Forms.ComboBox()
        Me.Label201 = New System.Windows.Forms.Label()
        Me.Label202 = New System.Windows.Forms.Label()
        Me.optionDefectIdTJARegression = New System.Windows.Forms.TextBox()
        Me.Label203 = New System.Windows.Forms.Label()
        Me.optionDefectKindTJARegression = New System.Windows.Forms.ComboBox()
        Me.Label204 = New System.Windows.Forms.Label()
        Me.optionPtIdTJARegression = New System.Windows.Forms.TextBox()
        Me.Label205 = New System.Windows.Forms.Label()
        Me.optionFailedTJARegression = New System.Windows.Forms.TextBox()
        Me.Label206 = New System.Windows.Forms.Label()
        Me.optionPassedTJARegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateTJARegression = New System.Windows.Forms.ComboBox()
        Me.Label207 = New System.Windows.Forms.Label()
        Me.optionVersionTJARegression = New System.Windows.Forms.ComboBox()
        Me.Label208 = New System.Windows.Forms.Label()
        Me.TabPage36 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateTJADelta = New System.Windows.Forms.ComboBox()
        Me.Label209 = New System.Windows.Forms.Label()
        Me.Label210 = New System.Windows.Forms.Label()
        Me.optionDefectIdTJADelta = New System.Windows.Forms.TextBox()
        Me.Label211 = New System.Windows.Forms.Label()
        Me.optionDefectKindTJADelta = New System.Windows.Forms.ComboBox()
        Me.Label212 = New System.Windows.Forms.Label()
        Me.optionPtIdTJADelta = New System.Windows.Forms.TextBox()
        Me.Label213 = New System.Windows.Forms.Label()
        Me.optionFailedTJADelta = New System.Windows.Forms.TextBox()
        Me.Label214 = New System.Windows.Forms.Label()
        Me.optionPassedTJADelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateTJADelta = New System.Windows.Forms.ComboBox()
        Me.Label215 = New System.Windows.Forms.Label()
        Me.optionVersionTJADelta = New System.Windows.Forms.ComboBox()
        Me.Label216 = New System.Windows.Forms.Label()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.optionLabTSLA = New System.Windows.Forms.TextBox()
        Me.Label217 = New System.Windows.Forms.Label()
        Me.TabControl10 = New System.Windows.Forms.TabControl()
        Me.TabPage37 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSLAFull = New System.Windows.Forms.ComboBox()
        Me.Label218 = New System.Windows.Forms.Label()
        Me.Label219 = New System.Windows.Forms.Label()
        Me.optionDefectIdSLAFull = New System.Windows.Forms.TextBox()
        Me.Label220 = New System.Windows.Forms.Label()
        Me.optionDefectKindSLAFull = New System.Windows.Forms.ComboBox()
        Me.Label221 = New System.Windows.Forms.Label()
        Me.optionPtIdSLAFull = New System.Windows.Forms.TextBox()
        Me.Label222 = New System.Windows.Forms.Label()
        Me.optionFailedSLAFull = New System.Windows.Forms.TextBox()
        Me.Label223 = New System.Windows.Forms.Label()
        Me.optionPassedSLAFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateSLAFull = New System.Windows.Forms.ComboBox()
        Me.Label224 = New System.Windows.Forms.Label()
        Me.optionVersionSLAFull = New System.Windows.Forms.ComboBox()
        Me.Label225 = New System.Windows.Forms.Label()
        Me.TabPage38 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSLARegression = New System.Windows.Forms.ComboBox()
        Me.Label226 = New System.Windows.Forms.Label()
        Me.Label227 = New System.Windows.Forms.Label()
        Me.optionDefectIdSLARegression = New System.Windows.Forms.TextBox()
        Me.Label228 = New System.Windows.Forms.Label()
        Me.optionDefectKindSLARegression = New System.Windows.Forms.ComboBox()
        Me.Label229 = New System.Windows.Forms.Label()
        Me.optionPtIdSLARegression = New System.Windows.Forms.TextBox()
        Me.Label230 = New System.Windows.Forms.Label()
        Me.optionFailedSLARegression = New System.Windows.Forms.TextBox()
        Me.Label231 = New System.Windows.Forms.Label()
        Me.optionPassedSLARegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateSLARegression = New System.Windows.Forms.ComboBox()
        Me.Label232 = New System.Windows.Forms.Label()
        Me.optionVersionSLARegression = New System.Windows.Forms.ComboBox()
        Me.Label233 = New System.Windows.Forms.Label()
        Me.TabPage39 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSLADelta = New System.Windows.Forms.ComboBox()
        Me.Label234 = New System.Windows.Forms.Label()
        Me.Label235 = New System.Windows.Forms.Label()
        Me.optionDefectIdSLADelta = New System.Windows.Forms.TextBox()
        Me.Label236 = New System.Windows.Forms.Label()
        Me.optionDefectKindSLADelta = New System.Windows.Forms.ComboBox()
        Me.Label237 = New System.Windows.Forms.Label()
        Me.optionPtIdSLADelta = New System.Windows.Forms.TextBox()
        Me.Label238 = New System.Windows.Forms.Label()
        Me.optionFailedSLADelta = New System.Windows.Forms.TextBox()
        Me.Label239 = New System.Windows.Forms.Label()
        Me.optionPassedSLADelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateSLADelta = New System.Windows.Forms.ComboBox()
        Me.Label240 = New System.Windows.Forms.Label()
        Me.optionVersionSLADelta = New System.Windows.Forms.ComboBox()
        Me.Label241 = New System.Windows.Forms.Label()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.optionLabTHMA = New System.Windows.Forms.TextBox()
        Me.Label242 = New System.Windows.Forms.Label()
        Me.TabControl11 = New System.Windows.Forms.TabControl()
        Me.TabPage40 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateHMAFull = New System.Windows.Forms.ComboBox()
        Me.Label243 = New System.Windows.Forms.Label()
        Me.Label244 = New System.Windows.Forms.Label()
        Me.optionDefectIdHMAFull = New System.Windows.Forms.TextBox()
        Me.Label245 = New System.Windows.Forms.Label()
        Me.optionDefectKindHMAFull = New System.Windows.Forms.ComboBox()
        Me.Label246 = New System.Windows.Forms.Label()
        Me.optionPtIdHMAFull = New System.Windows.Forms.TextBox()
        Me.Label247 = New System.Windows.Forms.Label()
        Me.optionFailedHMAFull = New System.Windows.Forms.TextBox()
        Me.Label248 = New System.Windows.Forms.Label()
        Me.optionPassedHMAFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateHMAFull = New System.Windows.Forms.ComboBox()
        Me.Label249 = New System.Windows.Forms.Label()
        Me.optionVersionHMAFull = New System.Windows.Forms.ComboBox()
        Me.Label250 = New System.Windows.Forms.Label()
        Me.TabPage41 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateHMARegression = New System.Windows.Forms.ComboBox()
        Me.Label251 = New System.Windows.Forms.Label()
        Me.Label252 = New System.Windows.Forms.Label()
        Me.optionDefectIdHMARegression = New System.Windows.Forms.TextBox()
        Me.Label253 = New System.Windows.Forms.Label()
        Me.optionDefectKindHMARegression = New System.Windows.Forms.ComboBox()
        Me.Label254 = New System.Windows.Forms.Label()
        Me.optionPtIdHMARegression = New System.Windows.Forms.TextBox()
        Me.Label255 = New System.Windows.Forms.Label()
        Me.optionFailedHMARegression = New System.Windows.Forms.TextBox()
        Me.Label256 = New System.Windows.Forms.Label()
        Me.optionPassedHMARegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateHMARegression = New System.Windows.Forms.ComboBox()
        Me.Label257 = New System.Windows.Forms.Label()
        Me.optionVersionHMARegression = New System.Windows.Forms.ComboBox()
        Me.Label258 = New System.Windows.Forms.Label()
        Me.TabPage42 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateHMADelta = New System.Windows.Forms.ComboBox()
        Me.Label259 = New System.Windows.Forms.Label()
        Me.Label260 = New System.Windows.Forms.Label()
        Me.optionDefectIdHMADelta = New System.Windows.Forms.TextBox()
        Me.Label261 = New System.Windows.Forms.Label()
        Me.optionDefectKindHMADelta = New System.Windows.Forms.ComboBox()
        Me.Label262 = New System.Windows.Forms.Label()
        Me.optionPtIdHMADelta = New System.Windows.Forms.TextBox()
        Me.Label263 = New System.Windows.Forms.Label()
        Me.optionFailedHMADelta = New System.Windows.Forms.TextBox()
        Me.Label264 = New System.Windows.Forms.Label()
        Me.optionPassedHMADelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateHMADelta = New System.Windows.Forms.ComboBox()
        Me.Label265 = New System.Windows.Forms.Label()
        Me.optionVersionHMADelta = New System.Windows.Forms.ComboBox()
        Me.Label266 = New System.Windows.Forms.Label()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.optionLabTVehicle = New System.Windows.Forms.TextBox()
        Me.Label267 = New System.Windows.Forms.Label()
        Me.TabControl12 = New System.Windows.Forms.TabControl()
        Me.TabPage43 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateVehicleFull = New System.Windows.Forms.ComboBox()
        Me.Label268 = New System.Windows.Forms.Label()
        Me.Label269 = New System.Windows.Forms.Label()
        Me.optionDefectIdVehicleFull = New System.Windows.Forms.TextBox()
        Me.Label270 = New System.Windows.Forms.Label()
        Me.optionDefectKindVehicleFull = New System.Windows.Forms.ComboBox()
        Me.Label271 = New System.Windows.Forms.Label()
        Me.optionPtIdVehicleFull = New System.Windows.Forms.TextBox()
        Me.Label272 = New System.Windows.Forms.Label()
        Me.optionFailedVehicleFull = New System.Windows.Forms.TextBox()
        Me.Label273 = New System.Windows.Forms.Label()
        Me.optionPassedVehicleFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateVehicleFull = New System.Windows.Forms.ComboBox()
        Me.Label274 = New System.Windows.Forms.Label()
        Me.optionVersionVehicleFull = New System.Windows.Forms.ComboBox()
        Me.Label275 = New System.Windows.Forms.Label()
        Me.TabPage44 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateVehicleRegression = New System.Windows.Forms.ComboBox()
        Me.Label276 = New System.Windows.Forms.Label()
        Me.Label277 = New System.Windows.Forms.Label()
        Me.optionDefectIdVehicleRegression = New System.Windows.Forms.TextBox()
        Me.Label278 = New System.Windows.Forms.Label()
        Me.optionDefectKindVehicleRegression = New System.Windows.Forms.ComboBox()
        Me.Label279 = New System.Windows.Forms.Label()
        Me.optionPtIdVehicleRegression = New System.Windows.Forms.TextBox()
        Me.Label280 = New System.Windows.Forms.Label()
        Me.optionFailedVehicleRegression = New System.Windows.Forms.TextBox()
        Me.Label281 = New System.Windows.Forms.Label()
        Me.optionPassedVehicleRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateVehicleRegression = New System.Windows.Forms.ComboBox()
        Me.Label282 = New System.Windows.Forms.Label()
        Me.optionVersionVehicleRegression = New System.Windows.Forms.ComboBox()
        Me.Label283 = New System.Windows.Forms.Label()
        Me.TabPage45 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateVehicleDelta = New System.Windows.Forms.ComboBox()
        Me.Label284 = New System.Windows.Forms.Label()
        Me.Label285 = New System.Windows.Forms.Label()
        Me.optionDefectIdVehicleDelta = New System.Windows.Forms.TextBox()
        Me.Label286 = New System.Windows.Forms.Label()
        Me.optionDefectKindVehicleDelta = New System.Windows.Forms.ComboBox()
        Me.Label287 = New System.Windows.Forms.Label()
        Me.optionPtIdVehicleDelta = New System.Windows.Forms.TextBox()
        Me.Label288 = New System.Windows.Forms.Label()
        Me.optionFailedVehicleDelta = New System.Windows.Forms.TextBox()
        Me.Label289 = New System.Windows.Forms.Label()
        Me.optionPassedVehicleDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateVehicleDelta = New System.Windows.Forms.ComboBox()
        Me.Label290 = New System.Windows.Forms.Label()
        Me.optionVersionVehicleDelta = New System.Windows.Forms.ComboBox()
        Me.Label291 = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.optionLabTSIT = New System.Windows.Forms.TextBox()
        Me.Label292 = New System.Windows.Forms.Label()
        Me.TabControl13 = New System.Windows.Forms.TabControl()
        Me.TabPage46 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSITFull = New System.Windows.Forms.ComboBox()
        Me.Label293 = New System.Windows.Forms.Label()
        Me.Label294 = New System.Windows.Forms.Label()
        Me.optionDefectIdSITFull = New System.Windows.Forms.TextBox()
        Me.Label295 = New System.Windows.Forms.Label()
        Me.optionDefectKindSITFull = New System.Windows.Forms.ComboBox()
        Me.Label296 = New System.Windows.Forms.Label()
        Me.optionPtIdSITFull = New System.Windows.Forms.TextBox()
        Me.Label297 = New System.Windows.Forms.Label()
        Me.optionFailedSITFull = New System.Windows.Forms.TextBox()
        Me.Label298 = New System.Windows.Forms.Label()
        Me.optionPassedSITFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateSITFull = New System.Windows.Forms.ComboBox()
        Me.Label299 = New System.Windows.Forms.Label()
        Me.optionVersionSITFull = New System.Windows.Forms.ComboBox()
        Me.Label300 = New System.Windows.Forms.Label()
        Me.TabPage47 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSITRegression = New System.Windows.Forms.ComboBox()
        Me.Label301 = New System.Windows.Forms.Label()
        Me.Label302 = New System.Windows.Forms.Label()
        Me.optionDefectIdSITRegression = New System.Windows.Forms.TextBox()
        Me.Label303 = New System.Windows.Forms.Label()
        Me.optionDefectKindSITRegression = New System.Windows.Forms.ComboBox()
        Me.Label304 = New System.Windows.Forms.Label()
        Me.optionPtIdSITRegression = New System.Windows.Forms.TextBox()
        Me.Label305 = New System.Windows.Forms.Label()
        Me.optionFailedSITRegression = New System.Windows.Forms.TextBox()
        Me.Label306 = New System.Windows.Forms.Label()
        Me.optionPassedSITRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateSITRegression = New System.Windows.Forms.ComboBox()
        Me.Label307 = New System.Windows.Forms.Label()
        Me.optionVersionSITRegression = New System.Windows.Forms.ComboBox()
        Me.Label308 = New System.Windows.Forms.Label()
        Me.TabPage48 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSITDelta = New System.Windows.Forms.ComboBox()
        Me.Label309 = New System.Windows.Forms.Label()
        Me.Label310 = New System.Windows.Forms.Label()
        Me.optionDefectIdSITDelta = New System.Windows.Forms.TextBox()
        Me.Label311 = New System.Windows.Forms.Label()
        Me.optionDefectKindSITDelta = New System.Windows.Forms.ComboBox()
        Me.Label312 = New System.Windows.Forms.Label()
        Me.optionPtIdSITDelta = New System.Windows.Forms.TextBox()
        Me.Label313 = New System.Windows.Forms.Label()
        Me.optionFailedSITDelta = New System.Windows.Forms.TextBox()
        Me.Label314 = New System.Windows.Forms.Label()
        Me.optionPassedSITDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateSITDelta = New System.Windows.Forms.ComboBox()
        Me.Label315 = New System.Windows.Forms.Label()
        Me.optionVersionSITDelta = New System.Windows.Forms.ComboBox()
        Me.Label316 = New System.Windows.Forms.Label()
        Me.TabPage49 = New System.Windows.Forms.TabPage()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.optionLabTSRCheck = New System.Windows.Forms.TextBox()
        Me.Label317 = New System.Windows.Forms.Label()
        Me.TabControl14 = New System.Windows.Forms.TabControl()
        Me.TabPage50 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSRCheckFull = New System.Windows.Forms.ComboBox()
        Me.Label318 = New System.Windows.Forms.Label()
        Me.Label319 = New System.Windows.Forms.Label()
        Me.optionDefectIdSRCheckFull = New System.Windows.Forms.TextBox()
        Me.Label320 = New System.Windows.Forms.Label()
        Me.optionDefectKindSRCheckFull = New System.Windows.Forms.ComboBox()
        Me.Label321 = New System.Windows.Forms.Label()
        Me.optionPtIdSRCheckFull = New System.Windows.Forms.TextBox()
        Me.Label322 = New System.Windows.Forms.Label()
        Me.optionFailedSRCheckFull = New System.Windows.Forms.TextBox()
        Me.Label323 = New System.Windows.Forms.Label()
        Me.optionPassedSRCheckFull = New System.Windows.Forms.TextBox()
        Me.optionPtStateSRCheckFull = New System.Windows.Forms.ComboBox()
        Me.Label324 = New System.Windows.Forms.Label()
        Me.optionVersionSRCheckFull = New System.Windows.Forms.ComboBox()
        Me.Label325 = New System.Windows.Forms.Label()
        Me.TabPage51 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSRCheckRegression = New System.Windows.Forms.ComboBox()
        Me.Label326 = New System.Windows.Forms.Label()
        Me.Label327 = New System.Windows.Forms.Label()
        Me.optionDefectIdSRCheckRegression = New System.Windows.Forms.TextBox()
        Me.Label328 = New System.Windows.Forms.Label()
        Me.optionDefectKindSRCheckRegression = New System.Windows.Forms.ComboBox()
        Me.Label329 = New System.Windows.Forms.Label()
        Me.optionPtIdSRCheckRegression = New System.Windows.Forms.TextBox()
        Me.Label330 = New System.Windows.Forms.Label()
        Me.optionFailedSRCheckRegression = New System.Windows.Forms.TextBox()
        Me.Label331 = New System.Windows.Forms.Label()
        Me.optionPassedSRCheckRegression = New System.Windows.Forms.TextBox()
        Me.optionPtStateSRCheckRegression = New System.Windows.Forms.ComboBox()
        Me.Label332 = New System.Windows.Forms.Label()
        Me.optionVersionSRCheckRegression = New System.Windows.Forms.ComboBox()
        Me.Label333 = New System.Windows.Forms.Label()
        Me.TabPage52 = New System.Windows.Forms.TabPage()
        Me.optionDefectStateSRCheckDelta = New System.Windows.Forms.ComboBox()
        Me.Label334 = New System.Windows.Forms.Label()
        Me.Label335 = New System.Windows.Forms.Label()
        Me.optionDefectIdSRCheckDelta = New System.Windows.Forms.TextBox()
        Me.Label336 = New System.Windows.Forms.Label()
        Me.optionDefectKindSRCheckDelta = New System.Windows.Forms.ComboBox()
        Me.Label337 = New System.Windows.Forms.Label()
        Me.optionPtIdSRCheckDelta = New System.Windows.Forms.TextBox()
        Me.Label338 = New System.Windows.Forms.Label()
        Me.optionFailedSRCheckDelta = New System.Windows.Forms.TextBox()
        Me.Label339 = New System.Windows.Forms.Label()
        Me.optionPassedSRCheckDelta = New System.Windows.Forms.TextBox()
        Me.optionPtStateSRCheckDelta = New System.Windows.Forms.ComboBox()
        Me.Label340 = New System.Windows.Forms.Label()
        Me.optionVersionSRCheckDelta = New System.Windows.Forms.ComboBox()
        Me.Label341 = New System.Windows.Forms.Label()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel30.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel32.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel33.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel34.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel35.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel36.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.Panel37.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel38.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel39.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel40.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage16.SuspendLayout()
        Me.TabPage17.SuspendLayout()
        Me.TabPage18.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.TabControl4.SuspendLayout()
        Me.TabPage19.SuspendLayout()
        Me.TabPage20.SuspendLayout()
        Me.TabPage21.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.TabControl5.SuspendLayout()
        Me.TabPage22.SuspendLayout()
        Me.TabPage23.SuspendLayout()
        Me.TabPage24.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.TabControl6.SuspendLayout()
        Me.TabPage25.SuspendLayout()
        Me.TabPage26.SuspendLayout()
        Me.TabPage27.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.TabControl7.SuspendLayout()
        Me.TabPage28.SuspendLayout()
        Me.TabPage29.SuspendLayout()
        Me.TabPage30.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.TabControl8.SuspendLayout()
        Me.TabPage31.SuspendLayout()
        Me.TabPage32.SuspendLayout()
        Me.TabPage33.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.TabControl9.SuspendLayout()
        Me.TabPage34.SuspendLayout()
        Me.TabPage35.SuspendLayout()
        Me.TabPage36.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.TabControl10.SuspendLayout()
        Me.TabPage37.SuspendLayout()
        Me.TabPage38.SuspendLayout()
        Me.TabPage39.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.TabControl11.SuspendLayout()
        Me.TabPage40.SuspendLayout()
        Me.TabPage41.SuspendLayout()
        Me.TabPage42.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.TabControl12.SuspendLayout()
        Me.TabPage43.SuspendLayout()
        Me.TabPage44.SuspendLayout()
        Me.TabPage45.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.TabControl13.SuspendLayout()
        Me.TabPage46.SuspendLayout()
        Me.TabPage47.SuspendLayout()
        Me.TabPage48.SuspendLayout()
        Me.TabPage49.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.TabControl14.SuspendLayout()
        Me.TabPage50.SuspendLayout()
        Me.TabPage51.SuspendLayout()
        Me.TabPage52.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.swProject)
        Me.GroupBox1.Controls.Add(Me.releaseDate)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.modifiedBy)
        Me.GroupBox1.Controls.Add(Me.documentOwner)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.endDate)
        Me.GroupBox1.Controls.Add(Me.startDate)
        Me.GroupBox1.Controls.Add(Me.testCoordinator)
        Me.GroupBox1.Controls.Add(Me.levelOfTesting)
        Me.GroupBox1.Controls.Add(Me.documentVersion)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.swVersion)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.swRelease)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.swVariant)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(556, 394)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Project Information"
        '
        'swProject
        '
        Me.swProject.BackColor = System.Drawing.Color.PeachPuff
        Me.swProject.FormattingEnabled = True
        Me.swProject.Location = New System.Drawing.Point(177, 33)
        Me.swProject.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swProject.Name = "swProject"
        Me.swProject.Size = New System.Drawing.Size(373, 24)
        Me.swProject.TabIndex = 18
        '
        'releaseDate
        '
        Me.releaseDate.CustomFormat = ""
        Me.releaseDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.releaseDate.Location = New System.Drawing.Point(177, 349)
        Me.releaseDate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.releaseDate.Name = "releaseDate"
        Me.releaseDate.Size = New System.Drawing.Size(373, 22)
        Me.releaseDate.TabIndex = 16
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label21.Location = New System.Drawing.Point(5, 354)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(106, 18)
        Me.Label21.TabIndex = 17
        Me.Label21.Text = "Release date"
        '
        'modifiedBy
        '
        Me.modifiedBy.BackColor = System.Drawing.Color.PeachPuff
        Me.modifiedBy.Location = New System.Drawing.Point(177, 217)
        Me.modifiedBy.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.modifiedBy.Name = "modifiedBy"
        Me.modifiedBy.Size = New System.Drawing.Size(373, 22)
        Me.modifiedBy.TabIndex = 7
        '
        'documentOwner
        '
        Me.documentOwner.BackColor = System.Drawing.Color.PeachPuff
        Me.documentOwner.Location = New System.Drawing.Point(177, 191)
        Me.documentOwner.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.documentOwner.Name = "documentOwner"
        Me.documentOwner.Size = New System.Drawing.Size(373, 22)
        Me.documentOwner.TabIndex = 6
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label20.Location = New System.Drawing.Point(5, 217)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(94, 18)
        Me.Label20.TabIndex = 15
        Me.Label20.Text = "Modified by"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label19.Location = New System.Drawing.Point(5, 191)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(136, 18)
        Me.Label19.TabIndex = 13
        Me.Label19.Text = "Document owner"
        '
        'endDate
        '
        Me.endDate.CustomFormat = ""
        Me.endDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.endDate.Location = New System.Drawing.Point(177, 323)
        Me.endDate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.endDate.Name = "endDate"
        Me.endDate.Size = New System.Drawing.Size(373, 22)
        Me.endDate.TabIndex = 11
        '
        'startDate
        '
        Me.startDate.CalendarMonthBackground = System.Drawing.Color.White
        Me.startDate.CustomFormat = ""
        Me.startDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.startDate.Location = New System.Drawing.Point(177, 297)
        Me.startDate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.startDate.Name = "startDate"
        Me.startDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.startDate.Size = New System.Drawing.Size(373, 22)
        Me.startDate.TabIndex = 10
        '
        'testCoordinator
        '
        Me.testCoordinator.BackColor = System.Drawing.Color.PeachPuff
        Me.testCoordinator.FormattingEnabled = True
        Me.testCoordinator.Location = New System.Drawing.Point(177, 243)
        Me.testCoordinator.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.testCoordinator.Name = "testCoordinator"
        Me.testCoordinator.Size = New System.Drawing.Size(373, 24)
        Me.testCoordinator.TabIndex = 8
        '
        'levelOfTesting
        '
        Me.levelOfTesting.BackColor = System.Drawing.Color.PeachPuff
        Me.levelOfTesting.FormattingEnabled = True
        Me.levelOfTesting.Location = New System.Drawing.Point(177, 163)
        Me.levelOfTesting.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.levelOfTesting.Name = "levelOfTesting"
        Me.levelOfTesting.Size = New System.Drawing.Size(373, 24)
        Me.levelOfTesting.TabIndex = 5
        '
        'documentVersion
        '
        Me.documentVersion.BackColor = System.Drawing.Color.PeachPuff
        Me.documentVersion.Location = New System.Drawing.Point(177, 271)
        Me.documentVersion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.documentVersion.Name = "documentVersion"
        Me.documentVersion.Size = New System.Drawing.Size(373, 22)
        Me.documentVersion.TabIndex = 9
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(5, 328)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 18)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "End date"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(5, 301)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(81, 18)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Start date"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(5, 274)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(145, 18)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Document version"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(5, 246)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(133, 18)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Test coordinator"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(5, 165)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(122, 18)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Level of testing"
        '
        'swVersion
        '
        Me.swVersion.BackColor = System.Drawing.Color.PeachPuff
        Me.swVersion.FormattingEnabled = True
        Me.swVersion.Location = New System.Drawing.Point(177, 113)
        Me.swVersion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swVersion.Name = "swVersion"
        Me.swVersion.Size = New System.Drawing.Size(373, 24)
        Me.swVersion.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(5, 113)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 18)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Version"
        '
        'swRelease
        '
        Me.swRelease.BackColor = System.Drawing.Color.PeachPuff
        Me.swRelease.Location = New System.Drawing.Point(177, 87)
        Me.swRelease.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swRelease.Name = "swRelease"
        Me.swRelease.Size = New System.Drawing.Size(373, 22)
        Me.swRelease.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(5, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 18)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Release"
        '
        'swVariant
        '
        Me.swVariant.BackColor = System.Drawing.Color.PeachPuff
        Me.swVariant.Location = New System.Drawing.Point(177, 61)
        Me.swVariant.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swVariant.Name = "swVariant"
        Me.swVariant.Size = New System.Drawing.Size(373, 22)
        Me.swVariant.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(5, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 18)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Variant"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(5, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Project"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.swSRCheck)
        Me.GroupBox2.Controls.Add(Me.swRDP)
        Me.GroupBox2.Controls.Add(Me.swSIT)
        Me.GroupBox2.Controls.Add(Me.swHMA)
        Me.GroupBox2.Controls.Add(Me.swVehicle)
        Me.GroupBox2.Controls.Add(Me.swELK)
        Me.GroupBox2.Controls.Add(Me.swTJA)
        Me.GroupBox2.Controls.Add(Me.swLDW)
        Me.GroupBox2.Controls.Add(Me.swSLA)
        Me.GroupBox2.Controls.Add(Me.swLKS)
        Me.GroupBox2.Controls.Add(Me.swCOM)
        Me.GroupBox2.Controls.Add(Me.swEM)
        Me.GroupBox2.Controls.Add(Me.swDCOM)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(12, 612)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Size = New System.Drawing.Size(556, 138)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Test part"
        '
        'swSRCheck
        '
        Me.swSRCheck.AutoSize = True
        Me.swSRCheck.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swSRCheck.ForeColor = System.Drawing.Color.Green
        Me.swSRCheck.Location = New System.Drawing.Point(443, 32)
        Me.swSRCheck.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swSRCheck.Name = "swSRCheck"
        Me.swSRCheck.Size = New System.Drawing.Size(107, 21)
        Me.swSRCheck.TabIndex = 22
        Me.swSRCheck.Text = "SR CHECK"
        Me.swSRCheck.UseVisualStyleBackColor = True
        '
        'swRDP
        '
        Me.swRDP.AutoSize = True
        Me.swRDP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.swRDP.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swRDP.ForeColor = System.Drawing.Color.Green
        Me.swRDP.Location = New System.Drawing.Point(336, 55)
        Me.swRDP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swRDP.Name = "swRDP"
        Me.swRDP.Size = New System.Drawing.Size(62, 21)
        Me.swRDP.TabIndex = 13
        Me.swRDP.Text = "RDP"
        Me.swRDP.UseVisualStyleBackColor = True
        '
        'swSIT
        '
        Me.swSIT.AutoSize = True
        Me.swSIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swSIT.ForeColor = System.Drawing.Color.Green
        Me.swSIT.Location = New System.Drawing.Point(336, 105)
        Me.swSIT.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swSIT.Name = "swSIT"
        Me.swSIT.Size = New System.Drawing.Size(54, 21)
        Me.swSIT.TabIndex = 21
        Me.swSIT.Text = "SIT"
        Me.swSIT.UseVisualStyleBackColor = True
        '
        'swHMA
        '
        Me.swHMA.AutoSize = True
        Me.swHMA.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swHMA.ForeColor = System.Drawing.Color.Green
        Me.swHMA.Location = New System.Drawing.Point(20, 105)
        Me.swHMA.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swHMA.Name = "swHMA"
        Me.swHMA.Size = New System.Drawing.Size(63, 21)
        Me.swHMA.TabIndex = 20
        Me.swHMA.Text = "HMA"
        Me.swHMA.UseVisualStyleBackColor = True
        '
        'swVehicle
        '
        Me.swVehicle.AutoSize = True
        Me.swVehicle.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swVehicle.ForeColor = System.Drawing.Color.Green
        Me.swVehicle.Location = New System.Drawing.Point(177, 105)
        Me.swVehicle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swVehicle.Name = "swVehicle"
        Me.swVehicle.Size = New System.Drawing.Size(94, 21)
        Me.swVehicle.TabIndex = 18
        Me.swVehicle.Text = "VEHICLE"
        Me.swVehicle.UseVisualStyleBackColor = True
        '
        'swELK
        '
        Me.swELK.AutoSize = True
        Me.swELK.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swELK.ForeColor = System.Drawing.Color.Green
        Me.swELK.Location = New System.Drawing.Point(20, 80)
        Me.swELK.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swELK.Name = "swELK"
        Me.swELK.Size = New System.Drawing.Size(59, 21)
        Me.swELK.TabIndex = 19
        Me.swELK.Text = "ELK"
        Me.swELK.UseVisualStyleBackColor = True
        '
        'swTJA
        '
        Me.swTJA.AutoSize = True
        Me.swTJA.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swTJA.ForeColor = System.Drawing.Color.Green
        Me.swTJA.Location = New System.Drawing.Point(177, 80)
        Me.swTJA.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swTJA.Name = "swTJA"
        Me.swTJA.Size = New System.Drawing.Size(58, 21)
        Me.swTJA.TabIndex = 17
        Me.swTJA.Text = "TJA"
        Me.swTJA.UseVisualStyleBackColor = True
        '
        'swLDW
        '
        Me.swLDW.AutoSize = True
        Me.swLDW.Cursor = System.Windows.Forms.Cursors.Hand
        Me.swLDW.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swLDW.ForeColor = System.Drawing.Color.Green
        Me.swLDW.Location = New System.Drawing.Point(20, 55)
        Me.swLDW.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swLDW.Name = "swLDW"
        Me.swLDW.Size = New System.Drawing.Size(64, 21)
        Me.swLDW.TabIndex = 15
        Me.swLDW.Text = "LDW"
        Me.swLDW.UseVisualStyleBackColor = True
        '
        'swSLA
        '
        Me.swSLA.AutoSize = True
        Me.swSLA.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swSLA.ForeColor = System.Drawing.Color.Green
        Me.swSLA.Location = New System.Drawing.Point(336, 80)
        Me.swSLA.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swSLA.Name = "swSLA"
        Me.swSLA.Size = New System.Drawing.Size(59, 21)
        Me.swSLA.TabIndex = 16
        Me.swSLA.Text = "SLA"
        Me.swSLA.UseVisualStyleBackColor = True
        '
        'swLKS
        '
        Me.swLKS.AutoSize = True
        Me.swLKS.Cursor = System.Windows.Forms.Cursors.Hand
        Me.swLKS.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swLKS.ForeColor = System.Drawing.Color.Green
        Me.swLKS.Location = New System.Drawing.Point(177, 55)
        Me.swLKS.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swLKS.Name = "swLKS"
        Me.swLKS.Size = New System.Drawing.Size(59, 21)
        Me.swLKS.TabIndex = 14
        Me.swLKS.Text = "LKS"
        Me.swLKS.UseVisualStyleBackColor = True
        '
        'swCOM
        '
        Me.swCOM.AutoSize = True
        Me.swCOM.Cursor = System.Windows.Forms.Cursors.Hand
        Me.swCOM.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swCOM.ForeColor = System.Drawing.Color.Green
        Me.swCOM.Location = New System.Drawing.Point(336, 32)
        Me.swCOM.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swCOM.Name = "swCOM"
        Me.swCOM.Size = New System.Drawing.Size(64, 21)
        Me.swCOM.TabIndex = 12
        Me.swCOM.Text = "COM"
        Me.swCOM.UseVisualStyleBackColor = True
        '
        'swEM
        '
        Me.swEM.AutoSize = True
        Me.swEM.Cursor = System.Windows.Forms.Cursors.Hand
        Me.swEM.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swEM.ForeColor = System.Drawing.Color.Green
        Me.swEM.Location = New System.Drawing.Point(177, 30)
        Me.swEM.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swEM.Name = "swEM"
        Me.swEM.Size = New System.Drawing.Size(53, 23)
        Me.swEM.TabIndex = 11
        Me.swEM.Text = "EM"
        Me.swEM.UseVisualStyleBackColor = True
        '
        'swDCOM
        '
        Me.swDCOM.AutoSize = True
        Me.swDCOM.Cursor = System.Windows.Forms.Cursors.Hand
        Me.swDCOM.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swDCOM.ForeColor = System.Drawing.Color.Green
        Me.swDCOM.Location = New System.Drawing.Point(20, 30)
        Me.swDCOM.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.swDCOM.Name = "swDCOM"
        Me.swDCOM.Size = New System.Drawing.Size(75, 21)
        Me.swDCOM.TabIndex = 10
        Me.swDCOM.Text = "DCOM"
        Me.swDCOM.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(5, 53)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 17)
        Me.Label5.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Red
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(156, 870)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(127, 33)
        Me.Button1.TabIndex = 22
        Me.Button1.Text = "RUN"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.Controls.Add(Me.swCoresi)
        Me.GroupBox3.Controls.Add(Me.swSource)
        Me.GroupBox3.Controls.Add(Me.swDelivery)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox3.Location = New System.Drawing.Point(13, 411)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(555, 196)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Software information"
        '
        'swCoresi
        '
        Me.swCoresi.BackColor = System.Drawing.Color.PeachPuff
        Me.swCoresi.Location = New System.Drawing.Point(176, 138)
        Me.swCoresi.Name = "swCoresi"
        Me.swCoresi.Size = New System.Drawing.Size(373, 47)
        Me.swCoresi.TabIndex = 12
        Me.swCoresi.Text = ""
        '
        'swSource
        '
        Me.swSource.BackColor = System.Drawing.Color.PeachPuff
        Me.swSource.Location = New System.Drawing.Point(176, 85)
        Me.swSource.Name = "swSource"
        Me.swSource.Size = New System.Drawing.Size(373, 47)
        Me.swSource.TabIndex = 11
        Me.swSource.Text = ""
        '
        'swDelivery
        '
        Me.swDelivery.BackColor = System.Drawing.Color.PeachPuff
        Me.swDelivery.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.swDelivery.Location = New System.Drawing.Point(176, 32)
        Me.swDelivery.Name = "swDelivery"
        Me.swDelivery.ShowSelectionMargin = True
        Me.swDelivery.Size = New System.Drawing.Size(373, 47)
        Me.swDelivery.TabIndex = 1
        Me.swDelivery.Text = ""
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label24.Location = New System.Drawing.Point(4, 32)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(68, 18)
        Me.Label24.TabIndex = 5
        Me.Label24.Text = "Delivery"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label22.Location = New System.Drawing.Point(6, 138)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(58, 18)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "Coresi"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label23.Location = New System.Drawing.Point(6, 85)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(62, 18)
        Me.Label23.TabIndex = 8
        Me.Label23.Text = "Source"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Green
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.Location = New System.Drawing.Point(298, 870)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(127, 33)
        Me.Button2.TabIndex = 23
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button3.Location = New System.Drawing.Point(12, 870)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(127, 33)
        Me.Button3.TabIndex = 25
        Me.Button3.Text = "BROWSE"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'ouputReportLocation
        '
        Me.ouputReportLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ouputReportLocation.Location = New System.Drawing.Point(12, 831)
        Me.ouputReportLocation.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ouputReportLocation.Name = "ouputReportLocation"
        Me.ouputReportLocation.Size = New System.Drawing.Size(556, 24)
        Me.ouputReportLocation.TabIndex = 10
        '
        'terminal
        '
        Me.terminal.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.terminal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.terminal.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.terminal.ForeColor = System.Drawing.SystemColors.Info
        Me.terminal.Location = New System.Drawing.Point(12, 755)
        Me.terminal.Name = "terminal"
        Me.terminal.ReadOnly = True
        Me.terminal.Size = New System.Drawing.Size(556, 71)
        Me.terminal.TabIndex = 2
        Me.terminal.Text = ""
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BackColor = System.Drawing.Color.Purple
        Me.Panel2.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Panel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(574, 18)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1152, 885)
        Me.Panel2.TabIndex = 23
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.FlowLayoutPanel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TabControl1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.13559!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.86441!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1152, 885)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.Purple
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel15)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel16)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel17)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel18)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel19)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel20)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel21)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel22)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel23)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel24)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel25)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel26)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel27)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(1146, 596)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.Panel28)
        Me.Panel15.Controls.Add(Me.Button4)
        Me.Panel15.Location = New System.Drawing.Point(3, 3)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(211, 165)
        Me.Panel15.TabIndex = 13
        '
        'Panel28
        '
        Me.Panel28.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel28.Controls.Add(Me.optionDCOMDelta)
        Me.Panel28.Controls.Add(Me.optionDCOMRegression)
        Me.Panel28.Controls.Add(Me.optionDCOMFull)
        Me.Panel28.ForeColor = System.Drawing.Color.Purple
        Me.Panel28.Location = New System.Drawing.Point(5, 132)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(200, 30)
        Me.Panel28.TabIndex = 1
        '
        'optionDCOMDelta
        '
        Me.optionDCOMDelta.AutoSize = True
        Me.optionDCOMDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionDCOMDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionDCOMDelta.Name = "optionDCOMDelta"
        Me.optionDCOMDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionDCOMDelta.TabIndex = 2
        Me.optionDCOMDelta.Text = "D"
        Me.optionDCOMDelta.UseVisualStyleBackColor = True
        '
        'optionDCOMRegression
        '
        Me.optionDCOMRegression.AutoSize = True
        Me.optionDCOMRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionDCOMRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionDCOMRegression.Name = "optionDCOMRegression"
        Me.optionDCOMRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionDCOMRegression.TabIndex = 1
        Me.optionDCOMRegression.Text = "R"
        Me.optionDCOMRegression.UseVisualStyleBackColor = True
        '
        'optionDCOMFull
        '
        Me.optionDCOMFull.AutoSize = True
        Me.optionDCOMFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionDCOMFull.Location = New System.Drawing.Point(15, 5)
        Me.optionDCOMFull.Name = "optionDCOMFull"
        Me.optionDCOMFull.Size = New System.Drawing.Size(39, 21)
        Me.optionDCOMFull.TabIndex = 0
        Me.optionDCOMFull.Text = "F"
        Me.optionDCOMFull.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.Purple
        Me.Button4.Location = New System.Drawing.Point(0, 0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(211, 165)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "DCOM"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.Panel29)
        Me.Panel16.Controls.Add(Me.CheckBox15)
        Me.Panel16.Controls.Add(Me.Button5)
        Me.Panel16.Location = New System.Drawing.Point(220, 3)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(211, 165)
        Me.Panel16.TabIndex = 14
        '
        'Panel29
        '
        Me.Panel29.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel29.Controls.Add(Me.optionEMDelta)
        Me.Panel29.Controls.Add(Me.optionEMRegression)
        Me.Panel29.Controls.Add(Me.optionEMFull)
        Me.Panel29.ForeColor = System.Drawing.Color.Purple
        Me.Panel29.Location = New System.Drawing.Point(6, 132)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(200, 30)
        Me.Panel29.TabIndex = 3
        '
        'optionEMDelta
        '
        Me.optionEMDelta.AutoSize = True
        Me.optionEMDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionEMDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionEMDelta.Name = "optionEMDelta"
        Me.optionEMDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionEMDelta.TabIndex = 2
        Me.optionEMDelta.Text = "D"
        Me.optionEMDelta.UseVisualStyleBackColor = True
        '
        'optionEMRegression
        '
        Me.optionEMRegression.AutoSize = True
        Me.optionEMRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionEMRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionEMRegression.Name = "optionEMRegression"
        Me.optionEMRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionEMRegression.TabIndex = 1
        Me.optionEMRegression.Text = "R"
        Me.optionEMRegression.UseVisualStyleBackColor = True
        '
        'optionEMFull
        '
        Me.optionEMFull.AutoSize = True
        Me.optionEMFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionEMFull.Location = New System.Drawing.Point(15, 5)
        Me.optionEMFull.Name = "optionEMFull"
        Me.optionEMFull.Size = New System.Drawing.Size(39, 21)
        Me.optionEMFull.TabIndex = 0
        Me.optionEMFull.Text = "F"
        Me.optionEMFull.UseVisualStyleBackColor = True
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox15.TabIndex = 0
        Me.CheckBox15.Text = "CheckBox15"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Purple
        Me.Button5.Location = New System.Drawing.Point(0, 0)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(211, 165)
        Me.Button5.TabIndex = 1
        Me.Button5.Text = "EM"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.Panel30)
        Me.Panel17.Controls.Add(Me.CheckBox16)
        Me.Panel17.Controls.Add(Me.Button6)
        Me.Panel17.Location = New System.Drawing.Point(437, 3)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(211, 165)
        Me.Panel17.TabIndex = 15
        '
        'Panel30
        '
        Me.Panel30.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel30.Controls.Add(Me.optionCOMDelta)
        Me.Panel30.Controls.Add(Me.optionCOMRegression)
        Me.Panel30.Controls.Add(Me.optionCOMFull)
        Me.Panel30.ForeColor = System.Drawing.Color.Purple
        Me.Panel30.Location = New System.Drawing.Point(5, 132)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(200, 30)
        Me.Panel30.TabIndex = 4
        '
        'optionCOMDelta
        '
        Me.optionCOMDelta.AutoSize = True
        Me.optionCOMDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionCOMDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionCOMDelta.Name = "optionCOMDelta"
        Me.optionCOMDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionCOMDelta.TabIndex = 2
        Me.optionCOMDelta.Text = "D"
        Me.optionCOMDelta.UseVisualStyleBackColor = True
        '
        'optionCOMRegression
        '
        Me.optionCOMRegression.AutoSize = True
        Me.optionCOMRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionCOMRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionCOMRegression.Name = "optionCOMRegression"
        Me.optionCOMRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionCOMRegression.TabIndex = 1
        Me.optionCOMRegression.Text = "R"
        Me.optionCOMRegression.UseVisualStyleBackColor = True
        '
        'optionCOMFull
        '
        Me.optionCOMFull.AutoSize = True
        Me.optionCOMFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionCOMFull.Location = New System.Drawing.Point(15, 5)
        Me.optionCOMFull.Name = "optionCOMFull"
        Me.optionCOMFull.Size = New System.Drawing.Size(39, 21)
        Me.optionCOMFull.TabIndex = 0
        Me.optionCOMFull.Text = "F"
        Me.optionCOMFull.UseVisualStyleBackColor = True
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox16.TabIndex = 0
        Me.CheckBox16.Text = "CheckBox16"
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.Purple
        Me.Button6.Location = New System.Drawing.Point(0, 0)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(211, 165)
        Me.Button6.TabIndex = 2
        Me.Button6.Text = "COM"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.Panel31)
        Me.Panel18.Controls.Add(Me.CheckBox17)
        Me.Panel18.Controls.Add(Me.Button7)
        Me.Panel18.Location = New System.Drawing.Point(654, 3)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(211, 165)
        Me.Panel18.TabIndex = 16
        '
        'Panel31
        '
        Me.Panel31.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel31.Controls.Add(Me.optionLDWDelta)
        Me.Panel31.Controls.Add(Me.optionLDWRegression)
        Me.Panel31.Controls.Add(Me.optionLDWFull)
        Me.Panel31.ForeColor = System.Drawing.Color.Purple
        Me.Panel31.Location = New System.Drawing.Point(6, 132)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(200, 30)
        Me.Panel31.TabIndex = 5
        '
        'optionLDWDelta
        '
        Me.optionLDWDelta.AutoSize = True
        Me.optionLDWDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionLDWDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionLDWDelta.Name = "optionLDWDelta"
        Me.optionLDWDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionLDWDelta.TabIndex = 2
        Me.optionLDWDelta.Text = "D"
        Me.optionLDWDelta.UseVisualStyleBackColor = True
        '
        'optionLDWRegression
        '
        Me.optionLDWRegression.AutoSize = True
        Me.optionLDWRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionLDWRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionLDWRegression.Name = "optionLDWRegression"
        Me.optionLDWRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionLDWRegression.TabIndex = 1
        Me.optionLDWRegression.Text = "R"
        Me.optionLDWRegression.UseVisualStyleBackColor = True
        '
        'optionLDWFull
        '
        Me.optionLDWFull.AutoSize = True
        Me.optionLDWFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionLDWFull.Location = New System.Drawing.Point(15, 5)
        Me.optionLDWFull.Name = "optionLDWFull"
        Me.optionLDWFull.Size = New System.Drawing.Size(39, 21)
        Me.optionLDWFull.TabIndex = 0
        Me.optionLDWFull.Text = "F"
        Me.optionLDWFull.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox17.TabIndex = 0
        Me.CheckBox17.Text = "CheckBox17"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.Purple
        Me.Button7.Location = New System.Drawing.Point(0, 0)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(211, 165)
        Me.Button7.TabIndex = 3
        Me.Button7.Text = "LDW"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.Panel32)
        Me.Panel19.Controls.Add(Me.CheckBox18)
        Me.Panel19.Controls.Add(Me.Button8)
        Me.Panel19.Location = New System.Drawing.Point(871, 3)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(211, 165)
        Me.Panel19.TabIndex = 17
        '
        'Panel32
        '
        Me.Panel32.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel32.Controls.Add(Me.optionLKSDelta)
        Me.Panel32.Controls.Add(Me.optionLKSRegression)
        Me.Panel32.Controls.Add(Me.optionLKSFull)
        Me.Panel32.ForeColor = System.Drawing.Color.Purple
        Me.Panel32.Location = New System.Drawing.Point(5, 132)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(200, 30)
        Me.Panel32.TabIndex = 5
        '
        'optionLKSDelta
        '
        Me.optionLKSDelta.AutoSize = True
        Me.optionLKSDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionLKSDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionLKSDelta.Name = "optionLKSDelta"
        Me.optionLKSDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionLKSDelta.TabIndex = 2
        Me.optionLKSDelta.Text = "D"
        Me.optionLKSDelta.UseVisualStyleBackColor = True
        '
        'optionLKSRegression
        '
        Me.optionLKSRegression.AutoSize = True
        Me.optionLKSRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionLKSRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionLKSRegression.Name = "optionLKSRegression"
        Me.optionLKSRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionLKSRegression.TabIndex = 1
        Me.optionLKSRegression.Text = "R"
        Me.optionLKSRegression.UseVisualStyleBackColor = True
        '
        'optionLKSFull
        '
        Me.optionLKSFull.AutoSize = True
        Me.optionLKSFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionLKSFull.Location = New System.Drawing.Point(15, 5)
        Me.optionLKSFull.Name = "optionLKSFull"
        Me.optionLKSFull.Size = New System.Drawing.Size(39, 21)
        Me.optionLKSFull.TabIndex = 0
        Me.optionLKSFull.Text = "F"
        Me.optionLKSFull.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox18.TabIndex = 0
        Me.CheckBox18.Text = "CheckBox18"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.Purple
        Me.Button8.Location = New System.Drawing.Point(0, 0)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(211, 165)
        Me.Button8.TabIndex = 4
        Me.Button8.Text = "LKS"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.Panel33)
        Me.Panel20.Controls.Add(Me.CheckBox19)
        Me.Panel20.Controls.Add(Me.Button9)
        Me.Panel20.Location = New System.Drawing.Point(3, 174)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(211, 165)
        Me.Panel20.TabIndex = 18
        '
        'Panel33
        '
        Me.Panel33.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel33.Controls.Add(Me.optionRDPDelta)
        Me.Panel33.Controls.Add(Me.optionRDPRegression)
        Me.Panel33.Controls.Add(Me.optionRDPFull)
        Me.Panel33.ForeColor = System.Drawing.Color.Purple
        Me.Panel33.Location = New System.Drawing.Point(5, 132)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(200, 30)
        Me.Panel33.TabIndex = 6
        '
        'optionRDPDelta
        '
        Me.optionRDPDelta.AutoSize = True
        Me.optionRDPDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionRDPDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionRDPDelta.Name = "optionRDPDelta"
        Me.optionRDPDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionRDPDelta.TabIndex = 2
        Me.optionRDPDelta.Text = "D"
        Me.optionRDPDelta.UseVisualStyleBackColor = True
        '
        'optionRDPRegression
        '
        Me.optionRDPRegression.AutoSize = True
        Me.optionRDPRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionRDPRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionRDPRegression.Name = "optionRDPRegression"
        Me.optionRDPRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionRDPRegression.TabIndex = 1
        Me.optionRDPRegression.Text = "R"
        Me.optionRDPRegression.UseVisualStyleBackColor = True
        '
        'optionRDPFull
        '
        Me.optionRDPFull.AutoSize = True
        Me.optionRDPFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionRDPFull.Location = New System.Drawing.Point(15, 5)
        Me.optionRDPFull.Name = "optionRDPFull"
        Me.optionRDPFull.Size = New System.Drawing.Size(39, 21)
        Me.optionRDPFull.TabIndex = 0
        Me.optionRDPFull.Text = "F"
        Me.optionRDPFull.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox19.TabIndex = 0
        Me.CheckBox19.Text = "CheckBox19"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.Purple
        Me.Button9.Location = New System.Drawing.Point(0, 0)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(211, 165)
        Me.Button9.TabIndex = 5
        Me.Button9.Text = "RDP"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Panel21
        '
        Me.Panel21.Controls.Add(Me.Panel34)
        Me.Panel21.Controls.Add(Me.CheckBox20)
        Me.Panel21.Controls.Add(Me.Button10)
        Me.Panel21.Location = New System.Drawing.Point(220, 174)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(211, 165)
        Me.Panel21.TabIndex = 19
        '
        'Panel34
        '
        Me.Panel34.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel34.Controls.Add(Me.optionELKDelta)
        Me.Panel34.Controls.Add(Me.optionELKRegression)
        Me.Panel34.Controls.Add(Me.optionELKFull)
        Me.Panel34.ForeColor = System.Drawing.Color.Purple
        Me.Panel34.Location = New System.Drawing.Point(5, 132)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(200, 30)
        Me.Panel34.TabIndex = 7
        '
        'optionELKDelta
        '
        Me.optionELKDelta.AutoSize = True
        Me.optionELKDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionELKDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionELKDelta.Name = "optionELKDelta"
        Me.optionELKDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionELKDelta.TabIndex = 2
        Me.optionELKDelta.Text = "D"
        Me.optionELKDelta.UseVisualStyleBackColor = True
        '
        'optionELKRegression
        '
        Me.optionELKRegression.AutoSize = True
        Me.optionELKRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionELKRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionELKRegression.Name = "optionELKRegression"
        Me.optionELKRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionELKRegression.TabIndex = 1
        Me.optionELKRegression.Text = "R"
        Me.optionELKRegression.UseVisualStyleBackColor = True
        '
        'optionELKFull
        '
        Me.optionELKFull.AutoSize = True
        Me.optionELKFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionELKFull.Location = New System.Drawing.Point(15, 5)
        Me.optionELKFull.Name = "optionELKFull"
        Me.optionELKFull.Size = New System.Drawing.Size(39, 21)
        Me.optionELKFull.TabIndex = 0
        Me.optionELKFull.Text = "F"
        Me.optionELKFull.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox20.TabIndex = 0
        Me.CheckBox20.Text = "CheckBox20"
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.Purple
        Me.Button10.Location = New System.Drawing.Point(0, 0)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(211, 165)
        Me.Button10.TabIndex = 6
        Me.Button10.Text = "ELK"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.Panel35)
        Me.Panel22.Controls.Add(Me.CheckBox21)
        Me.Panel22.Controls.Add(Me.Button11)
        Me.Panel22.Location = New System.Drawing.Point(437, 174)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(211, 165)
        Me.Panel22.TabIndex = 20
        '
        'Panel35
        '
        Me.Panel35.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel35.Controls.Add(Me.optionTJADelta)
        Me.Panel35.Controls.Add(Me.optionTJARegression)
        Me.Panel35.Controls.Add(Me.optionTJAFull)
        Me.Panel35.ForeColor = System.Drawing.Color.Purple
        Me.Panel35.Location = New System.Drawing.Point(5, 132)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(200, 30)
        Me.Panel35.TabIndex = 8
        '
        'optionTJADelta
        '
        Me.optionTJADelta.AutoSize = True
        Me.optionTJADelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionTJADelta.Location = New System.Drawing.Point(150, 5)
        Me.optionTJADelta.Name = "optionTJADelta"
        Me.optionTJADelta.Size = New System.Drawing.Size(41, 21)
        Me.optionTJADelta.TabIndex = 2
        Me.optionTJADelta.Text = "D"
        Me.optionTJADelta.UseVisualStyleBackColor = True
        '
        'optionTJARegression
        '
        Me.optionTJARegression.AutoSize = True
        Me.optionTJARegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionTJARegression.Location = New System.Drawing.Point(86, 5)
        Me.optionTJARegression.Name = "optionTJARegression"
        Me.optionTJARegression.Size = New System.Drawing.Size(41, 21)
        Me.optionTJARegression.TabIndex = 1
        Me.optionTJARegression.Text = "R"
        Me.optionTJARegression.UseVisualStyleBackColor = True
        '
        'optionTJAFull
        '
        Me.optionTJAFull.AutoSize = True
        Me.optionTJAFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionTJAFull.Location = New System.Drawing.Point(15, 5)
        Me.optionTJAFull.Name = "optionTJAFull"
        Me.optionTJAFull.Size = New System.Drawing.Size(39, 21)
        Me.optionTJAFull.TabIndex = 0
        Me.optionTJAFull.Text = "F"
        Me.optionTJAFull.UseVisualStyleBackColor = True
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox21.TabIndex = 0
        Me.CheckBox21.Text = "CheckBox21"
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.Purple
        Me.Button11.Location = New System.Drawing.Point(0, 0)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(211, 165)
        Me.Button11.TabIndex = 7
        Me.Button11.Text = "TJA"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Panel23
        '
        Me.Panel23.Controls.Add(Me.Panel36)
        Me.Panel23.Controls.Add(Me.CheckBox22)
        Me.Panel23.Controls.Add(Me.Button12)
        Me.Panel23.Location = New System.Drawing.Point(654, 174)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(211, 165)
        Me.Panel23.TabIndex = 21
        '
        'Panel36
        '
        Me.Panel36.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel36.Controls.Add(Me.optionSLADelta)
        Me.Panel36.Controls.Add(Me.optionSLARegression)
        Me.Panel36.Controls.Add(Me.optionSLAFull)
        Me.Panel36.ForeColor = System.Drawing.Color.Purple
        Me.Panel36.Location = New System.Drawing.Point(5, 132)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(200, 30)
        Me.Panel36.TabIndex = 9
        '
        'optionSLADelta
        '
        Me.optionSLADelta.AutoSize = True
        Me.optionSLADelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSLADelta.Location = New System.Drawing.Point(150, 5)
        Me.optionSLADelta.Name = "optionSLADelta"
        Me.optionSLADelta.Size = New System.Drawing.Size(41, 21)
        Me.optionSLADelta.TabIndex = 2
        Me.optionSLADelta.Text = "D"
        Me.optionSLADelta.UseVisualStyleBackColor = True
        '
        'optionSLARegression
        '
        Me.optionSLARegression.AutoSize = True
        Me.optionSLARegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSLARegression.Location = New System.Drawing.Point(86, 5)
        Me.optionSLARegression.Name = "optionSLARegression"
        Me.optionSLARegression.Size = New System.Drawing.Size(41, 21)
        Me.optionSLARegression.TabIndex = 1
        Me.optionSLARegression.Text = "R"
        Me.optionSLARegression.UseVisualStyleBackColor = True
        '
        'optionSLAFull
        '
        Me.optionSLAFull.AutoSize = True
        Me.optionSLAFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSLAFull.Location = New System.Drawing.Point(15, 5)
        Me.optionSLAFull.Name = "optionSLAFull"
        Me.optionSLAFull.Size = New System.Drawing.Size(39, 21)
        Me.optionSLAFull.TabIndex = 0
        Me.optionSLAFull.Text = "F"
        Me.optionSLAFull.UseVisualStyleBackColor = True
        '
        'CheckBox22
        '
        Me.CheckBox22.AutoSize = True
        Me.CheckBox22.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox22.Name = "CheckBox22"
        Me.CheckBox22.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox22.TabIndex = 0
        Me.CheckBox22.Text = "CheckBox22"
        Me.CheckBox22.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button12.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.ForeColor = System.Drawing.Color.Purple
        Me.Button12.Location = New System.Drawing.Point(0, 0)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(211, 165)
        Me.Button12.TabIndex = 8
        Me.Button12.Text = "SLA"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Panel24
        '
        Me.Panel24.Controls.Add(Me.Panel37)
        Me.Panel24.Controls.Add(Me.CheckBox23)
        Me.Panel24.Controls.Add(Me.Button13)
        Me.Panel24.Location = New System.Drawing.Point(871, 174)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(211, 165)
        Me.Panel24.TabIndex = 22
        '
        'Panel37
        '
        Me.Panel37.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel37.Controls.Add(Me.optionHMADelta)
        Me.Panel37.Controls.Add(Me.optionHMARegression)
        Me.Panel37.Controls.Add(Me.optionHMAFull)
        Me.Panel37.ForeColor = System.Drawing.Color.Purple
        Me.Panel37.Location = New System.Drawing.Point(5, 132)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(200, 30)
        Me.Panel37.TabIndex = 10
        '
        'optionHMADelta
        '
        Me.optionHMADelta.AutoSize = True
        Me.optionHMADelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionHMADelta.Location = New System.Drawing.Point(150, 5)
        Me.optionHMADelta.Name = "optionHMADelta"
        Me.optionHMADelta.Size = New System.Drawing.Size(41, 21)
        Me.optionHMADelta.TabIndex = 2
        Me.optionHMADelta.Text = "D"
        Me.optionHMADelta.UseVisualStyleBackColor = True
        '
        'optionHMARegression
        '
        Me.optionHMARegression.AutoSize = True
        Me.optionHMARegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionHMARegression.Location = New System.Drawing.Point(86, 5)
        Me.optionHMARegression.Name = "optionHMARegression"
        Me.optionHMARegression.Size = New System.Drawing.Size(41, 21)
        Me.optionHMARegression.TabIndex = 1
        Me.optionHMARegression.Text = "R"
        Me.optionHMARegression.UseVisualStyleBackColor = True
        '
        'optionHMAFull
        '
        Me.optionHMAFull.AutoSize = True
        Me.optionHMAFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionHMAFull.Location = New System.Drawing.Point(15, 5)
        Me.optionHMAFull.Name = "optionHMAFull"
        Me.optionHMAFull.Size = New System.Drawing.Size(39, 21)
        Me.optionHMAFull.TabIndex = 0
        Me.optionHMAFull.Text = "F"
        Me.optionHMAFull.UseVisualStyleBackColor = True
        '
        'CheckBox23
        '
        Me.CheckBox23.AutoSize = True
        Me.CheckBox23.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox23.TabIndex = 0
        Me.CheckBox23.Text = "CheckBox23"
        Me.CheckBox23.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = System.Drawing.Color.Purple
        Me.Button13.Location = New System.Drawing.Point(0, 0)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(211, 165)
        Me.Button13.TabIndex = 9
        Me.Button13.Text = "HMA"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Panel25
        '
        Me.Panel25.Controls.Add(Me.Panel38)
        Me.Panel25.Controls.Add(Me.CheckBox24)
        Me.Panel25.Controls.Add(Me.Button14)
        Me.Panel25.Location = New System.Drawing.Point(3, 345)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(211, 165)
        Me.Panel25.TabIndex = 23
        '
        'Panel38
        '
        Me.Panel38.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel38.Controls.Add(Me.optionVehicleDelta)
        Me.Panel38.Controls.Add(Me.optionVehicleRegression)
        Me.Panel38.Controls.Add(Me.optionVehicleFull)
        Me.Panel38.ForeColor = System.Drawing.Color.Purple
        Me.Panel38.Location = New System.Drawing.Point(5, 132)
        Me.Panel38.Name = "Panel38"
        Me.Panel38.Size = New System.Drawing.Size(200, 30)
        Me.Panel38.TabIndex = 11
        '
        'optionVehicleDelta
        '
        Me.optionVehicleDelta.AutoSize = True
        Me.optionVehicleDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionVehicleDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionVehicleDelta.Name = "optionVehicleDelta"
        Me.optionVehicleDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionVehicleDelta.TabIndex = 2
        Me.optionVehicleDelta.Text = "D"
        Me.optionVehicleDelta.UseVisualStyleBackColor = True
        '
        'optionVehicleRegression
        '
        Me.optionVehicleRegression.AutoSize = True
        Me.optionVehicleRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionVehicleRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionVehicleRegression.Name = "optionVehicleRegression"
        Me.optionVehicleRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionVehicleRegression.TabIndex = 1
        Me.optionVehicleRegression.Text = "R"
        Me.optionVehicleRegression.UseVisualStyleBackColor = True
        '
        'optionVehicleFull
        '
        Me.optionVehicleFull.AutoSize = True
        Me.optionVehicleFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionVehicleFull.Location = New System.Drawing.Point(15, 5)
        Me.optionVehicleFull.Name = "optionVehicleFull"
        Me.optionVehicleFull.Size = New System.Drawing.Size(39, 21)
        Me.optionVehicleFull.TabIndex = 0
        Me.optionVehicleFull.Text = "F"
        Me.optionVehicleFull.UseVisualStyleBackColor = True
        '
        'CheckBox24
        '
        Me.CheckBox24.AutoSize = True
        Me.CheckBox24.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox24.Name = "CheckBox24"
        Me.CheckBox24.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox24.TabIndex = 0
        Me.CheckBox24.Text = "CheckBox24"
        Me.CheckBox24.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button14.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.ForeColor = System.Drawing.Color.Purple
        Me.Button14.Location = New System.Drawing.Point(0, 0)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(211, 165)
        Me.Button14.TabIndex = 10
        Me.Button14.Text = "VEHICLE"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Panel26
        '
        Me.Panel26.Controls.Add(Me.Panel39)
        Me.Panel26.Controls.Add(Me.CheckBox25)
        Me.Panel26.Controls.Add(Me.Button15)
        Me.Panel26.Location = New System.Drawing.Point(220, 345)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(211, 165)
        Me.Panel26.TabIndex = 24
        '
        'Panel39
        '
        Me.Panel39.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel39.Controls.Add(Me.optionSITDelta)
        Me.Panel39.Controls.Add(Me.optionSITRegression)
        Me.Panel39.Controls.Add(Me.optionSITFull)
        Me.Panel39.ForeColor = System.Drawing.Color.Purple
        Me.Panel39.Location = New System.Drawing.Point(5, 132)
        Me.Panel39.Name = "Panel39"
        Me.Panel39.Size = New System.Drawing.Size(200, 30)
        Me.Panel39.TabIndex = 12
        '
        'optionSITDelta
        '
        Me.optionSITDelta.AutoSize = True
        Me.optionSITDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSITDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionSITDelta.Name = "optionSITDelta"
        Me.optionSITDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionSITDelta.TabIndex = 2
        Me.optionSITDelta.Text = "D"
        Me.optionSITDelta.UseVisualStyleBackColor = True
        '
        'optionSITRegression
        '
        Me.optionSITRegression.AutoSize = True
        Me.optionSITRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSITRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionSITRegression.Name = "optionSITRegression"
        Me.optionSITRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionSITRegression.TabIndex = 1
        Me.optionSITRegression.Text = "R"
        Me.optionSITRegression.UseVisualStyleBackColor = True
        '
        'optionSITFull
        '
        Me.optionSITFull.AutoSize = True
        Me.optionSITFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSITFull.Location = New System.Drawing.Point(15, 5)
        Me.optionSITFull.Name = "optionSITFull"
        Me.optionSITFull.Size = New System.Drawing.Size(39, 21)
        Me.optionSITFull.TabIndex = 0
        Me.optionSITFull.Text = "F"
        Me.optionSITFull.UseVisualStyleBackColor = True
        '
        'CheckBox25
        '
        Me.CheckBox25.AutoSize = True
        Me.CheckBox25.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox25.Name = "CheckBox25"
        Me.CheckBox25.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox25.TabIndex = 0
        Me.CheckBox25.Text = "CheckBox25"
        Me.CheckBox25.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.ForeColor = System.Drawing.Color.Purple
        Me.Button15.Location = New System.Drawing.Point(0, 0)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(211, 165)
        Me.Button15.TabIndex = 11
        Me.Button15.Text = "SIT"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Panel27
        '
        Me.Panel27.Controls.Add(Me.Panel40)
        Me.Panel27.Controls.Add(Me.CheckBox26)
        Me.Panel27.Controls.Add(Me.Button16)
        Me.Panel27.Location = New System.Drawing.Point(437, 345)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(211, 165)
        Me.Panel27.TabIndex = 25
        '
        'Panel40
        '
        Me.Panel40.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel40.Controls.Add(Me.optionSRCheckDelta)
        Me.Panel40.Controls.Add(Me.optionSRCheckRegression)
        Me.Panel40.Controls.Add(Me.optionSRCheckFull)
        Me.Panel40.ForeColor = System.Drawing.Color.Purple
        Me.Panel40.Location = New System.Drawing.Point(5, 132)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(200, 30)
        Me.Panel40.TabIndex = 13
        '
        'optionSRCheckDelta
        '
        Me.optionSRCheckDelta.AutoSize = True
        Me.optionSRCheckDelta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSRCheckDelta.Location = New System.Drawing.Point(150, 5)
        Me.optionSRCheckDelta.Name = "optionSRCheckDelta"
        Me.optionSRCheckDelta.Size = New System.Drawing.Size(41, 21)
        Me.optionSRCheckDelta.TabIndex = 2
        Me.optionSRCheckDelta.Text = "D"
        Me.optionSRCheckDelta.UseVisualStyleBackColor = True
        '
        'optionSRCheckRegression
        '
        Me.optionSRCheckRegression.AutoSize = True
        Me.optionSRCheckRegression.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSRCheckRegression.Location = New System.Drawing.Point(86, 5)
        Me.optionSRCheckRegression.Name = "optionSRCheckRegression"
        Me.optionSRCheckRegression.Size = New System.Drawing.Size(41, 21)
        Me.optionSRCheckRegression.TabIndex = 1
        Me.optionSRCheckRegression.Text = "R"
        Me.optionSRCheckRegression.UseVisualStyleBackColor = True
        '
        'optionSRCheckFull
        '
        Me.optionSRCheckFull.AutoSize = True
        Me.optionSRCheckFull.Cursor = System.Windows.Forms.Cursors.Hand
        Me.optionSRCheckFull.Location = New System.Drawing.Point(15, 5)
        Me.optionSRCheckFull.Name = "optionSRCheckFull"
        Me.optionSRCheckFull.Size = New System.Drawing.Size(39, 21)
        Me.optionSRCheckFull.TabIndex = 0
        Me.optionSRCheckFull.Text = "F"
        Me.optionSRCheckFull.UseVisualStyleBackColor = True
        '
        'CheckBox26
        '
        Me.CheckBox26.AutoSize = True
        Me.CheckBox26.Location = New System.Drawing.Point(871, 345)
        Me.CheckBox26.Name = "CheckBox26"
        Me.CheckBox26.Size = New System.Drawing.Size(118, 21)
        Me.CheckBox26.TabIndex = 0
        Me.CheckBox26.Text = "CheckBox26"
        Me.CheckBox26.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.ForeColor = System.Drawing.Color.Purple
        Me.Button16.Location = New System.Drawing.Point(0, 0)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(211, 165)
        Me.Button16.TabIndex = 12
        Me.Button16.Text = "SR CHECK"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Controls.Add(Me.TabPage11)
        Me.TabControl1.Controls.Add(Me.TabPage12)
        Me.TabControl1.Controls.Add(Me.TabPage49)
        Me.TabControl1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.ItemSize = New System.Drawing.Size(50, 10)
        Me.TabControl1.Location = New System.Drawing.Point(3, 605)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1146, 277)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.TabControl2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.optionLabTDCOM)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(3, 219)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1130, 35)
        Me.Panel1.TabIndex = 1
        '
        'optionLabTDCOM
        '
        Me.optionLabTDCOM.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTDCOM.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTDCOM.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTDCOM.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTDCOM.Name = "optionLabTDCOM"
        Me.optionLabTDCOM.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTDCOM.TabIndex = 14
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(108, 8)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(117, 20)
        Me.Label18.TabIndex = 14
        Me.Label18.Text = "LabT_DCOM"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage13)
        Me.TabControl2.Controls.Add(Me.TabPage14)
        Me.TabControl2.Controls.Add(Me.TabPage15)
        Me.TabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TabControl2.Location = New System.Drawing.Point(3, 3)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl2.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl2.TabIndex = 0
        '
        'TabPage13
        '
        Me.TabPage13.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage13.Controls.Add(Me.optionDefectStateDCOMFull)
        Me.TabPage13.Controls.Add(Me.Label39)
        Me.TabPage13.Controls.Add(Me.Label16)
        Me.TabPage13.Controls.Add(Me.optionDefectIdDCOMFull)
        Me.TabPage13.Controls.Add(Me.Label17)
        Me.TabPage13.Controls.Add(Me.optionDefectKindDCOMFull)
        Me.TabPage13.Controls.Add(Me.Label14)
        Me.TabPage13.Controls.Add(Me.optionPtIdDCOMFull)
        Me.TabPage13.Controls.Add(Me.Label15)
        Me.TabPage13.Controls.Add(Me.optionFailedDCOMFull)
        Me.TabPage13.Controls.Add(Me.Label13)
        Me.TabPage13.Controls.Add(Me.optionPassedDCOMFull)
        Me.TabPage13.Controls.Add(Me.optionPtStateDCOMFull)
        Me.TabPage13.Controls.Add(Me.Label12)
        Me.TabPage13.Controls.Add(Me.optionVersionDCOMFull)
        Me.TabPage13.Controls.Add(Me.Label11)
        Me.TabPage13.Location = New System.Drawing.Point(4, 25)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage13.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage13.TabIndex = 0
        Me.TabPage13.Text = "FULL "
        '
        'optionDefectStateDCOMFull
        '
        Me.optionDefectStateDCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateDCOMFull.FormattingEnabled = True
        Me.optionDefectStateDCOMFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateDCOMFull.Name = "optionDefectStateDCOMFull"
        Me.optionDefectStateDCOMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateDCOMFull.TabIndex = 16
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(762, 144)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(53, 20)
        Me.Label39.TabIndex = 15
        Me.Label39.Text = "State"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(104, 141)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(86, 20)
        Me.Label16.TabIndex = 13
        Me.Label16.Text = "Defect id"
        '
        'optionDefectIdDCOMFull
        '
        Me.optionDefectIdDCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdDCOMFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdDCOMFull.Name = "optionDefectIdDCOMFull"
        Me.optionDefectIdDCOMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdDCOMFull.TabIndex = 12
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(463, 142)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(46, 20)
        Me.Label17.TabIndex = 11
        Me.Label17.Text = "Kind"
        '
        'optionDefectKindDCOMFull
        '
        Me.optionDefectKindDCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindDCOMFull.FormattingEnabled = True
        Me.optionDefectKindDCOMFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindDCOMFull.Name = "optionDefectKindDCOMFull"
        Me.optionDefectKindDCOMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindDCOMFull.TabIndex = 10
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(104, 88)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 20)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "PT id"
        '
        'optionPtIdDCOMFull
        '
        Me.optionPtIdDCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdDCOMFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdDCOMFull.Name = "optionPtIdDCOMFull"
        Me.optionPtIdDCOMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdDCOMFull.TabIndex = 8
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(463, 92)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(53, 20)
        Me.Label15.TabIndex = 7
        Me.Label15.Text = "State"
        '
        'optionFailedDCOMFull
        '
        Me.optionFailedDCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedDCOMFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedDCOMFull.Name = "optionFailedDCOMFull"
        Me.optionFailedDCOMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedDCOMFull.TabIndex = 6
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(762, 42)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(60, 20)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "Failed"
        '
        'optionPassedDCOMFull
        '
        Me.optionPassedDCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedDCOMFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedDCOMFull.Name = "optionPassedDCOMFull"
        Me.optionPassedDCOMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedDCOMFull.TabIndex = 4
        '
        'optionPtStateDCOMFull
        '
        Me.optionPtStateDCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateDCOMFull.FormattingEnabled = True
        Me.optionPtStateDCOMFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateDCOMFull.Name = "optionPtStateDCOMFull"
        Me.optionPtStateDCOMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateDCOMFull.TabIndex = 3
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(463, 40)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(71, 20)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Passed"
        '
        'optionVersionDCOMFull
        '
        Me.optionVersionDCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionDCOMFull.FormattingEnabled = True
        Me.optionVersionDCOMFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionDCOMFull.Name = "optionVersionDCOMFull"
        Me.optionVersionDCOMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionDCOMFull.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(104, 37)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 20)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Version"
        '
        'TabPage14
        '
        Me.TabPage14.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage14.Controls.Add(Me.optionDefectStateDCOMRegression)
        Me.TabPage14.Controls.Add(Me.Label25)
        Me.TabPage14.Controls.Add(Me.Label26)
        Me.TabPage14.Controls.Add(Me.optionDefectIdDCOMRegression)
        Me.TabPage14.Controls.Add(Me.Label27)
        Me.TabPage14.Controls.Add(Me.optionDefectKindDCOMRegression)
        Me.TabPage14.Controls.Add(Me.Label28)
        Me.TabPage14.Controls.Add(Me.optionPtIdDCOMRegression)
        Me.TabPage14.Controls.Add(Me.Label29)
        Me.TabPage14.Controls.Add(Me.optionFailedDCOMRegression)
        Me.TabPage14.Controls.Add(Me.Label30)
        Me.TabPage14.Controls.Add(Me.optionPassedDCOMRegression)
        Me.TabPage14.Controls.Add(Me.optionPtStateDCOMRegression)
        Me.TabPage14.Controls.Add(Me.Label31)
        Me.TabPage14.Controls.Add(Me.optionVersionDCOMRegression)
        Me.TabPage14.Controls.Add(Me.Label32)
        Me.TabPage14.Location = New System.Drawing.Point(4, 25)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage14.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage14.TabIndex = 1
        Me.TabPage14.Text = "REGRESSION"
        '
        'optionDefectStateDCOMRegression
        '
        Me.optionDefectStateDCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateDCOMRegression.FormattingEnabled = True
        Me.optionDefectStateDCOMRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateDCOMRegression.Name = "optionDefectStateDCOMRegression"
        Me.optionDefectStateDCOMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateDCOMRegression.TabIndex = 32
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(762, 144)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(53, 20)
        Me.Label25.TabIndex = 31
        Me.Label25.Text = "State"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(104, 141)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(86, 20)
        Me.Label26.TabIndex = 30
        Me.Label26.Text = "Defect id"
        '
        'optionDefectIdDCOMRegression
        '
        Me.optionDefectIdDCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdDCOMRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdDCOMRegression.Name = "optionDefectIdDCOMRegression"
        Me.optionDefectIdDCOMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdDCOMRegression.TabIndex = 29
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(463, 142)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(46, 20)
        Me.Label27.TabIndex = 28
        Me.Label27.Text = "Kind"
        '
        'optionDefectKindDCOMRegression
        '
        Me.optionDefectKindDCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindDCOMRegression.FormattingEnabled = True
        Me.optionDefectKindDCOMRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindDCOMRegression.Name = "optionDefectKindDCOMRegression"
        Me.optionDefectKindDCOMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindDCOMRegression.TabIndex = 27
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(104, 88)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(53, 20)
        Me.Label28.TabIndex = 26
        Me.Label28.Text = "PT id"
        '
        'optionPtIdDCOMRegression
        '
        Me.optionPtIdDCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdDCOMRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdDCOMRegression.Name = "optionPtIdDCOMRegression"
        Me.optionPtIdDCOMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdDCOMRegression.TabIndex = 25
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(463, 92)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(53, 20)
        Me.Label29.TabIndex = 24
        Me.Label29.Text = "State"
        '
        'optionFailedDCOMRegression
        '
        Me.optionFailedDCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedDCOMRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedDCOMRegression.Name = "optionFailedDCOMRegression"
        Me.optionFailedDCOMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedDCOMRegression.TabIndex = 23
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(762, 42)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(60, 20)
        Me.Label30.TabIndex = 22
        Me.Label30.Text = "Failed"
        '
        'optionPassedDCOMRegression
        '
        Me.optionPassedDCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedDCOMRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedDCOMRegression.Name = "optionPassedDCOMRegression"
        Me.optionPassedDCOMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedDCOMRegression.TabIndex = 21
        '
        'optionPtStateDCOMRegression
        '
        Me.optionPtStateDCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateDCOMRegression.FormattingEnabled = True
        Me.optionPtStateDCOMRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateDCOMRegression.Name = "optionPtStateDCOMRegression"
        Me.optionPtStateDCOMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateDCOMRegression.TabIndex = 20
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(463, 40)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(71, 20)
        Me.Label31.TabIndex = 19
        Me.Label31.Text = "Passed"
        '
        'optionVersionDCOMRegression
        '
        Me.optionVersionDCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionDCOMRegression.FormattingEnabled = True
        Me.optionVersionDCOMRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionDCOMRegression.Name = "optionVersionDCOMRegression"
        Me.optionVersionDCOMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionDCOMRegression.TabIndex = 18
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(104, 37)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(73, 20)
        Me.Label32.TabIndex = 17
        Me.Label32.Text = "Version"
        '
        'TabPage15
        '
        Me.TabPage15.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage15.Controls.Add(Me.optionDefectStateDCOMDelta)
        Me.TabPage15.Controls.Add(Me.Label33)
        Me.TabPage15.Controls.Add(Me.Label34)
        Me.TabPage15.Controls.Add(Me.optionDefectIdDCOMDelta)
        Me.TabPage15.Controls.Add(Me.Label35)
        Me.TabPage15.Controls.Add(Me.optionDefectKindDCOMDelta)
        Me.TabPage15.Controls.Add(Me.Label36)
        Me.TabPage15.Controls.Add(Me.optionPtIdDCOMDelta)
        Me.TabPage15.Controls.Add(Me.Label37)
        Me.TabPage15.Controls.Add(Me.optionFailedDCOMDelta)
        Me.TabPage15.Controls.Add(Me.Label38)
        Me.TabPage15.Controls.Add(Me.optionPassedDCOMDelta)
        Me.TabPage15.Controls.Add(Me.optionPtStateDCOMDelta)
        Me.TabPage15.Controls.Add(Me.Label40)
        Me.TabPage15.Controls.Add(Me.optionVersionDCOMDelta)
        Me.TabPage15.Controls.Add(Me.Label41)
        Me.TabPage15.Location = New System.Drawing.Point(4, 25)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage15.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage15.TabIndex = 2
        Me.TabPage15.Text = "DELTA"
        '
        'optionDefectStateDCOMDelta
        '
        Me.optionDefectStateDCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateDCOMDelta.FormattingEnabled = True
        Me.optionDefectStateDCOMDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateDCOMDelta.Name = "optionDefectStateDCOMDelta"
        Me.optionDefectStateDCOMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateDCOMDelta.TabIndex = 32
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(762, 144)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(53, 20)
        Me.Label33.TabIndex = 31
        Me.Label33.Text = "State"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(104, 141)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(86, 20)
        Me.Label34.TabIndex = 30
        Me.Label34.Text = "Defect id"
        '
        'optionDefectIdDCOMDelta
        '
        Me.optionDefectIdDCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdDCOMDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdDCOMDelta.Name = "optionDefectIdDCOMDelta"
        Me.optionDefectIdDCOMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdDCOMDelta.TabIndex = 29
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(463, 142)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(46, 20)
        Me.Label35.TabIndex = 28
        Me.Label35.Text = "Kind"
        '
        'optionDefectKindDCOMDelta
        '
        Me.optionDefectKindDCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindDCOMDelta.FormattingEnabled = True
        Me.optionDefectKindDCOMDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindDCOMDelta.Name = "optionDefectKindDCOMDelta"
        Me.optionDefectKindDCOMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindDCOMDelta.TabIndex = 27
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(104, 88)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(53, 20)
        Me.Label36.TabIndex = 26
        Me.Label36.Text = "PT id"
        '
        'optionPtIdDCOMDelta
        '
        Me.optionPtIdDCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdDCOMDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdDCOMDelta.Name = "optionPtIdDCOMDelta"
        Me.optionPtIdDCOMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdDCOMDelta.TabIndex = 25
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(463, 92)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(53, 20)
        Me.Label37.TabIndex = 24
        Me.Label37.Text = "State"
        '
        'optionFailedDCOMDelta
        '
        Me.optionFailedDCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedDCOMDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedDCOMDelta.Name = "optionFailedDCOMDelta"
        Me.optionFailedDCOMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedDCOMDelta.TabIndex = 23
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(762, 42)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(60, 20)
        Me.Label38.TabIndex = 22
        Me.Label38.Text = "Failed"
        '
        'optionPassedDCOMDelta
        '
        Me.optionPassedDCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedDCOMDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedDCOMDelta.Name = "optionPassedDCOMDelta"
        Me.optionPassedDCOMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedDCOMDelta.TabIndex = 21
        '
        'optionPtStateDCOMDelta
        '
        Me.optionPtStateDCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateDCOMDelta.FormattingEnabled = True
        Me.optionPtStateDCOMDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateDCOMDelta.Name = "optionPtStateDCOMDelta"
        Me.optionPtStateDCOMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateDCOMDelta.TabIndex = 20
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(463, 40)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(71, 20)
        Me.Label40.TabIndex = 19
        Me.Label40.Text = "Passed"
        '
        'optionVersionDCOMDelta
        '
        Me.optionVersionDCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionDCOMDelta.FormattingEnabled = True
        Me.optionVersionDCOMDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionDCOMDelta.Name = "optionVersionDCOMDelta"
        Me.optionVersionDCOMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionDCOMDelta.TabIndex = 18
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(104, 37)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(73, 20)
        Me.Label41.TabIndex = 17
        Me.Label41.Text = "Version"
        '
        'TabPage2
        '
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.Panel3)
        Me.TabPage2.Controls.Add(Me.TabControl3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.optionLabTEM)
        Me.Panel3.Controls.Add(Me.Label42)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(3, 219)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1130, 35)
        Me.Panel3.TabIndex = 3
        '
        'optionLabTEM
        '
        Me.optionLabTEM.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTEM.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTEM.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTEM.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTEM.Name = "optionLabTEM"
        Me.optionLabTEM.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTEM.TabIndex = 14
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(108, 8)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(88, 20)
        Me.Label42.TabIndex = 14
        Me.Label42.Text = "LabT_EM"
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage16)
        Me.TabControl3.Controls.Add(Me.TabPage17)
        Me.TabControl3.Controls.Add(Me.TabPage18)
        Me.TabControl3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl3.Location = New System.Drawing.Point(3, 3)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl3.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl3.TabIndex = 2
        '
        'TabPage16
        '
        Me.TabPage16.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage16.Controls.Add(Me.optionDefectStateEMFull)
        Me.TabPage16.Controls.Add(Me.Label43)
        Me.TabPage16.Controls.Add(Me.Label44)
        Me.TabPage16.Controls.Add(Me.optionDefectIdEMFull)
        Me.TabPage16.Controls.Add(Me.Label45)
        Me.TabPage16.Controls.Add(Me.optionDefectKindEMFull)
        Me.TabPage16.Controls.Add(Me.Label46)
        Me.TabPage16.Controls.Add(Me.optionPtIdEMFull)
        Me.TabPage16.Controls.Add(Me.Label47)
        Me.TabPage16.Controls.Add(Me.optionFailedEMFull)
        Me.TabPage16.Controls.Add(Me.Label48)
        Me.TabPage16.Controls.Add(Me.optionPassedEMFull)
        Me.TabPage16.Controls.Add(Me.optionPtStateEMFull)
        Me.TabPage16.Controls.Add(Me.Label49)
        Me.TabPage16.Controls.Add(Me.optionVersionEMFull)
        Me.TabPage16.Controls.Add(Me.Label50)
        Me.TabPage16.Location = New System.Drawing.Point(4, 25)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage16.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage16.TabIndex = 0
        Me.TabPage16.Text = "FULL "
        '
        'optionDefectStateEMFull
        '
        Me.optionDefectStateEMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateEMFull.FormattingEnabled = True
        Me.optionDefectStateEMFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateEMFull.Name = "optionDefectStateEMFull"
        Me.optionDefectStateEMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateEMFull.TabIndex = 16
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(762, 144)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(53, 20)
        Me.Label43.TabIndex = 15
        Me.Label43.Text = "State"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(104, 141)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(86, 20)
        Me.Label44.TabIndex = 13
        Me.Label44.Text = "Defect id"
        '
        'optionDefectIdEMFull
        '
        Me.optionDefectIdEMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdEMFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdEMFull.Name = "optionDefectIdEMFull"
        Me.optionDefectIdEMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdEMFull.TabIndex = 12
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(463, 142)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(46, 20)
        Me.Label45.TabIndex = 11
        Me.Label45.Text = "Kind"
        '
        'optionDefectKindEMFull
        '
        Me.optionDefectKindEMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindEMFull.FormattingEnabled = True
        Me.optionDefectKindEMFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindEMFull.Name = "optionDefectKindEMFull"
        Me.optionDefectKindEMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindEMFull.TabIndex = 10
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(104, 88)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(53, 20)
        Me.Label46.TabIndex = 9
        Me.Label46.Text = "PT id"
        '
        'optionPtIdEMFull
        '
        Me.optionPtIdEMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdEMFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdEMFull.Name = "optionPtIdEMFull"
        Me.optionPtIdEMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdEMFull.TabIndex = 8
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(463, 92)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(53, 20)
        Me.Label47.TabIndex = 7
        Me.Label47.Text = "State"
        '
        'optionFailedEMFull
        '
        Me.optionFailedEMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedEMFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedEMFull.Name = "optionFailedEMFull"
        Me.optionFailedEMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedEMFull.TabIndex = 6
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(762, 42)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(60, 20)
        Me.Label48.TabIndex = 5
        Me.Label48.Text = "Failed"
        '
        'optionPassedEMFull
        '
        Me.optionPassedEMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedEMFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedEMFull.Name = "optionPassedEMFull"
        Me.optionPassedEMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedEMFull.TabIndex = 4
        '
        'optionPtStateEMFull
        '
        Me.optionPtStateEMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateEMFull.FormattingEnabled = True
        Me.optionPtStateEMFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateEMFull.Name = "optionPtStateEMFull"
        Me.optionPtStateEMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateEMFull.TabIndex = 3
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(463, 40)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(71, 20)
        Me.Label49.TabIndex = 2
        Me.Label49.Text = "Passed"
        '
        'optionVersionEMFull
        '
        Me.optionVersionEMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionEMFull.FormattingEnabled = True
        Me.optionVersionEMFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionEMFull.Name = "optionVersionEMFull"
        Me.optionVersionEMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionEMFull.TabIndex = 1
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(104, 37)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(73, 20)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "Version"
        '
        'TabPage17
        '
        Me.TabPage17.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage17.Controls.Add(Me.optionDefectStateEMRegression)
        Me.TabPage17.Controls.Add(Me.Label51)
        Me.TabPage17.Controls.Add(Me.Label52)
        Me.TabPage17.Controls.Add(Me.optionDefectIdEMRegression)
        Me.TabPage17.Controls.Add(Me.Label53)
        Me.TabPage17.Controls.Add(Me.optionDefectKindEMRegression)
        Me.TabPage17.Controls.Add(Me.Label54)
        Me.TabPage17.Controls.Add(Me.optionPtIdEMRegression)
        Me.TabPage17.Controls.Add(Me.Label55)
        Me.TabPage17.Controls.Add(Me.optionFailedEMRegression)
        Me.TabPage17.Controls.Add(Me.Label56)
        Me.TabPage17.Controls.Add(Me.optionPassedEMRegression)
        Me.TabPage17.Controls.Add(Me.optionPtStateEMRegression)
        Me.TabPage17.Controls.Add(Me.Label57)
        Me.TabPage17.Controls.Add(Me.optionVersionEMRegression)
        Me.TabPage17.Controls.Add(Me.Label58)
        Me.TabPage17.Location = New System.Drawing.Point(4, 25)
        Me.TabPage17.Name = "TabPage17"
        Me.TabPage17.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage17.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage17.TabIndex = 1
        Me.TabPage17.Text = "REGRESSION"
        '
        'optionDefectStateEMRegression
        '
        Me.optionDefectStateEMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateEMRegression.FormattingEnabled = True
        Me.optionDefectStateEMRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateEMRegression.Name = "optionDefectStateEMRegression"
        Me.optionDefectStateEMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateEMRegression.TabIndex = 32
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(762, 144)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(53, 20)
        Me.Label51.TabIndex = 31
        Me.Label51.Text = "State"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(104, 141)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(86, 20)
        Me.Label52.TabIndex = 30
        Me.Label52.Text = "Defect id"
        '
        'optionDefectIdEMRegression
        '
        Me.optionDefectIdEMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdEMRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdEMRegression.Name = "optionDefectIdEMRegression"
        Me.optionDefectIdEMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdEMRegression.TabIndex = 29
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(463, 142)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(46, 20)
        Me.Label53.TabIndex = 28
        Me.Label53.Text = "Kind"
        '
        'optionDefectKindEMRegression
        '
        Me.optionDefectKindEMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindEMRegression.FormattingEnabled = True
        Me.optionDefectKindEMRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindEMRegression.Name = "optionDefectKindEMRegression"
        Me.optionDefectKindEMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindEMRegression.TabIndex = 27
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(104, 88)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(53, 20)
        Me.Label54.TabIndex = 26
        Me.Label54.Text = "PT id"
        '
        'optionPtIdEMRegression
        '
        Me.optionPtIdEMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdEMRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdEMRegression.Name = "optionPtIdEMRegression"
        Me.optionPtIdEMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdEMRegression.TabIndex = 25
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(463, 92)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(53, 20)
        Me.Label55.TabIndex = 24
        Me.Label55.Text = "State"
        '
        'optionFailedEMRegression
        '
        Me.optionFailedEMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedEMRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedEMRegression.Name = "optionFailedEMRegression"
        Me.optionFailedEMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedEMRegression.TabIndex = 23
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(762, 42)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(60, 20)
        Me.Label56.TabIndex = 22
        Me.Label56.Text = "Failed"
        '
        'optionPassedEMRegression
        '
        Me.optionPassedEMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedEMRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedEMRegression.Name = "optionPassedEMRegression"
        Me.optionPassedEMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedEMRegression.TabIndex = 21
        '
        'optionPtStateEMRegression
        '
        Me.optionPtStateEMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateEMRegression.FormattingEnabled = True
        Me.optionPtStateEMRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateEMRegression.Name = "optionPtStateEMRegression"
        Me.optionPtStateEMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateEMRegression.TabIndex = 20
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(463, 40)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(71, 20)
        Me.Label57.TabIndex = 19
        Me.Label57.Text = "Passed"
        '
        'optionVersionEMRegression
        '
        Me.optionVersionEMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionEMRegression.FormattingEnabled = True
        Me.optionVersionEMRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionEMRegression.Name = "optionVersionEMRegression"
        Me.optionVersionEMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionEMRegression.TabIndex = 18
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(104, 37)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(73, 20)
        Me.Label58.TabIndex = 17
        Me.Label58.Text = "Version"
        '
        'TabPage18
        '
        Me.TabPage18.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage18.Controls.Add(Me.optionDefectStateEMDelta)
        Me.TabPage18.Controls.Add(Me.Label59)
        Me.TabPage18.Controls.Add(Me.Label60)
        Me.TabPage18.Controls.Add(Me.optionDefectIdEMDelta)
        Me.TabPage18.Controls.Add(Me.Label61)
        Me.TabPage18.Controls.Add(Me.optionDefectKindEMDelta)
        Me.TabPage18.Controls.Add(Me.Label62)
        Me.TabPage18.Controls.Add(Me.optionPtIdEMDelta)
        Me.TabPage18.Controls.Add(Me.Label63)
        Me.TabPage18.Controls.Add(Me.optionFailedEMDelta)
        Me.TabPage18.Controls.Add(Me.Label64)
        Me.TabPage18.Controls.Add(Me.optionPassedEMDelta)
        Me.TabPage18.Controls.Add(Me.optionPtStateEMDelta)
        Me.TabPage18.Controls.Add(Me.Label65)
        Me.TabPage18.Controls.Add(Me.optionVersionEMDelta)
        Me.TabPage18.Controls.Add(Me.Label66)
        Me.TabPage18.Location = New System.Drawing.Point(4, 25)
        Me.TabPage18.Name = "TabPage18"
        Me.TabPage18.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage18.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage18.TabIndex = 2
        Me.TabPage18.Text = "DELTA"
        '
        'optionDefectStateEMDelta
        '
        Me.optionDefectStateEMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateEMDelta.FormattingEnabled = True
        Me.optionDefectStateEMDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateEMDelta.Name = "optionDefectStateEMDelta"
        Me.optionDefectStateEMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateEMDelta.TabIndex = 32
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(762, 144)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(53, 20)
        Me.Label59.TabIndex = 31
        Me.Label59.Text = "State"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(104, 141)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(86, 20)
        Me.Label60.TabIndex = 30
        Me.Label60.Text = "Defect id"
        '
        'optionDefectIdEMDelta
        '
        Me.optionDefectIdEMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdEMDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdEMDelta.Name = "optionDefectIdEMDelta"
        Me.optionDefectIdEMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdEMDelta.TabIndex = 29
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(463, 142)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(46, 20)
        Me.Label61.TabIndex = 28
        Me.Label61.Text = "Kind"
        '
        'optionDefectKindEMDelta
        '
        Me.optionDefectKindEMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindEMDelta.FormattingEnabled = True
        Me.optionDefectKindEMDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindEMDelta.Name = "optionDefectKindEMDelta"
        Me.optionDefectKindEMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindEMDelta.TabIndex = 27
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(104, 88)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(53, 20)
        Me.Label62.TabIndex = 26
        Me.Label62.Text = "PT id"
        '
        'optionPtIdEMDelta
        '
        Me.optionPtIdEMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdEMDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdEMDelta.Name = "optionPtIdEMDelta"
        Me.optionPtIdEMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdEMDelta.TabIndex = 25
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(463, 92)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(53, 20)
        Me.Label63.TabIndex = 24
        Me.Label63.Text = "State"
        '
        'optionFailedEMDelta
        '
        Me.optionFailedEMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedEMDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedEMDelta.Name = "optionFailedEMDelta"
        Me.optionFailedEMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedEMDelta.TabIndex = 23
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(762, 42)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(60, 20)
        Me.Label64.TabIndex = 22
        Me.Label64.Text = "Failed"
        '
        'optionPassedEMDelta
        '
        Me.optionPassedEMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedEMDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedEMDelta.Name = "optionPassedEMDelta"
        Me.optionPassedEMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedEMDelta.TabIndex = 21
        '
        'optionPtStateEMDelta
        '
        Me.optionPtStateEMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateEMDelta.FormattingEnabled = True
        Me.optionPtStateEMDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateEMDelta.Name = "optionPtStateEMDelta"
        Me.optionPtStateEMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateEMDelta.TabIndex = 20
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(463, 40)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(71, 20)
        Me.Label65.TabIndex = 19
        Me.Label65.Text = "Passed"
        '
        'optionVersionEMDelta
        '
        Me.optionVersionEMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionEMDelta.FormattingEnabled = True
        Me.optionVersionEMDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionEMDelta.Name = "optionVersionEMDelta"
        Me.optionVersionEMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionEMDelta.TabIndex = 18
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(104, 37)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(73, 20)
        Me.Label66.TabIndex = 17
        Me.Label66.Text = "Version"
        '
        'TabPage3
        '
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage3.Controls.Add(Me.Panel4)
        Me.TabPage3.Controls.Add(Me.TabControl4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "TabPage3"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.optionLabTCOM)
        Me.Panel4.Controls.Add(Me.Label67)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(3, 219)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1130, 35)
        Me.Panel4.TabIndex = 3
        '
        'optionLabTCOM
        '
        Me.optionLabTCOM.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTCOM.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTCOM.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTCOM.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTCOM.Name = "optionLabTCOM"
        Me.optionLabTCOM.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTCOM.TabIndex = 14
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(108, 8)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(103, 20)
        Me.Label67.TabIndex = 14
        Me.Label67.Text = "LabT_COM"
        '
        'TabControl4
        '
        Me.TabControl4.Controls.Add(Me.TabPage19)
        Me.TabControl4.Controls.Add(Me.TabPage20)
        Me.TabControl4.Controls.Add(Me.TabPage21)
        Me.TabControl4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl4.Location = New System.Drawing.Point(3, 3)
        Me.TabControl4.Name = "TabControl4"
        Me.TabControl4.SelectedIndex = 0
        Me.TabControl4.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl4.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl4.TabIndex = 2
        '
        'TabPage19
        '
        Me.TabPage19.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage19.Controls.Add(Me.optionDefectStateCOMFull)
        Me.TabPage19.Controls.Add(Me.Label68)
        Me.TabPage19.Controls.Add(Me.Label69)
        Me.TabPage19.Controls.Add(Me.optionDefectIdCOMFull)
        Me.TabPage19.Controls.Add(Me.Label70)
        Me.TabPage19.Controls.Add(Me.optionDefectKindCOMFull)
        Me.TabPage19.Controls.Add(Me.Label71)
        Me.TabPage19.Controls.Add(Me.optionPtIdCOMFull)
        Me.TabPage19.Controls.Add(Me.Label72)
        Me.TabPage19.Controls.Add(Me.optionFailedCOMFull)
        Me.TabPage19.Controls.Add(Me.Label73)
        Me.TabPage19.Controls.Add(Me.optionPassedCOMFull)
        Me.TabPage19.Controls.Add(Me.optionPtStateCOMFull)
        Me.TabPage19.Controls.Add(Me.Label74)
        Me.TabPage19.Controls.Add(Me.optionVersionCOMFull)
        Me.TabPage19.Controls.Add(Me.Label75)
        Me.TabPage19.Location = New System.Drawing.Point(4, 25)
        Me.TabPage19.Name = "TabPage19"
        Me.TabPage19.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage19.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage19.TabIndex = 0
        Me.TabPage19.Text = "FULL "
        '
        'optionDefectStateCOMFull
        '
        Me.optionDefectStateCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateCOMFull.FormattingEnabled = True
        Me.optionDefectStateCOMFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateCOMFull.Name = "optionDefectStateCOMFull"
        Me.optionDefectStateCOMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateCOMFull.TabIndex = 16
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(762, 144)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(53, 20)
        Me.Label68.TabIndex = 15
        Me.Label68.Text = "State"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(104, 141)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(86, 20)
        Me.Label69.TabIndex = 13
        Me.Label69.Text = "Defect id"
        '
        'optionDefectIdCOMFull
        '
        Me.optionDefectIdCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdCOMFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdCOMFull.Name = "optionDefectIdCOMFull"
        Me.optionDefectIdCOMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdCOMFull.TabIndex = 12
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(463, 142)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(46, 20)
        Me.Label70.TabIndex = 11
        Me.Label70.Text = "Kind"
        '
        'optionDefectKindCOMFull
        '
        Me.optionDefectKindCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindCOMFull.FormattingEnabled = True
        Me.optionDefectKindCOMFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindCOMFull.Name = "optionDefectKindCOMFull"
        Me.optionDefectKindCOMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindCOMFull.TabIndex = 10
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(104, 88)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(53, 20)
        Me.Label71.TabIndex = 9
        Me.Label71.Text = "PT id"
        '
        'optionPtIdCOMFull
        '
        Me.optionPtIdCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdCOMFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdCOMFull.Name = "optionPtIdCOMFull"
        Me.optionPtIdCOMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdCOMFull.TabIndex = 8
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.Location = New System.Drawing.Point(463, 92)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(53, 20)
        Me.Label72.TabIndex = 7
        Me.Label72.Text = "State"
        '
        'optionFailedCOMFull
        '
        Me.optionFailedCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedCOMFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedCOMFull.Name = "optionFailedCOMFull"
        Me.optionFailedCOMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedCOMFull.TabIndex = 6
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(762, 42)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(60, 20)
        Me.Label73.TabIndex = 5
        Me.Label73.Text = "Failed"
        '
        'optionPassedCOMFull
        '
        Me.optionPassedCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedCOMFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedCOMFull.Name = "optionPassedCOMFull"
        Me.optionPassedCOMFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedCOMFull.TabIndex = 4
        '
        'optionPtStateCOMFull
        '
        Me.optionPtStateCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateCOMFull.FormattingEnabled = True
        Me.optionPtStateCOMFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateCOMFull.Name = "optionPtStateCOMFull"
        Me.optionPtStateCOMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateCOMFull.TabIndex = 3
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(463, 40)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(71, 20)
        Me.Label74.TabIndex = 2
        Me.Label74.Text = "Passed"
        '
        'optionVersionCOMFull
        '
        Me.optionVersionCOMFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionCOMFull.FormattingEnabled = True
        Me.optionVersionCOMFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionCOMFull.Name = "optionVersionCOMFull"
        Me.optionVersionCOMFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionCOMFull.TabIndex = 1
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(104, 37)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(73, 20)
        Me.Label75.TabIndex = 0
        Me.Label75.Text = "Version"
        '
        'TabPage20
        '
        Me.TabPage20.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage20.Controls.Add(Me.optionDefectStateCOMRegression)
        Me.TabPage20.Controls.Add(Me.Label76)
        Me.TabPage20.Controls.Add(Me.Label77)
        Me.TabPage20.Controls.Add(Me.optionDefectIdCOMRegression)
        Me.TabPage20.Controls.Add(Me.Label78)
        Me.TabPage20.Controls.Add(Me.optionDefectKindCOMRegression)
        Me.TabPage20.Controls.Add(Me.Label79)
        Me.TabPage20.Controls.Add(Me.optionPtIdCOMRegression)
        Me.TabPage20.Controls.Add(Me.Label80)
        Me.TabPage20.Controls.Add(Me.optionFailedCOMRegression)
        Me.TabPage20.Controls.Add(Me.Label81)
        Me.TabPage20.Controls.Add(Me.optionPassedCOMRegression)
        Me.TabPage20.Controls.Add(Me.optionPtStateCOMRegression)
        Me.TabPage20.Controls.Add(Me.Label82)
        Me.TabPage20.Controls.Add(Me.optionVersionCOMRegression)
        Me.TabPage20.Controls.Add(Me.Label83)
        Me.TabPage20.Location = New System.Drawing.Point(4, 25)
        Me.TabPage20.Name = "TabPage20"
        Me.TabPage20.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage20.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage20.TabIndex = 1
        Me.TabPage20.Text = "REGRESSION"
        '
        'optionDefectStateCOMRegression
        '
        Me.optionDefectStateCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateCOMRegression.FormattingEnabled = True
        Me.optionDefectStateCOMRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateCOMRegression.Name = "optionDefectStateCOMRegression"
        Me.optionDefectStateCOMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateCOMRegression.TabIndex = 32
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(762, 144)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(53, 20)
        Me.Label76.TabIndex = 31
        Me.Label76.Text = "State"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(104, 141)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(86, 20)
        Me.Label77.TabIndex = 30
        Me.Label77.Text = "Defect id"
        '
        'optionDefectIdCOMRegression
        '
        Me.optionDefectIdCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdCOMRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdCOMRegression.Name = "optionDefectIdCOMRegression"
        Me.optionDefectIdCOMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdCOMRegression.TabIndex = 29
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(463, 142)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(46, 20)
        Me.Label78.TabIndex = 28
        Me.Label78.Text = "Kind"
        '
        'optionDefectKindCOMRegression
        '
        Me.optionDefectKindCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindCOMRegression.FormattingEnabled = True
        Me.optionDefectKindCOMRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindCOMRegression.Name = "optionDefectKindCOMRegression"
        Me.optionDefectKindCOMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindCOMRegression.TabIndex = 27
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(104, 88)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(53, 20)
        Me.Label79.TabIndex = 26
        Me.Label79.Text = "PT id"
        '
        'optionPtIdCOMRegression
        '
        Me.optionPtIdCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdCOMRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdCOMRegression.Name = "optionPtIdCOMRegression"
        Me.optionPtIdCOMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdCOMRegression.TabIndex = 25
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(463, 92)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(53, 20)
        Me.Label80.TabIndex = 24
        Me.Label80.Text = "State"
        '
        'optionFailedCOMRegression
        '
        Me.optionFailedCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedCOMRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedCOMRegression.Name = "optionFailedCOMRegression"
        Me.optionFailedCOMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedCOMRegression.TabIndex = 23
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.Location = New System.Drawing.Point(762, 42)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(60, 20)
        Me.Label81.TabIndex = 22
        Me.Label81.Text = "Failed"
        '
        'optionPassedCOMRegression
        '
        Me.optionPassedCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedCOMRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedCOMRegression.Name = "optionPassedCOMRegression"
        Me.optionPassedCOMRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedCOMRegression.TabIndex = 21
        '
        'optionPtStateCOMRegression
        '
        Me.optionPtStateCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateCOMRegression.FormattingEnabled = True
        Me.optionPtStateCOMRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateCOMRegression.Name = "optionPtStateCOMRegression"
        Me.optionPtStateCOMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateCOMRegression.TabIndex = 20
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(463, 40)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(71, 20)
        Me.Label82.TabIndex = 19
        Me.Label82.Text = "Passed"
        '
        'optionVersionCOMRegression
        '
        Me.optionVersionCOMRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionCOMRegression.FormattingEnabled = True
        Me.optionVersionCOMRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionCOMRegression.Name = "optionVersionCOMRegression"
        Me.optionVersionCOMRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionCOMRegression.TabIndex = 18
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(104, 37)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(73, 20)
        Me.Label83.TabIndex = 17
        Me.Label83.Text = "Version"
        '
        'TabPage21
        '
        Me.TabPage21.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage21.Controls.Add(Me.optionDefectStateCOMDelta)
        Me.TabPage21.Controls.Add(Me.Label84)
        Me.TabPage21.Controls.Add(Me.Label85)
        Me.TabPage21.Controls.Add(Me.optionDefectIdCOMDelta)
        Me.TabPage21.Controls.Add(Me.Label86)
        Me.TabPage21.Controls.Add(Me.optionDefectKindCOMDelta)
        Me.TabPage21.Controls.Add(Me.Label87)
        Me.TabPage21.Controls.Add(Me.optionPtIdCOMDelta)
        Me.TabPage21.Controls.Add(Me.Label88)
        Me.TabPage21.Controls.Add(Me.optionFailedCOMDelta)
        Me.TabPage21.Controls.Add(Me.Label89)
        Me.TabPage21.Controls.Add(Me.optionPassedCOMDelta)
        Me.TabPage21.Controls.Add(Me.optionPtStateCOMDelta)
        Me.TabPage21.Controls.Add(Me.Label90)
        Me.TabPage21.Controls.Add(Me.optionVersionCOMDelta)
        Me.TabPage21.Controls.Add(Me.Label91)
        Me.TabPage21.Location = New System.Drawing.Point(4, 25)
        Me.TabPage21.Name = "TabPage21"
        Me.TabPage21.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage21.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage21.TabIndex = 2
        Me.TabPage21.Text = "DELTA"
        '
        'optionDefectStateCOMDelta
        '
        Me.optionDefectStateCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateCOMDelta.FormattingEnabled = True
        Me.optionDefectStateCOMDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateCOMDelta.Name = "optionDefectStateCOMDelta"
        Me.optionDefectStateCOMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateCOMDelta.TabIndex = 32
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(762, 144)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(53, 20)
        Me.Label84.TabIndex = 31
        Me.Label84.Text = "State"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(104, 141)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(86, 20)
        Me.Label85.TabIndex = 30
        Me.Label85.Text = "Defect id"
        '
        'optionDefectIdCOMDelta
        '
        Me.optionDefectIdCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdCOMDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdCOMDelta.Name = "optionDefectIdCOMDelta"
        Me.optionDefectIdCOMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdCOMDelta.TabIndex = 29
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(463, 142)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(46, 20)
        Me.Label86.TabIndex = 28
        Me.Label86.Text = "Kind"
        '
        'optionDefectKindCOMDelta
        '
        Me.optionDefectKindCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindCOMDelta.FormattingEnabled = True
        Me.optionDefectKindCOMDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindCOMDelta.Name = "optionDefectKindCOMDelta"
        Me.optionDefectKindCOMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindCOMDelta.TabIndex = 27
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(104, 88)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(53, 20)
        Me.Label87.TabIndex = 26
        Me.Label87.Text = "PT id"
        '
        'optionPtIdCOMDelta
        '
        Me.optionPtIdCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdCOMDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdCOMDelta.Name = "optionPtIdCOMDelta"
        Me.optionPtIdCOMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdCOMDelta.TabIndex = 25
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(463, 92)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(53, 20)
        Me.Label88.TabIndex = 24
        Me.Label88.Text = "State"
        '
        'optionFailedCOMDelta
        '
        Me.optionFailedCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedCOMDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedCOMDelta.Name = "optionFailedCOMDelta"
        Me.optionFailedCOMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedCOMDelta.TabIndex = 23
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(762, 42)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(60, 20)
        Me.Label89.TabIndex = 22
        Me.Label89.Text = "Failed"
        '
        'optionPassedCOMDelta
        '
        Me.optionPassedCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedCOMDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedCOMDelta.Name = "optionPassedCOMDelta"
        Me.optionPassedCOMDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedCOMDelta.TabIndex = 21
        '
        'optionPtStateCOMDelta
        '
        Me.optionPtStateCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateCOMDelta.FormattingEnabled = True
        Me.optionPtStateCOMDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateCOMDelta.Name = "optionPtStateCOMDelta"
        Me.optionPtStateCOMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateCOMDelta.TabIndex = 20
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(463, 40)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(71, 20)
        Me.Label90.TabIndex = 19
        Me.Label90.Text = "Passed"
        '
        'optionVersionCOMDelta
        '
        Me.optionVersionCOMDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionCOMDelta.FormattingEnabled = True
        Me.optionVersionCOMDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionCOMDelta.Name = "optionVersionCOMDelta"
        Me.optionVersionCOMDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionCOMDelta.TabIndex = 18
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(104, 37)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(73, 20)
        Me.Label91.TabIndex = 17
        Me.Label91.Text = "Version"
        '
        'TabPage4
        '
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage4.Controls.Add(Me.Panel5)
        Me.TabPage4.Controls.Add(Me.TabControl5)
        Me.TabPage4.Location = New System.Drawing.Point(4, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "TabPage4"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.optionLabTLDW)
        Me.Panel5.Controls.Add(Me.Label92)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(3, 219)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1130, 35)
        Me.Panel5.TabIndex = 3
        '
        'optionLabTLDW
        '
        Me.optionLabTLDW.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTLDW.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTLDW.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTLDW.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTLDW.Name = "optionLabTLDW"
        Me.optionLabTLDW.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTLDW.TabIndex = 14
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(108, 8)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(103, 20)
        Me.Label92.TabIndex = 14
        Me.Label92.Text = "LabT_LDW"
        '
        'TabControl5
        '
        Me.TabControl5.Controls.Add(Me.TabPage22)
        Me.TabControl5.Controls.Add(Me.TabPage23)
        Me.TabControl5.Controls.Add(Me.TabPage24)
        Me.TabControl5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl5.Location = New System.Drawing.Point(3, 3)
        Me.TabControl5.Name = "TabControl5"
        Me.TabControl5.SelectedIndex = 0
        Me.TabControl5.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl5.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl5.TabIndex = 2
        '
        'TabPage22
        '
        Me.TabPage22.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage22.Controls.Add(Me.optionDefectStateLDWFull)
        Me.TabPage22.Controls.Add(Me.Label93)
        Me.TabPage22.Controls.Add(Me.Label94)
        Me.TabPage22.Controls.Add(Me.optionDefectIdLDWFull)
        Me.TabPage22.Controls.Add(Me.Label95)
        Me.TabPage22.Controls.Add(Me.optionDefectKindLDWFull)
        Me.TabPage22.Controls.Add(Me.Label96)
        Me.TabPage22.Controls.Add(Me.optionPtIdLDWFull)
        Me.TabPage22.Controls.Add(Me.Label97)
        Me.TabPage22.Controls.Add(Me.optionFailedLDWFull)
        Me.TabPage22.Controls.Add(Me.Label98)
        Me.TabPage22.Controls.Add(Me.optionPassedLDWFull)
        Me.TabPage22.Controls.Add(Me.optionPtStateLDWFull)
        Me.TabPage22.Controls.Add(Me.Label99)
        Me.TabPage22.Controls.Add(Me.optionVersionLDWFull)
        Me.TabPage22.Controls.Add(Me.Label100)
        Me.TabPage22.Location = New System.Drawing.Point(4, 25)
        Me.TabPage22.Name = "TabPage22"
        Me.TabPage22.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage22.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage22.TabIndex = 0
        Me.TabPage22.Text = "FULL "
        '
        'optionDefectStateLDWFull
        '
        Me.optionDefectStateLDWFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateLDWFull.FormattingEnabled = True
        Me.optionDefectStateLDWFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateLDWFull.Name = "optionDefectStateLDWFull"
        Me.optionDefectStateLDWFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateLDWFull.TabIndex = 16
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(762, 144)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(53, 20)
        Me.Label93.TabIndex = 15
        Me.Label93.Text = "State"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(104, 141)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(86, 20)
        Me.Label94.TabIndex = 13
        Me.Label94.Text = "Defect id"
        '
        'optionDefectIdLDWFull
        '
        Me.optionDefectIdLDWFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdLDWFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdLDWFull.Name = "optionDefectIdLDWFull"
        Me.optionDefectIdLDWFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdLDWFull.TabIndex = 12
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(463, 142)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(46, 20)
        Me.Label95.TabIndex = 11
        Me.Label95.Text = "Kind"
        '
        'optionDefectKindLDWFull
        '
        Me.optionDefectKindLDWFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindLDWFull.FormattingEnabled = True
        Me.optionDefectKindLDWFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindLDWFull.Name = "optionDefectKindLDWFull"
        Me.optionDefectKindLDWFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindLDWFull.TabIndex = 10
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.Location = New System.Drawing.Point(104, 88)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(53, 20)
        Me.Label96.TabIndex = 9
        Me.Label96.Text = "PT id"
        '
        'optionPtIdLDWFull
        '
        Me.optionPtIdLDWFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdLDWFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdLDWFull.Name = "optionPtIdLDWFull"
        Me.optionPtIdLDWFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdLDWFull.TabIndex = 8
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label97.Location = New System.Drawing.Point(463, 92)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(53, 20)
        Me.Label97.TabIndex = 7
        Me.Label97.Text = "State"
        '
        'optionFailedLDWFull
        '
        Me.optionFailedLDWFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedLDWFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedLDWFull.Name = "optionFailedLDWFull"
        Me.optionFailedLDWFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedLDWFull.TabIndex = 6
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(762, 42)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(60, 20)
        Me.Label98.TabIndex = 5
        Me.Label98.Text = "Failed"
        '
        'optionPassedLDWFull
        '
        Me.optionPassedLDWFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedLDWFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedLDWFull.Name = "optionPassedLDWFull"
        Me.optionPassedLDWFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedLDWFull.TabIndex = 4
        '
        'optionPtStateLDWFull
        '
        Me.optionPtStateLDWFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateLDWFull.FormattingEnabled = True
        Me.optionPtStateLDWFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateLDWFull.Name = "optionPtStateLDWFull"
        Me.optionPtStateLDWFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateLDWFull.TabIndex = 3
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label99.Location = New System.Drawing.Point(463, 40)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(71, 20)
        Me.Label99.TabIndex = 2
        Me.Label99.Text = "Passed"
        '
        'optionVersionLDWFull
        '
        Me.optionVersionLDWFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionLDWFull.FormattingEnabled = True
        Me.optionVersionLDWFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionLDWFull.Name = "optionVersionLDWFull"
        Me.optionVersionLDWFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionLDWFull.TabIndex = 1
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.Location = New System.Drawing.Point(104, 37)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(73, 20)
        Me.Label100.TabIndex = 0
        Me.Label100.Text = "Version"
        '
        'TabPage23
        '
        Me.TabPage23.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage23.Controls.Add(Me.optionDefectStateLDWRegression)
        Me.TabPage23.Controls.Add(Me.Label101)
        Me.TabPage23.Controls.Add(Me.Label102)
        Me.TabPage23.Controls.Add(Me.optionDefectIdLDWRegression)
        Me.TabPage23.Controls.Add(Me.Label103)
        Me.TabPage23.Controls.Add(Me.optionDefectKindLDWRegression)
        Me.TabPage23.Controls.Add(Me.Label104)
        Me.TabPage23.Controls.Add(Me.optionPtIdLDWRegression)
        Me.TabPage23.Controls.Add(Me.Label106)
        Me.TabPage23.Controls.Add(Me.optionFailedLDWRegression)
        Me.TabPage23.Controls.Add(Me.Label107)
        Me.TabPage23.Controls.Add(Me.optionPassedLDWRegression)
        Me.TabPage23.Controls.Add(Me.optionPtStateLDWRegression)
        Me.TabPage23.Controls.Add(Me.Label108)
        Me.TabPage23.Controls.Add(Me.optionVersionLDWRegression)
        Me.TabPage23.Controls.Add(Me.Label109)
        Me.TabPage23.Location = New System.Drawing.Point(4, 25)
        Me.TabPage23.Name = "TabPage23"
        Me.TabPage23.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage23.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage23.TabIndex = 1
        Me.TabPage23.Text = "REGRESSION"
        '
        'optionDefectStateLDWRegression
        '
        Me.optionDefectStateLDWRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateLDWRegression.FormattingEnabled = True
        Me.optionDefectStateLDWRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateLDWRegression.Name = "optionDefectStateLDWRegression"
        Me.optionDefectStateLDWRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateLDWRegression.TabIndex = 32
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.Location = New System.Drawing.Point(762, 144)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(53, 20)
        Me.Label101.TabIndex = 31
        Me.Label101.Text = "State"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.Location = New System.Drawing.Point(104, 141)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(86, 20)
        Me.Label102.TabIndex = 30
        Me.Label102.Text = "Defect id"
        '
        'optionDefectIdLDWRegression
        '
        Me.optionDefectIdLDWRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdLDWRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdLDWRegression.Name = "optionDefectIdLDWRegression"
        Me.optionDefectIdLDWRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdLDWRegression.TabIndex = 29
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(463, 142)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(46, 20)
        Me.Label103.TabIndex = 28
        Me.Label103.Text = "Kind"
        '
        'optionDefectKindLDWRegression
        '
        Me.optionDefectKindLDWRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindLDWRegression.FormattingEnabled = True
        Me.optionDefectKindLDWRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindLDWRegression.Name = "optionDefectKindLDWRegression"
        Me.optionDefectKindLDWRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindLDWRegression.TabIndex = 27
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(104, 88)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(53, 20)
        Me.Label104.TabIndex = 26
        Me.Label104.Text = "PT id"
        '
        'optionPtIdLDWRegression
        '
        Me.optionPtIdLDWRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdLDWRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdLDWRegression.Name = "optionPtIdLDWRegression"
        Me.optionPtIdLDWRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdLDWRegression.TabIndex = 25
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(463, 92)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(53, 20)
        Me.Label106.TabIndex = 24
        Me.Label106.Text = "State"
        '
        'optionFailedLDWRegression
        '
        Me.optionFailedLDWRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedLDWRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedLDWRegression.Name = "optionFailedLDWRegression"
        Me.optionFailedLDWRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedLDWRegression.TabIndex = 23
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(762, 42)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(60, 20)
        Me.Label107.TabIndex = 22
        Me.Label107.Text = "Failed"
        '
        'optionPassedLDWRegression
        '
        Me.optionPassedLDWRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedLDWRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedLDWRegression.Name = "optionPassedLDWRegression"
        Me.optionPassedLDWRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedLDWRegression.TabIndex = 21
        '
        'optionPtStateLDWRegression
        '
        Me.optionPtStateLDWRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateLDWRegression.FormattingEnabled = True
        Me.optionPtStateLDWRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateLDWRegression.Name = "optionPtStateLDWRegression"
        Me.optionPtStateLDWRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateLDWRegression.TabIndex = 20
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.Location = New System.Drawing.Point(463, 40)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(71, 20)
        Me.Label108.TabIndex = 19
        Me.Label108.Text = "Passed"
        '
        'optionVersionLDWRegression
        '
        Me.optionVersionLDWRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionLDWRegression.FormattingEnabled = True
        Me.optionVersionLDWRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionLDWRegression.Name = "optionVersionLDWRegression"
        Me.optionVersionLDWRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionLDWRegression.TabIndex = 18
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label109.Location = New System.Drawing.Point(104, 37)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(73, 20)
        Me.Label109.TabIndex = 17
        Me.Label109.Text = "Version"
        '
        'TabPage24
        '
        Me.TabPage24.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage24.Controls.Add(Me.optionDefectStateLDWDelta)
        Me.TabPage24.Controls.Add(Me.Label110)
        Me.TabPage24.Controls.Add(Me.Label111)
        Me.TabPage24.Controls.Add(Me.optionDefectIdLDWDelta)
        Me.TabPage24.Controls.Add(Me.Label112)
        Me.TabPage24.Controls.Add(Me.optionDefectKindLDWDelta)
        Me.TabPage24.Controls.Add(Me.Label113)
        Me.TabPage24.Controls.Add(Me.optionPtIdLDWDelta)
        Me.TabPage24.Controls.Add(Me.Label114)
        Me.TabPage24.Controls.Add(Me.optionFailedLDWDelta)
        Me.TabPage24.Controls.Add(Me.Label115)
        Me.TabPage24.Controls.Add(Me.optionPassedLDWDelta)
        Me.TabPage24.Controls.Add(Me.optionPtStateLDWDelta)
        Me.TabPage24.Controls.Add(Me.Label116)
        Me.TabPage24.Controls.Add(Me.optionVersionLDWDelta)
        Me.TabPage24.Controls.Add(Me.Label117)
        Me.TabPage24.Location = New System.Drawing.Point(4, 25)
        Me.TabPage24.Name = "TabPage24"
        Me.TabPage24.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage24.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage24.TabIndex = 2
        Me.TabPage24.Text = "DELTA"
        '
        'optionDefectStateLDWDelta
        '
        Me.optionDefectStateLDWDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateLDWDelta.FormattingEnabled = True
        Me.optionDefectStateLDWDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateLDWDelta.Name = "optionDefectStateLDWDelta"
        Me.optionDefectStateLDWDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateLDWDelta.TabIndex = 32
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.Location = New System.Drawing.Point(762, 144)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(53, 20)
        Me.Label110.TabIndex = 31
        Me.Label110.Text = "State"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label111.Location = New System.Drawing.Point(104, 141)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(86, 20)
        Me.Label111.TabIndex = 30
        Me.Label111.Text = "Defect id"
        '
        'optionDefectIdLDWDelta
        '
        Me.optionDefectIdLDWDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdLDWDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdLDWDelta.Name = "optionDefectIdLDWDelta"
        Me.optionDefectIdLDWDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdLDWDelta.TabIndex = 29
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.Location = New System.Drawing.Point(463, 142)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(46, 20)
        Me.Label112.TabIndex = 28
        Me.Label112.Text = "Kind"
        '
        'optionDefectKindLDWDelta
        '
        Me.optionDefectKindLDWDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindLDWDelta.FormattingEnabled = True
        Me.optionDefectKindLDWDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindLDWDelta.Name = "optionDefectKindLDWDelta"
        Me.optionDefectKindLDWDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindLDWDelta.TabIndex = 27
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label113.Location = New System.Drawing.Point(104, 88)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(53, 20)
        Me.Label113.TabIndex = 26
        Me.Label113.Text = "PT id"
        '
        'optionPtIdLDWDelta
        '
        Me.optionPtIdLDWDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdLDWDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdLDWDelta.Name = "optionPtIdLDWDelta"
        Me.optionPtIdLDWDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdLDWDelta.TabIndex = 25
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label114.Location = New System.Drawing.Point(463, 92)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(53, 20)
        Me.Label114.TabIndex = 24
        Me.Label114.Text = "State"
        '
        'optionFailedLDWDelta
        '
        Me.optionFailedLDWDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedLDWDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedLDWDelta.Name = "optionFailedLDWDelta"
        Me.optionFailedLDWDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedLDWDelta.TabIndex = 23
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label115.Location = New System.Drawing.Point(762, 42)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(60, 20)
        Me.Label115.TabIndex = 22
        Me.Label115.Text = "Failed"
        '
        'optionPassedLDWDelta
        '
        Me.optionPassedLDWDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedLDWDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedLDWDelta.Name = "optionPassedLDWDelta"
        Me.optionPassedLDWDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedLDWDelta.TabIndex = 21
        '
        'optionPtStateLDWDelta
        '
        Me.optionPtStateLDWDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateLDWDelta.FormattingEnabled = True
        Me.optionPtStateLDWDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateLDWDelta.Name = "optionPtStateLDWDelta"
        Me.optionPtStateLDWDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateLDWDelta.TabIndex = 20
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.Location = New System.Drawing.Point(463, 40)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(71, 20)
        Me.Label116.TabIndex = 19
        Me.Label116.Text = "Passed"
        '
        'optionVersionLDWDelta
        '
        Me.optionVersionLDWDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionLDWDelta.FormattingEnabled = True
        Me.optionVersionLDWDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionLDWDelta.Name = "optionVersionLDWDelta"
        Me.optionVersionLDWDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionLDWDelta.TabIndex = 18
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label117.Location = New System.Drawing.Point(104, 37)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(73, 20)
        Me.Label117.TabIndex = 17
        Me.Label117.Text = "Version"
        '
        'TabPage5
        '
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage5.Controls.Add(Me.Panel6)
        Me.TabPage5.Controls.Add(Me.TabControl6)
        Me.TabPage5.Location = New System.Drawing.Point(4, 4)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "TabPage5"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.optionLabTLKS)
        Me.Panel6.Controls.Add(Me.Label105)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel6.Location = New System.Drawing.Point(3, 219)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1130, 35)
        Me.Panel6.TabIndex = 3
        '
        'optionLabTLKS
        '
        Me.optionLabTLKS.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTLKS.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTLKS.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTLKS.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTLKS.Name = "optionLabTLKS"
        Me.optionLabTLKS.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTLKS.TabIndex = 14
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(108, 8)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(96, 20)
        Me.Label105.TabIndex = 14
        Me.Label105.Text = "LabT_LKS"
        '
        'TabControl6
        '
        Me.TabControl6.Controls.Add(Me.TabPage25)
        Me.TabControl6.Controls.Add(Me.TabPage26)
        Me.TabControl6.Controls.Add(Me.TabPage27)
        Me.TabControl6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl6.Location = New System.Drawing.Point(3, 3)
        Me.TabControl6.Name = "TabControl6"
        Me.TabControl6.SelectedIndex = 0
        Me.TabControl6.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl6.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl6.TabIndex = 2
        '
        'TabPage25
        '
        Me.TabPage25.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage25.Controls.Add(Me.optionDefectStateLKSFull)
        Me.TabPage25.Controls.Add(Me.Label118)
        Me.TabPage25.Controls.Add(Me.Label119)
        Me.TabPage25.Controls.Add(Me.optionDefectIdLKSFull)
        Me.TabPage25.Controls.Add(Me.Label120)
        Me.TabPage25.Controls.Add(Me.optionDefectKindLKSFull)
        Me.TabPage25.Controls.Add(Me.Label121)
        Me.TabPage25.Controls.Add(Me.optionPtIdLKSFull)
        Me.TabPage25.Controls.Add(Me.Label122)
        Me.TabPage25.Controls.Add(Me.optionFailedLKSFull)
        Me.TabPage25.Controls.Add(Me.Label123)
        Me.TabPage25.Controls.Add(Me.optionPassedLKSFull)
        Me.TabPage25.Controls.Add(Me.optionPtStateLKSFull)
        Me.TabPage25.Controls.Add(Me.Label124)
        Me.TabPage25.Controls.Add(Me.optionVersionLKSFull)
        Me.TabPage25.Controls.Add(Me.Label125)
        Me.TabPage25.Location = New System.Drawing.Point(4, 25)
        Me.TabPage25.Name = "TabPage25"
        Me.TabPage25.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage25.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage25.TabIndex = 0
        Me.TabPage25.Text = "FULL "
        '
        'optionDefectStateLKSFull
        '
        Me.optionDefectStateLKSFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateLKSFull.FormattingEnabled = True
        Me.optionDefectStateLKSFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateLKSFull.Name = "optionDefectStateLKSFull"
        Me.optionDefectStateLKSFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateLKSFull.TabIndex = 16
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label118.Location = New System.Drawing.Point(762, 144)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(53, 20)
        Me.Label118.TabIndex = 15
        Me.Label118.Text = "State"
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label119.Location = New System.Drawing.Point(104, 141)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(86, 20)
        Me.Label119.TabIndex = 13
        Me.Label119.Text = "Defect id"
        '
        'optionDefectIdLKSFull
        '
        Me.optionDefectIdLKSFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdLKSFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdLKSFull.Name = "optionDefectIdLKSFull"
        Me.optionDefectIdLKSFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdLKSFull.TabIndex = 12
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label120.Location = New System.Drawing.Point(463, 142)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(46, 20)
        Me.Label120.TabIndex = 11
        Me.Label120.Text = "Kind"
        '
        'optionDefectKindLKSFull
        '
        Me.optionDefectKindLKSFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindLKSFull.FormattingEnabled = True
        Me.optionDefectKindLKSFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindLKSFull.Name = "optionDefectKindLKSFull"
        Me.optionDefectKindLKSFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindLKSFull.TabIndex = 10
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label121.Location = New System.Drawing.Point(104, 88)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(53, 20)
        Me.Label121.TabIndex = 9
        Me.Label121.Text = "PT id"
        '
        'optionPtIdLKSFull
        '
        Me.optionPtIdLKSFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdLKSFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdLKSFull.Name = "optionPtIdLKSFull"
        Me.optionPtIdLKSFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdLKSFull.TabIndex = 8
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label122.Location = New System.Drawing.Point(463, 92)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(53, 20)
        Me.Label122.TabIndex = 7
        Me.Label122.Text = "State"
        '
        'optionFailedLKSFull
        '
        Me.optionFailedLKSFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedLKSFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedLKSFull.Name = "optionFailedLKSFull"
        Me.optionFailedLKSFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedLKSFull.TabIndex = 6
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label123.Location = New System.Drawing.Point(762, 42)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(60, 20)
        Me.Label123.TabIndex = 5
        Me.Label123.Text = "Failed"
        '
        'optionPassedLKSFull
        '
        Me.optionPassedLKSFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedLKSFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedLKSFull.Name = "optionPassedLKSFull"
        Me.optionPassedLKSFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedLKSFull.TabIndex = 4
        '
        'optionPtStateLKSFull
        '
        Me.optionPtStateLKSFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateLKSFull.FormattingEnabled = True
        Me.optionPtStateLKSFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateLKSFull.Name = "optionPtStateLKSFull"
        Me.optionPtStateLKSFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateLKSFull.TabIndex = 3
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label124.Location = New System.Drawing.Point(463, 40)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(71, 20)
        Me.Label124.TabIndex = 2
        Me.Label124.Text = "Passed"
        '
        'optionVersionLKSFull
        '
        Me.optionVersionLKSFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionLKSFull.FormattingEnabled = True
        Me.optionVersionLKSFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionLKSFull.Name = "optionVersionLKSFull"
        Me.optionVersionLKSFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionLKSFull.TabIndex = 1
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label125.Location = New System.Drawing.Point(104, 37)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(73, 20)
        Me.Label125.TabIndex = 0
        Me.Label125.Text = "Version"
        '
        'TabPage26
        '
        Me.TabPage26.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage26.Controls.Add(Me.optionDefectStateLKSRegression)
        Me.TabPage26.Controls.Add(Me.Label126)
        Me.TabPage26.Controls.Add(Me.Label127)
        Me.TabPage26.Controls.Add(Me.optionDefectIdLKSRegression)
        Me.TabPage26.Controls.Add(Me.Label128)
        Me.TabPage26.Controls.Add(Me.optionDefectKindLKSRegression)
        Me.TabPage26.Controls.Add(Me.Label129)
        Me.TabPage26.Controls.Add(Me.optionPtIdLKSRegression)
        Me.TabPage26.Controls.Add(Me.Label130)
        Me.TabPage26.Controls.Add(Me.optionFailedLKSRegression)
        Me.TabPage26.Controls.Add(Me.Label131)
        Me.TabPage26.Controls.Add(Me.optionPassedLKSRegression)
        Me.TabPage26.Controls.Add(Me.optionPtStateLKSRegression)
        Me.TabPage26.Controls.Add(Me.Label132)
        Me.TabPage26.Controls.Add(Me.optionVersionLKSRegression)
        Me.TabPage26.Controls.Add(Me.Label133)
        Me.TabPage26.Location = New System.Drawing.Point(4, 25)
        Me.TabPage26.Name = "TabPage26"
        Me.TabPage26.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage26.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage26.TabIndex = 1
        Me.TabPage26.Text = "REGRESSION"
        '
        'optionDefectStateLKSRegression
        '
        Me.optionDefectStateLKSRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateLKSRegression.FormattingEnabled = True
        Me.optionDefectStateLKSRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateLKSRegression.Name = "optionDefectStateLKSRegression"
        Me.optionDefectStateLKSRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateLKSRegression.TabIndex = 32
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label126.Location = New System.Drawing.Point(762, 144)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(53, 20)
        Me.Label126.TabIndex = 31
        Me.Label126.Text = "State"
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label127.Location = New System.Drawing.Point(104, 141)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(86, 20)
        Me.Label127.TabIndex = 30
        Me.Label127.Text = "Defect id"
        '
        'optionDefectIdLKSRegression
        '
        Me.optionDefectIdLKSRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdLKSRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdLKSRegression.Name = "optionDefectIdLKSRegression"
        Me.optionDefectIdLKSRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdLKSRegression.TabIndex = 29
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label128.Location = New System.Drawing.Point(463, 142)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(46, 20)
        Me.Label128.TabIndex = 28
        Me.Label128.Text = "Kind"
        '
        'optionDefectKindLKSRegression
        '
        Me.optionDefectKindLKSRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindLKSRegression.FormattingEnabled = True
        Me.optionDefectKindLKSRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindLKSRegression.Name = "optionDefectKindLKSRegression"
        Me.optionDefectKindLKSRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindLKSRegression.TabIndex = 27
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label129.Location = New System.Drawing.Point(104, 88)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(53, 20)
        Me.Label129.TabIndex = 26
        Me.Label129.Text = "PT id"
        '
        'optionPtIdLKSRegression
        '
        Me.optionPtIdLKSRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdLKSRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdLKSRegression.Name = "optionPtIdLKSRegression"
        Me.optionPtIdLKSRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdLKSRegression.TabIndex = 25
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label130.Location = New System.Drawing.Point(463, 92)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(53, 20)
        Me.Label130.TabIndex = 24
        Me.Label130.Text = "State"
        '
        'optionFailedLKSRegression
        '
        Me.optionFailedLKSRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedLKSRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedLKSRegression.Name = "optionFailedLKSRegression"
        Me.optionFailedLKSRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedLKSRegression.TabIndex = 23
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label131.Location = New System.Drawing.Point(762, 42)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(60, 20)
        Me.Label131.TabIndex = 22
        Me.Label131.Text = "Failed"
        '
        'optionPassedLKSRegression
        '
        Me.optionPassedLKSRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedLKSRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedLKSRegression.Name = "optionPassedLKSRegression"
        Me.optionPassedLKSRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedLKSRegression.TabIndex = 21
        '
        'optionPtStateLKSRegression
        '
        Me.optionPtStateLKSRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateLKSRegression.FormattingEnabled = True
        Me.optionPtStateLKSRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateLKSRegression.Name = "optionPtStateLKSRegression"
        Me.optionPtStateLKSRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateLKSRegression.TabIndex = 20
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label132.Location = New System.Drawing.Point(463, 40)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(71, 20)
        Me.Label132.TabIndex = 19
        Me.Label132.Text = "Passed"
        '
        'optionVersionLKSRegression
        '
        Me.optionVersionLKSRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionLKSRegression.FormattingEnabled = True
        Me.optionVersionLKSRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionLKSRegression.Name = "optionVersionLKSRegression"
        Me.optionVersionLKSRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionLKSRegression.TabIndex = 18
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label133.Location = New System.Drawing.Point(104, 37)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(73, 20)
        Me.Label133.TabIndex = 17
        Me.Label133.Text = "Version"
        '
        'TabPage27
        '
        Me.TabPage27.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage27.Controls.Add(Me.optionDefectStateLKSDelta)
        Me.TabPage27.Controls.Add(Me.Label134)
        Me.TabPage27.Controls.Add(Me.Label135)
        Me.TabPage27.Controls.Add(Me.optionDefectIdLKSDelta)
        Me.TabPage27.Controls.Add(Me.Label136)
        Me.TabPage27.Controls.Add(Me.optionDefectKindLKSDelta)
        Me.TabPage27.Controls.Add(Me.Label137)
        Me.TabPage27.Controls.Add(Me.optionPtIdLKSDelta)
        Me.TabPage27.Controls.Add(Me.Label138)
        Me.TabPage27.Controls.Add(Me.optionFailedLKSDelta)
        Me.TabPage27.Controls.Add(Me.Label139)
        Me.TabPage27.Controls.Add(Me.optionPassedLKSDelta)
        Me.TabPage27.Controls.Add(Me.optionPtStateLKSDelta)
        Me.TabPage27.Controls.Add(Me.Label140)
        Me.TabPage27.Controls.Add(Me.optionVersionLKSDelta)
        Me.TabPage27.Controls.Add(Me.Label141)
        Me.TabPage27.Location = New System.Drawing.Point(4, 25)
        Me.TabPage27.Name = "TabPage27"
        Me.TabPage27.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage27.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage27.TabIndex = 2
        Me.TabPage27.Text = "DELTA"
        '
        'optionDefectStateLKSDelta
        '
        Me.optionDefectStateLKSDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateLKSDelta.FormattingEnabled = True
        Me.optionDefectStateLKSDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateLKSDelta.Name = "optionDefectStateLKSDelta"
        Me.optionDefectStateLKSDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateLKSDelta.TabIndex = 32
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label134.Location = New System.Drawing.Point(762, 144)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(53, 20)
        Me.Label134.TabIndex = 31
        Me.Label134.Text = "State"
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label135.Location = New System.Drawing.Point(104, 141)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(86, 20)
        Me.Label135.TabIndex = 30
        Me.Label135.Text = "Defect id"
        '
        'optionDefectIdLKSDelta
        '
        Me.optionDefectIdLKSDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdLKSDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdLKSDelta.Name = "optionDefectIdLKSDelta"
        Me.optionDefectIdLKSDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdLKSDelta.TabIndex = 29
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label136.Location = New System.Drawing.Point(463, 142)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(46, 20)
        Me.Label136.TabIndex = 28
        Me.Label136.Text = "Kind"
        '
        'optionDefectKindLKSDelta
        '
        Me.optionDefectKindLKSDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindLKSDelta.FormattingEnabled = True
        Me.optionDefectKindLKSDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindLKSDelta.Name = "optionDefectKindLKSDelta"
        Me.optionDefectKindLKSDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindLKSDelta.TabIndex = 27
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label137.Location = New System.Drawing.Point(104, 88)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(53, 20)
        Me.Label137.TabIndex = 26
        Me.Label137.Text = "PT id"
        '
        'optionPtIdLKSDelta
        '
        Me.optionPtIdLKSDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdLKSDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdLKSDelta.Name = "optionPtIdLKSDelta"
        Me.optionPtIdLKSDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdLKSDelta.TabIndex = 25
        '
        'Label138
        '
        Me.Label138.AutoSize = True
        Me.Label138.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label138.Location = New System.Drawing.Point(463, 92)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(53, 20)
        Me.Label138.TabIndex = 24
        Me.Label138.Text = "State"
        '
        'optionFailedLKSDelta
        '
        Me.optionFailedLKSDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedLKSDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedLKSDelta.Name = "optionFailedLKSDelta"
        Me.optionFailedLKSDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedLKSDelta.TabIndex = 23
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label139.Location = New System.Drawing.Point(762, 42)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(60, 20)
        Me.Label139.TabIndex = 22
        Me.Label139.Text = "Failed"
        '
        'optionPassedLKSDelta
        '
        Me.optionPassedLKSDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedLKSDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedLKSDelta.Name = "optionPassedLKSDelta"
        Me.optionPassedLKSDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedLKSDelta.TabIndex = 21
        '
        'optionPtStateLKSDelta
        '
        Me.optionPtStateLKSDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateLKSDelta.FormattingEnabled = True
        Me.optionPtStateLKSDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateLKSDelta.Name = "optionPtStateLKSDelta"
        Me.optionPtStateLKSDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateLKSDelta.TabIndex = 20
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label140.Location = New System.Drawing.Point(463, 40)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(71, 20)
        Me.Label140.TabIndex = 19
        Me.Label140.Text = "Passed"
        '
        'optionVersionLKSDelta
        '
        Me.optionVersionLKSDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionLKSDelta.FormattingEnabled = True
        Me.optionVersionLKSDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionLKSDelta.Name = "optionVersionLKSDelta"
        Me.optionVersionLKSDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionLKSDelta.TabIndex = 18
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label141.Location = New System.Drawing.Point(104, 37)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(73, 20)
        Me.Label141.TabIndex = 17
        Me.Label141.Text = "Version"
        '
        'TabPage6
        '
        Me.TabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage6.Controls.Add(Me.Panel7)
        Me.TabPage6.Controls.Add(Me.TabControl7)
        Me.TabPage6.Location = New System.Drawing.Point(4, 4)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "TabPage6"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.optionLabTRDP)
        Me.Panel7.Controls.Add(Me.Label142)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel7.Location = New System.Drawing.Point(3, 219)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(1130, 35)
        Me.Panel7.TabIndex = 3
        '
        'optionLabTRDP
        '
        Me.optionLabTRDP.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTRDP.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTRDP.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTRDP.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTRDP.Name = "optionLabTRDP"
        Me.optionLabTRDP.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTRDP.TabIndex = 14
        '
        'Label142
        '
        Me.Label142.AutoSize = True
        Me.Label142.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label142.Location = New System.Drawing.Point(108, 8)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(100, 20)
        Me.Label142.TabIndex = 14
        Me.Label142.Text = "LabT_RDP"
        '
        'TabControl7
        '
        Me.TabControl7.Controls.Add(Me.TabPage28)
        Me.TabControl7.Controls.Add(Me.TabPage29)
        Me.TabControl7.Controls.Add(Me.TabPage30)
        Me.TabControl7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl7.Location = New System.Drawing.Point(3, 3)
        Me.TabControl7.Name = "TabControl7"
        Me.TabControl7.SelectedIndex = 0
        Me.TabControl7.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl7.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl7.TabIndex = 2
        '
        'TabPage28
        '
        Me.TabPage28.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage28.Controls.Add(Me.optionDefectStateRDPFull)
        Me.TabPage28.Controls.Add(Me.Label143)
        Me.TabPage28.Controls.Add(Me.Label144)
        Me.TabPage28.Controls.Add(Me.optionDefectIdRDPFull)
        Me.TabPage28.Controls.Add(Me.Label145)
        Me.TabPage28.Controls.Add(Me.optionDefectKindRDPFull)
        Me.TabPage28.Controls.Add(Me.Label146)
        Me.TabPage28.Controls.Add(Me.optionPtIdRDPFull)
        Me.TabPage28.Controls.Add(Me.Label147)
        Me.TabPage28.Controls.Add(Me.optionFailedRDPFull)
        Me.TabPage28.Controls.Add(Me.Label148)
        Me.TabPage28.Controls.Add(Me.optionPassedRDPFull)
        Me.TabPage28.Controls.Add(Me.optionPtStateRDPFull)
        Me.TabPage28.Controls.Add(Me.Label150)
        Me.TabPage28.Controls.Add(Me.optionVersionRDPFull)
        Me.TabPage28.Controls.Add(Me.Label151)
        Me.TabPage28.Location = New System.Drawing.Point(4, 25)
        Me.TabPage28.Name = "TabPage28"
        Me.TabPage28.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage28.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage28.TabIndex = 0
        Me.TabPage28.Text = "FULL "
        '
        'optionDefectStateRDPFull
        '
        Me.optionDefectStateRDPFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateRDPFull.FormattingEnabled = True
        Me.optionDefectStateRDPFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateRDPFull.Name = "optionDefectStateRDPFull"
        Me.optionDefectStateRDPFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateRDPFull.TabIndex = 16
        '
        'Label143
        '
        Me.Label143.AutoSize = True
        Me.Label143.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label143.Location = New System.Drawing.Point(762, 144)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(53, 20)
        Me.Label143.TabIndex = 15
        Me.Label143.Text = "State"
        '
        'Label144
        '
        Me.Label144.AutoSize = True
        Me.Label144.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label144.Location = New System.Drawing.Point(104, 141)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(86, 20)
        Me.Label144.TabIndex = 13
        Me.Label144.Text = "Defect id"
        '
        'optionDefectIdRDPFull
        '
        Me.optionDefectIdRDPFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdRDPFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdRDPFull.Name = "optionDefectIdRDPFull"
        Me.optionDefectIdRDPFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdRDPFull.TabIndex = 12
        '
        'Label145
        '
        Me.Label145.AutoSize = True
        Me.Label145.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label145.Location = New System.Drawing.Point(463, 142)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(46, 20)
        Me.Label145.TabIndex = 11
        Me.Label145.Text = "Kind"
        '
        'optionDefectKindRDPFull
        '
        Me.optionDefectKindRDPFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindRDPFull.FormattingEnabled = True
        Me.optionDefectKindRDPFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindRDPFull.Name = "optionDefectKindRDPFull"
        Me.optionDefectKindRDPFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindRDPFull.TabIndex = 10
        '
        'Label146
        '
        Me.Label146.AutoSize = True
        Me.Label146.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label146.Location = New System.Drawing.Point(104, 88)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(53, 20)
        Me.Label146.TabIndex = 9
        Me.Label146.Text = "PT id"
        '
        'optionPtIdRDPFull
        '
        Me.optionPtIdRDPFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdRDPFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdRDPFull.Name = "optionPtIdRDPFull"
        Me.optionPtIdRDPFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdRDPFull.TabIndex = 8
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label147.Location = New System.Drawing.Point(463, 92)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(53, 20)
        Me.Label147.TabIndex = 7
        Me.Label147.Text = "State"
        '
        'optionFailedRDPFull
        '
        Me.optionFailedRDPFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedRDPFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedRDPFull.Name = "optionFailedRDPFull"
        Me.optionFailedRDPFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedRDPFull.TabIndex = 6
        '
        'Label148
        '
        Me.Label148.AutoSize = True
        Me.Label148.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label148.Location = New System.Drawing.Point(762, 42)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(60, 20)
        Me.Label148.TabIndex = 5
        Me.Label148.Text = "Failed"
        '
        'optionPassedRDPFull
        '
        Me.optionPassedRDPFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedRDPFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedRDPFull.Name = "optionPassedRDPFull"
        Me.optionPassedRDPFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedRDPFull.TabIndex = 4
        '
        'optionPtStateRDPFull
        '
        Me.optionPtStateRDPFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateRDPFull.FormattingEnabled = True
        Me.optionPtStateRDPFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateRDPFull.Name = "optionPtStateRDPFull"
        Me.optionPtStateRDPFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateRDPFull.TabIndex = 3
        '
        'Label150
        '
        Me.Label150.AutoSize = True
        Me.Label150.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label150.Location = New System.Drawing.Point(463, 40)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(71, 20)
        Me.Label150.TabIndex = 2
        Me.Label150.Text = "Passed"
        '
        'optionVersionRDPFull
        '
        Me.optionVersionRDPFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionRDPFull.FormattingEnabled = True
        Me.optionVersionRDPFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionRDPFull.Name = "optionVersionRDPFull"
        Me.optionVersionRDPFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionRDPFull.TabIndex = 1
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label151.Location = New System.Drawing.Point(104, 37)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(73, 20)
        Me.Label151.TabIndex = 0
        Me.Label151.Text = "Version"
        '
        'TabPage29
        '
        Me.TabPage29.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage29.Controls.Add(Me.optionDefectStateRDPRegression)
        Me.TabPage29.Controls.Add(Me.Label152)
        Me.TabPage29.Controls.Add(Me.Label153)
        Me.TabPage29.Controls.Add(Me.optionDefectIdRDPRegression)
        Me.TabPage29.Controls.Add(Me.Label154)
        Me.TabPage29.Controls.Add(Me.optionDefectKindRDPRegression)
        Me.TabPage29.Controls.Add(Me.Label155)
        Me.TabPage29.Controls.Add(Me.optionPtIdRDPRegression)
        Me.TabPage29.Controls.Add(Me.Label156)
        Me.TabPage29.Controls.Add(Me.optionFailedRDPRegression)
        Me.TabPage29.Controls.Add(Me.Label157)
        Me.TabPage29.Controls.Add(Me.optionPassedRDPRegression)
        Me.TabPage29.Controls.Add(Me.optionPtStateRDPRegression)
        Me.TabPage29.Controls.Add(Me.Label158)
        Me.TabPage29.Controls.Add(Me.optionVersionRDPRegression)
        Me.TabPage29.Controls.Add(Me.Label159)
        Me.TabPage29.Location = New System.Drawing.Point(4, 25)
        Me.TabPage29.Name = "TabPage29"
        Me.TabPage29.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage29.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage29.TabIndex = 1
        Me.TabPage29.Text = "REGRESSION"
        '
        'optionDefectStateRDPRegression
        '
        Me.optionDefectStateRDPRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateRDPRegression.FormattingEnabled = True
        Me.optionDefectStateRDPRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateRDPRegression.Name = "optionDefectStateRDPRegression"
        Me.optionDefectStateRDPRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateRDPRegression.TabIndex = 32
        '
        'Label152
        '
        Me.Label152.AutoSize = True
        Me.Label152.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label152.Location = New System.Drawing.Point(762, 144)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(53, 20)
        Me.Label152.TabIndex = 31
        Me.Label152.Text = "State"
        '
        'Label153
        '
        Me.Label153.AutoSize = True
        Me.Label153.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label153.Location = New System.Drawing.Point(104, 141)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(86, 20)
        Me.Label153.TabIndex = 30
        Me.Label153.Text = "Defect id"
        '
        'optionDefectIdRDPRegression
        '
        Me.optionDefectIdRDPRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdRDPRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdRDPRegression.Name = "optionDefectIdRDPRegression"
        Me.optionDefectIdRDPRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdRDPRegression.TabIndex = 29
        '
        'Label154
        '
        Me.Label154.AutoSize = True
        Me.Label154.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label154.Location = New System.Drawing.Point(463, 142)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(46, 20)
        Me.Label154.TabIndex = 28
        Me.Label154.Text = "Kind"
        '
        'optionDefectKindRDPRegression
        '
        Me.optionDefectKindRDPRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindRDPRegression.FormattingEnabled = True
        Me.optionDefectKindRDPRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindRDPRegression.Name = "optionDefectKindRDPRegression"
        Me.optionDefectKindRDPRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindRDPRegression.TabIndex = 27
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label155.Location = New System.Drawing.Point(104, 88)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(53, 20)
        Me.Label155.TabIndex = 26
        Me.Label155.Text = "PT id"
        '
        'optionPtIdRDPRegression
        '
        Me.optionPtIdRDPRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdRDPRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdRDPRegression.Name = "optionPtIdRDPRegression"
        Me.optionPtIdRDPRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdRDPRegression.TabIndex = 25
        '
        'Label156
        '
        Me.Label156.AutoSize = True
        Me.Label156.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label156.Location = New System.Drawing.Point(463, 92)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(53, 20)
        Me.Label156.TabIndex = 24
        Me.Label156.Text = "State"
        '
        'optionFailedRDPRegression
        '
        Me.optionFailedRDPRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedRDPRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedRDPRegression.Name = "optionFailedRDPRegression"
        Me.optionFailedRDPRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedRDPRegression.TabIndex = 23
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label157.Location = New System.Drawing.Point(762, 42)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(60, 20)
        Me.Label157.TabIndex = 22
        Me.Label157.Text = "Failed"
        '
        'optionPassedRDPRegression
        '
        Me.optionPassedRDPRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedRDPRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedRDPRegression.Name = "optionPassedRDPRegression"
        Me.optionPassedRDPRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedRDPRegression.TabIndex = 21
        '
        'optionPtStateRDPRegression
        '
        Me.optionPtStateRDPRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateRDPRegression.FormattingEnabled = True
        Me.optionPtStateRDPRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateRDPRegression.Name = "optionPtStateRDPRegression"
        Me.optionPtStateRDPRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateRDPRegression.TabIndex = 20
        '
        'Label158
        '
        Me.Label158.AutoSize = True
        Me.Label158.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label158.Location = New System.Drawing.Point(463, 40)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(71, 20)
        Me.Label158.TabIndex = 19
        Me.Label158.Text = "Passed"
        '
        'optionVersionRDPRegression
        '
        Me.optionVersionRDPRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionRDPRegression.FormattingEnabled = True
        Me.optionVersionRDPRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionRDPRegression.Name = "optionVersionRDPRegression"
        Me.optionVersionRDPRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionRDPRegression.TabIndex = 18
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label159.Location = New System.Drawing.Point(104, 37)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(73, 20)
        Me.Label159.TabIndex = 17
        Me.Label159.Text = "Version"
        '
        'TabPage30
        '
        Me.TabPage30.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage30.Controls.Add(Me.optionDefectStateRDPDelta)
        Me.TabPage30.Controls.Add(Me.Label160)
        Me.TabPage30.Controls.Add(Me.Label161)
        Me.TabPage30.Controls.Add(Me.optionDefectIdRDPDelta)
        Me.TabPage30.Controls.Add(Me.Label162)
        Me.TabPage30.Controls.Add(Me.optionDefectKindRDPDelta)
        Me.TabPage30.Controls.Add(Me.Label163)
        Me.TabPage30.Controls.Add(Me.optionPtIdRDPDelta)
        Me.TabPage30.Controls.Add(Me.Label164)
        Me.TabPage30.Controls.Add(Me.optionFailedRDPDelta)
        Me.TabPage30.Controls.Add(Me.Label165)
        Me.TabPage30.Controls.Add(Me.optionPassedRDPDelta)
        Me.TabPage30.Controls.Add(Me.optionPtStateRDPDelta)
        Me.TabPage30.Controls.Add(Me.Label166)
        Me.TabPage30.Controls.Add(Me.optionVersionRDPDelta)
        Me.TabPage30.Controls.Add(Me.Label167)
        Me.TabPage30.Location = New System.Drawing.Point(4, 25)
        Me.TabPage30.Name = "TabPage30"
        Me.TabPage30.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage30.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage30.TabIndex = 2
        Me.TabPage30.Text = "DELTA"
        '
        'optionDefectStateRDPDelta
        '
        Me.optionDefectStateRDPDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateRDPDelta.FormattingEnabled = True
        Me.optionDefectStateRDPDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateRDPDelta.Name = "optionDefectStateRDPDelta"
        Me.optionDefectStateRDPDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateRDPDelta.TabIndex = 32
        '
        'Label160
        '
        Me.Label160.AutoSize = True
        Me.Label160.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label160.Location = New System.Drawing.Point(762, 144)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(53, 20)
        Me.Label160.TabIndex = 31
        Me.Label160.Text = "State"
        '
        'Label161
        '
        Me.Label161.AutoSize = True
        Me.Label161.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label161.Location = New System.Drawing.Point(104, 141)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(86, 20)
        Me.Label161.TabIndex = 30
        Me.Label161.Text = "Defect id"
        '
        'optionDefectIdRDPDelta
        '
        Me.optionDefectIdRDPDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdRDPDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdRDPDelta.Name = "optionDefectIdRDPDelta"
        Me.optionDefectIdRDPDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdRDPDelta.TabIndex = 29
        '
        'Label162
        '
        Me.Label162.AutoSize = True
        Me.Label162.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label162.Location = New System.Drawing.Point(463, 142)
        Me.Label162.Name = "Label162"
        Me.Label162.Size = New System.Drawing.Size(46, 20)
        Me.Label162.TabIndex = 28
        Me.Label162.Text = "Kind"
        '
        'optionDefectKindRDPDelta
        '
        Me.optionDefectKindRDPDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindRDPDelta.FormattingEnabled = True
        Me.optionDefectKindRDPDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindRDPDelta.Name = "optionDefectKindRDPDelta"
        Me.optionDefectKindRDPDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindRDPDelta.TabIndex = 27
        '
        'Label163
        '
        Me.Label163.AutoSize = True
        Me.Label163.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label163.Location = New System.Drawing.Point(104, 88)
        Me.Label163.Name = "Label163"
        Me.Label163.Size = New System.Drawing.Size(53, 20)
        Me.Label163.TabIndex = 26
        Me.Label163.Text = "PT id"
        '
        'optionPtIdRDPDelta
        '
        Me.optionPtIdRDPDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdRDPDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdRDPDelta.Name = "optionPtIdRDPDelta"
        Me.optionPtIdRDPDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdRDPDelta.TabIndex = 25
        '
        'Label164
        '
        Me.Label164.AutoSize = True
        Me.Label164.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label164.Location = New System.Drawing.Point(463, 92)
        Me.Label164.Name = "Label164"
        Me.Label164.Size = New System.Drawing.Size(53, 20)
        Me.Label164.TabIndex = 24
        Me.Label164.Text = "State"
        '
        'optionFailedRDPDelta
        '
        Me.optionFailedRDPDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedRDPDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedRDPDelta.Name = "optionFailedRDPDelta"
        Me.optionFailedRDPDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedRDPDelta.TabIndex = 23
        '
        'Label165
        '
        Me.Label165.AutoSize = True
        Me.Label165.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label165.Location = New System.Drawing.Point(762, 42)
        Me.Label165.Name = "Label165"
        Me.Label165.Size = New System.Drawing.Size(60, 20)
        Me.Label165.TabIndex = 22
        Me.Label165.Text = "Failed"
        '
        'optionPassedRDPDelta
        '
        Me.optionPassedRDPDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedRDPDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedRDPDelta.Name = "optionPassedRDPDelta"
        Me.optionPassedRDPDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedRDPDelta.TabIndex = 21
        '
        'optionPtStateRDPDelta
        '
        Me.optionPtStateRDPDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateRDPDelta.FormattingEnabled = True
        Me.optionPtStateRDPDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateRDPDelta.Name = "optionPtStateRDPDelta"
        Me.optionPtStateRDPDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateRDPDelta.TabIndex = 20
        '
        'Label166
        '
        Me.Label166.AutoSize = True
        Me.Label166.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label166.Location = New System.Drawing.Point(463, 40)
        Me.Label166.Name = "Label166"
        Me.Label166.Size = New System.Drawing.Size(71, 20)
        Me.Label166.TabIndex = 19
        Me.Label166.Text = "Passed"
        '
        'optionVersionRDPDelta
        '
        Me.optionVersionRDPDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionRDPDelta.FormattingEnabled = True
        Me.optionVersionRDPDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionRDPDelta.Name = "optionVersionRDPDelta"
        Me.optionVersionRDPDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionRDPDelta.TabIndex = 18
        '
        'Label167
        '
        Me.Label167.AutoSize = True
        Me.Label167.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label167.Location = New System.Drawing.Point(104, 37)
        Me.Label167.Name = "Label167"
        Me.Label167.Size = New System.Drawing.Size(73, 20)
        Me.Label167.TabIndex = 17
        Me.Label167.Text = "Version"
        '
        'TabPage7
        '
        Me.TabPage7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage7.Controls.Add(Me.Panel8)
        Me.TabPage7.Controls.Add(Me.TabControl8)
        Me.TabPage7.Location = New System.Drawing.Point(4, 4)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "TabPage7"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.optionLabTELK)
        Me.Panel8.Controls.Add(Me.Label149)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel8.Location = New System.Drawing.Point(3, 219)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(1130, 35)
        Me.Panel8.TabIndex = 3
        '
        'optionLabTELK
        '
        Me.optionLabTELK.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTELK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTELK.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTELK.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTELK.Name = "optionLabTELK"
        Me.optionLabTELK.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTELK.TabIndex = 14
        '
        'Label149
        '
        Me.Label149.AutoSize = True
        Me.Label149.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label149.Location = New System.Drawing.Point(108, 8)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(96, 20)
        Me.Label149.TabIndex = 14
        Me.Label149.Text = "LabT_ELK"
        '
        'TabControl8
        '
        Me.TabControl8.Controls.Add(Me.TabPage31)
        Me.TabControl8.Controls.Add(Me.TabPage32)
        Me.TabControl8.Controls.Add(Me.TabPage33)
        Me.TabControl8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl8.Location = New System.Drawing.Point(3, 3)
        Me.TabControl8.Name = "TabControl8"
        Me.TabControl8.SelectedIndex = 0
        Me.TabControl8.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl8.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl8.TabIndex = 2
        '
        'TabPage31
        '
        Me.TabPage31.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage31.Controls.Add(Me.optionDefectStateELKFull)
        Me.TabPage31.Controls.Add(Me.Label168)
        Me.TabPage31.Controls.Add(Me.Label169)
        Me.TabPage31.Controls.Add(Me.optionDefectIdELKFull)
        Me.TabPage31.Controls.Add(Me.Label170)
        Me.TabPage31.Controls.Add(Me.optionDefectKindELKFull)
        Me.TabPage31.Controls.Add(Me.Label171)
        Me.TabPage31.Controls.Add(Me.optionPtIdELKFull)
        Me.TabPage31.Controls.Add(Me.Label172)
        Me.TabPage31.Controls.Add(Me.optionFailedELKFull)
        Me.TabPage31.Controls.Add(Me.Label173)
        Me.TabPage31.Controls.Add(Me.optionPassedELKFull)
        Me.TabPage31.Controls.Add(Me.optionPtStateELKFull)
        Me.TabPage31.Controls.Add(Me.Label174)
        Me.TabPage31.Controls.Add(Me.optionVersionELKFull)
        Me.TabPage31.Controls.Add(Me.Label175)
        Me.TabPage31.Location = New System.Drawing.Point(4, 25)
        Me.TabPage31.Name = "TabPage31"
        Me.TabPage31.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage31.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage31.TabIndex = 0
        Me.TabPage31.Text = "FULL "
        '
        'optionDefectStateELKFull
        '
        Me.optionDefectStateELKFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateELKFull.FormattingEnabled = True
        Me.optionDefectStateELKFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateELKFull.Name = "optionDefectStateELKFull"
        Me.optionDefectStateELKFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateELKFull.TabIndex = 16
        '
        'Label168
        '
        Me.Label168.AutoSize = True
        Me.Label168.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label168.Location = New System.Drawing.Point(762, 144)
        Me.Label168.Name = "Label168"
        Me.Label168.Size = New System.Drawing.Size(53, 20)
        Me.Label168.TabIndex = 15
        Me.Label168.Text = "State"
        '
        'Label169
        '
        Me.Label169.AutoSize = True
        Me.Label169.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label169.Location = New System.Drawing.Point(104, 141)
        Me.Label169.Name = "Label169"
        Me.Label169.Size = New System.Drawing.Size(86, 20)
        Me.Label169.TabIndex = 13
        Me.Label169.Text = "Defect id"
        '
        'optionDefectIdELKFull
        '
        Me.optionDefectIdELKFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdELKFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdELKFull.Name = "optionDefectIdELKFull"
        Me.optionDefectIdELKFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdELKFull.TabIndex = 12
        '
        'Label170
        '
        Me.Label170.AutoSize = True
        Me.Label170.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label170.Location = New System.Drawing.Point(463, 142)
        Me.Label170.Name = "Label170"
        Me.Label170.Size = New System.Drawing.Size(46, 20)
        Me.Label170.TabIndex = 11
        Me.Label170.Text = "Kind"
        '
        'optionDefectKindELKFull
        '
        Me.optionDefectKindELKFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindELKFull.FormattingEnabled = True
        Me.optionDefectKindELKFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindELKFull.Name = "optionDefectKindELKFull"
        Me.optionDefectKindELKFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindELKFull.TabIndex = 10
        '
        'Label171
        '
        Me.Label171.AutoSize = True
        Me.Label171.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label171.Location = New System.Drawing.Point(104, 88)
        Me.Label171.Name = "Label171"
        Me.Label171.Size = New System.Drawing.Size(53, 20)
        Me.Label171.TabIndex = 9
        Me.Label171.Text = "PT id"
        '
        'optionPtIdELKFull
        '
        Me.optionPtIdELKFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdELKFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdELKFull.Name = "optionPtIdELKFull"
        Me.optionPtIdELKFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdELKFull.TabIndex = 8
        '
        'Label172
        '
        Me.Label172.AutoSize = True
        Me.Label172.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label172.Location = New System.Drawing.Point(463, 92)
        Me.Label172.Name = "Label172"
        Me.Label172.Size = New System.Drawing.Size(53, 20)
        Me.Label172.TabIndex = 7
        Me.Label172.Text = "State"
        '
        'optionFailedELKFull
        '
        Me.optionFailedELKFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedELKFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedELKFull.Name = "optionFailedELKFull"
        Me.optionFailedELKFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedELKFull.TabIndex = 6
        '
        'Label173
        '
        Me.Label173.AutoSize = True
        Me.Label173.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label173.Location = New System.Drawing.Point(762, 42)
        Me.Label173.Name = "Label173"
        Me.Label173.Size = New System.Drawing.Size(60, 20)
        Me.Label173.TabIndex = 5
        Me.Label173.Text = "Failed"
        '
        'optionPassedELKFull
        '
        Me.optionPassedELKFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedELKFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedELKFull.Name = "optionPassedELKFull"
        Me.optionPassedELKFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedELKFull.TabIndex = 4
        '
        'optionPtStateELKFull
        '
        Me.optionPtStateELKFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateELKFull.FormattingEnabled = True
        Me.optionPtStateELKFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateELKFull.Name = "optionPtStateELKFull"
        Me.optionPtStateELKFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateELKFull.TabIndex = 3
        '
        'Label174
        '
        Me.Label174.AutoSize = True
        Me.Label174.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label174.Location = New System.Drawing.Point(463, 40)
        Me.Label174.Name = "Label174"
        Me.Label174.Size = New System.Drawing.Size(71, 20)
        Me.Label174.TabIndex = 2
        Me.Label174.Text = "Passed"
        '
        'optionVersionELKFull
        '
        Me.optionVersionELKFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionELKFull.FormattingEnabled = True
        Me.optionVersionELKFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionELKFull.Name = "optionVersionELKFull"
        Me.optionVersionELKFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionELKFull.TabIndex = 1
        '
        'Label175
        '
        Me.Label175.AutoSize = True
        Me.Label175.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label175.Location = New System.Drawing.Point(104, 37)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(73, 20)
        Me.Label175.TabIndex = 0
        Me.Label175.Text = "Version"
        '
        'TabPage32
        '
        Me.TabPage32.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage32.Controls.Add(Me.optionDefectStateELKRegression)
        Me.TabPage32.Controls.Add(Me.Label176)
        Me.TabPage32.Controls.Add(Me.Label177)
        Me.TabPage32.Controls.Add(Me.optionDefectIdELKRegression)
        Me.TabPage32.Controls.Add(Me.Label178)
        Me.TabPage32.Controls.Add(Me.optionDefectKindELKRegression)
        Me.TabPage32.Controls.Add(Me.Label179)
        Me.TabPage32.Controls.Add(Me.optionPtIdELKRegression)
        Me.TabPage32.Controls.Add(Me.Label180)
        Me.TabPage32.Controls.Add(Me.optionFailedELKRegression)
        Me.TabPage32.Controls.Add(Me.Label181)
        Me.TabPage32.Controls.Add(Me.optionPassedELKRegression)
        Me.TabPage32.Controls.Add(Me.optionPtStateELKRegression)
        Me.TabPage32.Controls.Add(Me.Label182)
        Me.TabPage32.Controls.Add(Me.optionVersionELKRegression)
        Me.TabPage32.Controls.Add(Me.Label183)
        Me.TabPage32.Location = New System.Drawing.Point(4, 25)
        Me.TabPage32.Name = "TabPage32"
        Me.TabPage32.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage32.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage32.TabIndex = 1
        Me.TabPage32.Text = "REGRESSION"
        '
        'optionDefectStateELKRegression
        '
        Me.optionDefectStateELKRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateELKRegression.FormattingEnabled = True
        Me.optionDefectStateELKRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateELKRegression.Name = "optionDefectStateELKRegression"
        Me.optionDefectStateELKRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateELKRegression.TabIndex = 32
        '
        'Label176
        '
        Me.Label176.AutoSize = True
        Me.Label176.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label176.Location = New System.Drawing.Point(762, 144)
        Me.Label176.Name = "Label176"
        Me.Label176.Size = New System.Drawing.Size(53, 20)
        Me.Label176.TabIndex = 31
        Me.Label176.Text = "State"
        '
        'Label177
        '
        Me.Label177.AutoSize = True
        Me.Label177.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label177.Location = New System.Drawing.Point(104, 141)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(86, 20)
        Me.Label177.TabIndex = 30
        Me.Label177.Text = "Defect id"
        '
        'optionDefectIdELKRegression
        '
        Me.optionDefectIdELKRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdELKRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdELKRegression.Name = "optionDefectIdELKRegression"
        Me.optionDefectIdELKRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdELKRegression.TabIndex = 29
        '
        'Label178
        '
        Me.Label178.AutoSize = True
        Me.Label178.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label178.Location = New System.Drawing.Point(463, 142)
        Me.Label178.Name = "Label178"
        Me.Label178.Size = New System.Drawing.Size(46, 20)
        Me.Label178.TabIndex = 28
        Me.Label178.Text = "Kind"
        '
        'optionDefectKindELKRegression
        '
        Me.optionDefectKindELKRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindELKRegression.FormattingEnabled = True
        Me.optionDefectKindELKRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindELKRegression.Name = "optionDefectKindELKRegression"
        Me.optionDefectKindELKRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindELKRegression.TabIndex = 27
        '
        'Label179
        '
        Me.Label179.AutoSize = True
        Me.Label179.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label179.Location = New System.Drawing.Point(104, 88)
        Me.Label179.Name = "Label179"
        Me.Label179.Size = New System.Drawing.Size(53, 20)
        Me.Label179.TabIndex = 26
        Me.Label179.Text = "PT id"
        '
        'optionPtIdELKRegression
        '
        Me.optionPtIdELKRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdELKRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdELKRegression.Name = "optionPtIdELKRegression"
        Me.optionPtIdELKRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdELKRegression.TabIndex = 25
        '
        'Label180
        '
        Me.Label180.AutoSize = True
        Me.Label180.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label180.Location = New System.Drawing.Point(463, 92)
        Me.Label180.Name = "Label180"
        Me.Label180.Size = New System.Drawing.Size(53, 20)
        Me.Label180.TabIndex = 24
        Me.Label180.Text = "State"
        '
        'optionFailedELKRegression
        '
        Me.optionFailedELKRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedELKRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedELKRegression.Name = "optionFailedELKRegression"
        Me.optionFailedELKRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedELKRegression.TabIndex = 23
        '
        'Label181
        '
        Me.Label181.AutoSize = True
        Me.Label181.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label181.Location = New System.Drawing.Point(762, 42)
        Me.Label181.Name = "Label181"
        Me.Label181.Size = New System.Drawing.Size(60, 20)
        Me.Label181.TabIndex = 22
        Me.Label181.Text = "Failed"
        '
        'optionPassedELKRegression
        '
        Me.optionPassedELKRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedELKRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedELKRegression.Name = "optionPassedELKRegression"
        Me.optionPassedELKRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedELKRegression.TabIndex = 21
        '
        'optionPtStateELKRegression
        '
        Me.optionPtStateELKRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateELKRegression.FormattingEnabled = True
        Me.optionPtStateELKRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateELKRegression.Name = "optionPtStateELKRegression"
        Me.optionPtStateELKRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateELKRegression.TabIndex = 20
        '
        'Label182
        '
        Me.Label182.AutoSize = True
        Me.Label182.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label182.Location = New System.Drawing.Point(463, 40)
        Me.Label182.Name = "Label182"
        Me.Label182.Size = New System.Drawing.Size(71, 20)
        Me.Label182.TabIndex = 19
        Me.Label182.Text = "Passed"
        '
        'optionVersionELKRegression
        '
        Me.optionVersionELKRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionELKRegression.FormattingEnabled = True
        Me.optionVersionELKRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionELKRegression.Name = "optionVersionELKRegression"
        Me.optionVersionELKRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionELKRegression.TabIndex = 18
        '
        'Label183
        '
        Me.Label183.AutoSize = True
        Me.Label183.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label183.Location = New System.Drawing.Point(104, 37)
        Me.Label183.Name = "Label183"
        Me.Label183.Size = New System.Drawing.Size(73, 20)
        Me.Label183.TabIndex = 17
        Me.Label183.Text = "Version"
        '
        'TabPage33
        '
        Me.TabPage33.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage33.Controls.Add(Me.optionDefectStateELKDelta)
        Me.TabPage33.Controls.Add(Me.Label184)
        Me.TabPage33.Controls.Add(Me.Label185)
        Me.TabPage33.Controls.Add(Me.optionDefectIdELKDelta)
        Me.TabPage33.Controls.Add(Me.Label186)
        Me.TabPage33.Controls.Add(Me.optionDefectKindELKDelta)
        Me.TabPage33.Controls.Add(Me.Label187)
        Me.TabPage33.Controls.Add(Me.optionPtIdELKDelta)
        Me.TabPage33.Controls.Add(Me.Label188)
        Me.TabPage33.Controls.Add(Me.optionFailedELKDelta)
        Me.TabPage33.Controls.Add(Me.Label189)
        Me.TabPage33.Controls.Add(Me.optionPassedELKDelta)
        Me.TabPage33.Controls.Add(Me.optionPtStateELKDelta)
        Me.TabPage33.Controls.Add(Me.Label190)
        Me.TabPage33.Controls.Add(Me.optionVersionELKDelta)
        Me.TabPage33.Controls.Add(Me.Label191)
        Me.TabPage33.Location = New System.Drawing.Point(4, 25)
        Me.TabPage33.Name = "TabPage33"
        Me.TabPage33.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage33.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage33.TabIndex = 2
        Me.TabPage33.Text = "DELTA"
        '
        'optionDefectStateELKDelta
        '
        Me.optionDefectStateELKDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateELKDelta.FormattingEnabled = True
        Me.optionDefectStateELKDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateELKDelta.Name = "optionDefectStateELKDelta"
        Me.optionDefectStateELKDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateELKDelta.TabIndex = 32
        '
        'Label184
        '
        Me.Label184.AutoSize = True
        Me.Label184.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label184.Location = New System.Drawing.Point(762, 144)
        Me.Label184.Name = "Label184"
        Me.Label184.Size = New System.Drawing.Size(53, 20)
        Me.Label184.TabIndex = 31
        Me.Label184.Text = "State"
        '
        'Label185
        '
        Me.Label185.AutoSize = True
        Me.Label185.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label185.Location = New System.Drawing.Point(104, 141)
        Me.Label185.Name = "Label185"
        Me.Label185.Size = New System.Drawing.Size(86, 20)
        Me.Label185.TabIndex = 30
        Me.Label185.Text = "Defect id"
        '
        'optionDefectIdELKDelta
        '
        Me.optionDefectIdELKDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdELKDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdELKDelta.Name = "optionDefectIdELKDelta"
        Me.optionDefectIdELKDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdELKDelta.TabIndex = 29
        '
        'Label186
        '
        Me.Label186.AutoSize = True
        Me.Label186.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label186.Location = New System.Drawing.Point(463, 142)
        Me.Label186.Name = "Label186"
        Me.Label186.Size = New System.Drawing.Size(46, 20)
        Me.Label186.TabIndex = 28
        Me.Label186.Text = "Kind"
        '
        'optionDefectKindELKDelta
        '
        Me.optionDefectKindELKDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindELKDelta.FormattingEnabled = True
        Me.optionDefectKindELKDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindELKDelta.Name = "optionDefectKindELKDelta"
        Me.optionDefectKindELKDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindELKDelta.TabIndex = 27
        '
        'Label187
        '
        Me.Label187.AutoSize = True
        Me.Label187.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label187.Location = New System.Drawing.Point(104, 88)
        Me.Label187.Name = "Label187"
        Me.Label187.Size = New System.Drawing.Size(53, 20)
        Me.Label187.TabIndex = 26
        Me.Label187.Text = "PT id"
        '
        'optionPtIdELKDelta
        '
        Me.optionPtIdELKDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdELKDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdELKDelta.Name = "optionPtIdELKDelta"
        Me.optionPtIdELKDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdELKDelta.TabIndex = 25
        '
        'Label188
        '
        Me.Label188.AutoSize = True
        Me.Label188.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label188.Location = New System.Drawing.Point(463, 92)
        Me.Label188.Name = "Label188"
        Me.Label188.Size = New System.Drawing.Size(53, 20)
        Me.Label188.TabIndex = 24
        Me.Label188.Text = "State"
        '
        'optionFailedELKDelta
        '
        Me.optionFailedELKDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedELKDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedELKDelta.Name = "optionFailedELKDelta"
        Me.optionFailedELKDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedELKDelta.TabIndex = 23
        '
        'Label189
        '
        Me.Label189.AutoSize = True
        Me.Label189.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label189.Location = New System.Drawing.Point(762, 42)
        Me.Label189.Name = "Label189"
        Me.Label189.Size = New System.Drawing.Size(60, 20)
        Me.Label189.TabIndex = 22
        Me.Label189.Text = "Failed"
        '
        'optionPassedELKDelta
        '
        Me.optionPassedELKDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedELKDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedELKDelta.Name = "optionPassedELKDelta"
        Me.optionPassedELKDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedELKDelta.TabIndex = 21
        '
        'optionPtStateELKDelta
        '
        Me.optionPtStateELKDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateELKDelta.FormattingEnabled = True
        Me.optionPtStateELKDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateELKDelta.Name = "optionPtStateELKDelta"
        Me.optionPtStateELKDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateELKDelta.TabIndex = 20
        '
        'Label190
        '
        Me.Label190.AutoSize = True
        Me.Label190.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label190.Location = New System.Drawing.Point(463, 40)
        Me.Label190.Name = "Label190"
        Me.Label190.Size = New System.Drawing.Size(71, 20)
        Me.Label190.TabIndex = 19
        Me.Label190.Text = "Passed"
        '
        'optionVersionELKDelta
        '
        Me.optionVersionELKDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionELKDelta.FormattingEnabled = True
        Me.optionVersionELKDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionELKDelta.Name = "optionVersionELKDelta"
        Me.optionVersionELKDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionELKDelta.TabIndex = 18
        '
        'Label191
        '
        Me.Label191.AutoSize = True
        Me.Label191.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label191.Location = New System.Drawing.Point(104, 37)
        Me.Label191.Name = "Label191"
        Me.Label191.Size = New System.Drawing.Size(73, 20)
        Me.Label191.TabIndex = 17
        Me.Label191.Text = "Version"
        '
        'TabPage8
        '
        Me.TabPage8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage8.Controls.Add(Me.Panel9)
        Me.TabPage8.Controls.Add(Me.TabControl9)
        Me.TabPage8.Location = New System.Drawing.Point(4, 4)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "TabPage8"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.optionLabTTJA)
        Me.Panel9.Controls.Add(Me.Label192)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel9.Location = New System.Drawing.Point(3, 219)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(1130, 35)
        Me.Panel9.TabIndex = 3
        '
        'optionLabTTJA
        '
        Me.optionLabTTJA.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTTJA.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTTJA.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTTJA.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTTJA.Name = "optionLabTTJA"
        Me.optionLabTTJA.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTTJA.TabIndex = 14
        '
        'Label192
        '
        Me.Label192.AutoSize = True
        Me.Label192.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label192.Location = New System.Drawing.Point(108, 8)
        Me.Label192.Name = "Label192"
        Me.Label192.Size = New System.Drawing.Size(94, 20)
        Me.Label192.TabIndex = 14
        Me.Label192.Text = "LabT_TJA"
        '
        'TabControl9
        '
        Me.TabControl9.Controls.Add(Me.TabPage34)
        Me.TabControl9.Controls.Add(Me.TabPage35)
        Me.TabControl9.Controls.Add(Me.TabPage36)
        Me.TabControl9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl9.Location = New System.Drawing.Point(3, 3)
        Me.TabControl9.Name = "TabControl9"
        Me.TabControl9.SelectedIndex = 0
        Me.TabControl9.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl9.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl9.TabIndex = 2
        '
        'TabPage34
        '
        Me.TabPage34.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage34.Controls.Add(Me.optionDefectStateTJAFull)
        Me.TabPage34.Controls.Add(Me.Label193)
        Me.TabPage34.Controls.Add(Me.Label194)
        Me.TabPage34.Controls.Add(Me.optionDefectIdTJAFull)
        Me.TabPage34.Controls.Add(Me.Label195)
        Me.TabPage34.Controls.Add(Me.optionDefectKindTJAFull)
        Me.TabPage34.Controls.Add(Me.Label196)
        Me.TabPage34.Controls.Add(Me.optionPtIdTJAFull)
        Me.TabPage34.Controls.Add(Me.Label197)
        Me.TabPage34.Controls.Add(Me.optionFailedTJAFull)
        Me.TabPage34.Controls.Add(Me.Label198)
        Me.TabPage34.Controls.Add(Me.optionPassedTJAFull)
        Me.TabPage34.Controls.Add(Me.optionPtStateTJAFull)
        Me.TabPage34.Controls.Add(Me.Label199)
        Me.TabPage34.Controls.Add(Me.optionVersionTJAFull)
        Me.TabPage34.Controls.Add(Me.Label200)
        Me.TabPage34.Location = New System.Drawing.Point(4, 25)
        Me.TabPage34.Name = "TabPage34"
        Me.TabPage34.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage34.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage34.TabIndex = 0
        Me.TabPage34.Text = "FULL "
        '
        'optionDefectStateTJAFull
        '
        Me.optionDefectStateTJAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateTJAFull.FormattingEnabled = True
        Me.optionDefectStateTJAFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateTJAFull.Name = "optionDefectStateTJAFull"
        Me.optionDefectStateTJAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateTJAFull.TabIndex = 16
        '
        'Label193
        '
        Me.Label193.AutoSize = True
        Me.Label193.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label193.Location = New System.Drawing.Point(762, 144)
        Me.Label193.Name = "Label193"
        Me.Label193.Size = New System.Drawing.Size(53, 20)
        Me.Label193.TabIndex = 15
        Me.Label193.Text = "State"
        '
        'Label194
        '
        Me.Label194.AutoSize = True
        Me.Label194.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label194.Location = New System.Drawing.Point(104, 141)
        Me.Label194.Name = "Label194"
        Me.Label194.Size = New System.Drawing.Size(86, 20)
        Me.Label194.TabIndex = 13
        Me.Label194.Text = "Defect id"
        '
        'optionDefectIdTJAFull
        '
        Me.optionDefectIdTJAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdTJAFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdTJAFull.Name = "optionDefectIdTJAFull"
        Me.optionDefectIdTJAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdTJAFull.TabIndex = 12
        '
        'Label195
        '
        Me.Label195.AutoSize = True
        Me.Label195.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label195.Location = New System.Drawing.Point(463, 142)
        Me.Label195.Name = "Label195"
        Me.Label195.Size = New System.Drawing.Size(46, 20)
        Me.Label195.TabIndex = 11
        Me.Label195.Text = "Kind"
        '
        'optionDefectKindTJAFull
        '
        Me.optionDefectKindTJAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindTJAFull.FormattingEnabled = True
        Me.optionDefectKindTJAFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindTJAFull.Name = "optionDefectKindTJAFull"
        Me.optionDefectKindTJAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindTJAFull.TabIndex = 10
        '
        'Label196
        '
        Me.Label196.AutoSize = True
        Me.Label196.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label196.Location = New System.Drawing.Point(104, 88)
        Me.Label196.Name = "Label196"
        Me.Label196.Size = New System.Drawing.Size(53, 20)
        Me.Label196.TabIndex = 9
        Me.Label196.Text = "PT id"
        '
        'optionPtIdTJAFull
        '
        Me.optionPtIdTJAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdTJAFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdTJAFull.Name = "optionPtIdTJAFull"
        Me.optionPtIdTJAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdTJAFull.TabIndex = 8
        '
        'Label197
        '
        Me.Label197.AutoSize = True
        Me.Label197.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label197.Location = New System.Drawing.Point(463, 92)
        Me.Label197.Name = "Label197"
        Me.Label197.Size = New System.Drawing.Size(53, 20)
        Me.Label197.TabIndex = 7
        Me.Label197.Text = "State"
        '
        'optionFailedTJAFull
        '
        Me.optionFailedTJAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedTJAFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedTJAFull.Name = "optionFailedTJAFull"
        Me.optionFailedTJAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedTJAFull.TabIndex = 6
        '
        'Label198
        '
        Me.Label198.AutoSize = True
        Me.Label198.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label198.Location = New System.Drawing.Point(762, 42)
        Me.Label198.Name = "Label198"
        Me.Label198.Size = New System.Drawing.Size(60, 20)
        Me.Label198.TabIndex = 5
        Me.Label198.Text = "Failed"
        '
        'optionPassedTJAFull
        '
        Me.optionPassedTJAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedTJAFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedTJAFull.Name = "optionPassedTJAFull"
        Me.optionPassedTJAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedTJAFull.TabIndex = 4
        '
        'optionPtStateTJAFull
        '
        Me.optionPtStateTJAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateTJAFull.FormattingEnabled = True
        Me.optionPtStateTJAFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateTJAFull.Name = "optionPtStateTJAFull"
        Me.optionPtStateTJAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateTJAFull.TabIndex = 3
        '
        'Label199
        '
        Me.Label199.AutoSize = True
        Me.Label199.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label199.Location = New System.Drawing.Point(463, 40)
        Me.Label199.Name = "Label199"
        Me.Label199.Size = New System.Drawing.Size(71, 20)
        Me.Label199.TabIndex = 2
        Me.Label199.Text = "Passed"
        '
        'optionVersionTJAFull
        '
        Me.optionVersionTJAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionTJAFull.FormattingEnabled = True
        Me.optionVersionTJAFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionTJAFull.Name = "optionVersionTJAFull"
        Me.optionVersionTJAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionTJAFull.TabIndex = 1
        '
        'Label200
        '
        Me.Label200.AutoSize = True
        Me.Label200.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label200.Location = New System.Drawing.Point(104, 37)
        Me.Label200.Name = "Label200"
        Me.Label200.Size = New System.Drawing.Size(73, 20)
        Me.Label200.TabIndex = 0
        Me.Label200.Text = "Version"
        '
        'TabPage35
        '
        Me.TabPage35.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage35.Controls.Add(Me.optionDefectStateTJARegression)
        Me.TabPage35.Controls.Add(Me.Label201)
        Me.TabPage35.Controls.Add(Me.Label202)
        Me.TabPage35.Controls.Add(Me.optionDefectIdTJARegression)
        Me.TabPage35.Controls.Add(Me.Label203)
        Me.TabPage35.Controls.Add(Me.optionDefectKindTJARegression)
        Me.TabPage35.Controls.Add(Me.Label204)
        Me.TabPage35.Controls.Add(Me.optionPtIdTJARegression)
        Me.TabPage35.Controls.Add(Me.Label205)
        Me.TabPage35.Controls.Add(Me.optionFailedTJARegression)
        Me.TabPage35.Controls.Add(Me.Label206)
        Me.TabPage35.Controls.Add(Me.optionPassedTJARegression)
        Me.TabPage35.Controls.Add(Me.optionPtStateTJARegression)
        Me.TabPage35.Controls.Add(Me.Label207)
        Me.TabPage35.Controls.Add(Me.optionVersionTJARegression)
        Me.TabPage35.Controls.Add(Me.Label208)
        Me.TabPage35.Location = New System.Drawing.Point(4, 25)
        Me.TabPage35.Name = "TabPage35"
        Me.TabPage35.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage35.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage35.TabIndex = 1
        Me.TabPage35.Text = "REGRESSION"
        '
        'optionDefectStateTJARegression
        '
        Me.optionDefectStateTJARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateTJARegression.FormattingEnabled = True
        Me.optionDefectStateTJARegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateTJARegression.Name = "optionDefectStateTJARegression"
        Me.optionDefectStateTJARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateTJARegression.TabIndex = 32
        '
        'Label201
        '
        Me.Label201.AutoSize = True
        Me.Label201.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label201.Location = New System.Drawing.Point(762, 144)
        Me.Label201.Name = "Label201"
        Me.Label201.Size = New System.Drawing.Size(53, 20)
        Me.Label201.TabIndex = 31
        Me.Label201.Text = "State"
        '
        'Label202
        '
        Me.Label202.AutoSize = True
        Me.Label202.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label202.Location = New System.Drawing.Point(104, 141)
        Me.Label202.Name = "Label202"
        Me.Label202.Size = New System.Drawing.Size(86, 20)
        Me.Label202.TabIndex = 30
        Me.Label202.Text = "Defect id"
        '
        'optionDefectIdTJARegression
        '
        Me.optionDefectIdTJARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdTJARegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdTJARegression.Name = "optionDefectIdTJARegression"
        Me.optionDefectIdTJARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdTJARegression.TabIndex = 29
        '
        'Label203
        '
        Me.Label203.AutoSize = True
        Me.Label203.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label203.Location = New System.Drawing.Point(463, 142)
        Me.Label203.Name = "Label203"
        Me.Label203.Size = New System.Drawing.Size(46, 20)
        Me.Label203.TabIndex = 28
        Me.Label203.Text = "Kind"
        '
        'optionDefectKindTJARegression
        '
        Me.optionDefectKindTJARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindTJARegression.FormattingEnabled = True
        Me.optionDefectKindTJARegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindTJARegression.Name = "optionDefectKindTJARegression"
        Me.optionDefectKindTJARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindTJARegression.TabIndex = 27
        '
        'Label204
        '
        Me.Label204.AutoSize = True
        Me.Label204.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label204.Location = New System.Drawing.Point(104, 88)
        Me.Label204.Name = "Label204"
        Me.Label204.Size = New System.Drawing.Size(53, 20)
        Me.Label204.TabIndex = 26
        Me.Label204.Text = "PT id"
        '
        'optionPtIdTJARegression
        '
        Me.optionPtIdTJARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdTJARegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdTJARegression.Name = "optionPtIdTJARegression"
        Me.optionPtIdTJARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdTJARegression.TabIndex = 25
        '
        'Label205
        '
        Me.Label205.AutoSize = True
        Me.Label205.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label205.Location = New System.Drawing.Point(463, 92)
        Me.Label205.Name = "Label205"
        Me.Label205.Size = New System.Drawing.Size(53, 20)
        Me.Label205.TabIndex = 24
        Me.Label205.Text = "State"
        '
        'optionFailedTJARegression
        '
        Me.optionFailedTJARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedTJARegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedTJARegression.Name = "optionFailedTJARegression"
        Me.optionFailedTJARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedTJARegression.TabIndex = 23
        '
        'Label206
        '
        Me.Label206.AutoSize = True
        Me.Label206.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label206.Location = New System.Drawing.Point(762, 42)
        Me.Label206.Name = "Label206"
        Me.Label206.Size = New System.Drawing.Size(60, 20)
        Me.Label206.TabIndex = 22
        Me.Label206.Text = "Failed"
        '
        'optionPassedTJARegression
        '
        Me.optionPassedTJARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedTJARegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedTJARegression.Name = "optionPassedTJARegression"
        Me.optionPassedTJARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedTJARegression.TabIndex = 21
        '
        'optionPtStateTJARegression
        '
        Me.optionPtStateTJARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateTJARegression.FormattingEnabled = True
        Me.optionPtStateTJARegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateTJARegression.Name = "optionPtStateTJARegression"
        Me.optionPtStateTJARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateTJARegression.TabIndex = 20
        '
        'Label207
        '
        Me.Label207.AutoSize = True
        Me.Label207.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label207.Location = New System.Drawing.Point(463, 40)
        Me.Label207.Name = "Label207"
        Me.Label207.Size = New System.Drawing.Size(71, 20)
        Me.Label207.TabIndex = 19
        Me.Label207.Text = "Passed"
        '
        'optionVersionTJARegression
        '
        Me.optionVersionTJARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionTJARegression.FormattingEnabled = True
        Me.optionVersionTJARegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionTJARegression.Name = "optionVersionTJARegression"
        Me.optionVersionTJARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionTJARegression.TabIndex = 18
        '
        'Label208
        '
        Me.Label208.AutoSize = True
        Me.Label208.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label208.Location = New System.Drawing.Point(104, 37)
        Me.Label208.Name = "Label208"
        Me.Label208.Size = New System.Drawing.Size(73, 20)
        Me.Label208.TabIndex = 17
        Me.Label208.Text = "Version"
        '
        'TabPage36
        '
        Me.TabPage36.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage36.Controls.Add(Me.optionDefectStateTJADelta)
        Me.TabPage36.Controls.Add(Me.Label209)
        Me.TabPage36.Controls.Add(Me.Label210)
        Me.TabPage36.Controls.Add(Me.optionDefectIdTJADelta)
        Me.TabPage36.Controls.Add(Me.Label211)
        Me.TabPage36.Controls.Add(Me.optionDefectKindTJADelta)
        Me.TabPage36.Controls.Add(Me.Label212)
        Me.TabPage36.Controls.Add(Me.optionPtIdTJADelta)
        Me.TabPage36.Controls.Add(Me.Label213)
        Me.TabPage36.Controls.Add(Me.optionFailedTJADelta)
        Me.TabPage36.Controls.Add(Me.Label214)
        Me.TabPage36.Controls.Add(Me.optionPassedTJADelta)
        Me.TabPage36.Controls.Add(Me.optionPtStateTJADelta)
        Me.TabPage36.Controls.Add(Me.Label215)
        Me.TabPage36.Controls.Add(Me.optionVersionTJADelta)
        Me.TabPage36.Controls.Add(Me.Label216)
        Me.TabPage36.Location = New System.Drawing.Point(4, 25)
        Me.TabPage36.Name = "TabPage36"
        Me.TabPage36.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage36.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage36.TabIndex = 2
        Me.TabPage36.Text = "DELTA"
        '
        'optionDefectStateTJADelta
        '
        Me.optionDefectStateTJADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateTJADelta.FormattingEnabled = True
        Me.optionDefectStateTJADelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateTJADelta.Name = "optionDefectStateTJADelta"
        Me.optionDefectStateTJADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateTJADelta.TabIndex = 32
        '
        'Label209
        '
        Me.Label209.AutoSize = True
        Me.Label209.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label209.Location = New System.Drawing.Point(762, 144)
        Me.Label209.Name = "Label209"
        Me.Label209.Size = New System.Drawing.Size(53, 20)
        Me.Label209.TabIndex = 31
        Me.Label209.Text = "State"
        '
        'Label210
        '
        Me.Label210.AutoSize = True
        Me.Label210.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label210.Location = New System.Drawing.Point(104, 141)
        Me.Label210.Name = "Label210"
        Me.Label210.Size = New System.Drawing.Size(86, 20)
        Me.Label210.TabIndex = 30
        Me.Label210.Text = "Defect id"
        '
        'optionDefectIdTJADelta
        '
        Me.optionDefectIdTJADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdTJADelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdTJADelta.Name = "optionDefectIdTJADelta"
        Me.optionDefectIdTJADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdTJADelta.TabIndex = 29
        '
        'Label211
        '
        Me.Label211.AutoSize = True
        Me.Label211.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label211.Location = New System.Drawing.Point(463, 142)
        Me.Label211.Name = "Label211"
        Me.Label211.Size = New System.Drawing.Size(46, 20)
        Me.Label211.TabIndex = 28
        Me.Label211.Text = "Kind"
        '
        'optionDefectKindTJADelta
        '
        Me.optionDefectKindTJADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindTJADelta.FormattingEnabled = True
        Me.optionDefectKindTJADelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindTJADelta.Name = "optionDefectKindTJADelta"
        Me.optionDefectKindTJADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindTJADelta.TabIndex = 27
        '
        'Label212
        '
        Me.Label212.AutoSize = True
        Me.Label212.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label212.Location = New System.Drawing.Point(104, 88)
        Me.Label212.Name = "Label212"
        Me.Label212.Size = New System.Drawing.Size(53, 20)
        Me.Label212.TabIndex = 26
        Me.Label212.Text = "PT id"
        '
        'optionPtIdTJADelta
        '
        Me.optionPtIdTJADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdTJADelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdTJADelta.Name = "optionPtIdTJADelta"
        Me.optionPtIdTJADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdTJADelta.TabIndex = 25
        '
        'Label213
        '
        Me.Label213.AutoSize = True
        Me.Label213.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label213.Location = New System.Drawing.Point(463, 92)
        Me.Label213.Name = "Label213"
        Me.Label213.Size = New System.Drawing.Size(53, 20)
        Me.Label213.TabIndex = 24
        Me.Label213.Text = "State"
        '
        'optionFailedTJADelta
        '
        Me.optionFailedTJADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedTJADelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedTJADelta.Name = "optionFailedTJADelta"
        Me.optionFailedTJADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedTJADelta.TabIndex = 23
        '
        'Label214
        '
        Me.Label214.AutoSize = True
        Me.Label214.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label214.Location = New System.Drawing.Point(762, 42)
        Me.Label214.Name = "Label214"
        Me.Label214.Size = New System.Drawing.Size(60, 20)
        Me.Label214.TabIndex = 22
        Me.Label214.Text = "Failed"
        '
        'optionPassedTJADelta
        '
        Me.optionPassedTJADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedTJADelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedTJADelta.Name = "optionPassedTJADelta"
        Me.optionPassedTJADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedTJADelta.TabIndex = 21
        '
        'optionPtStateTJADelta
        '
        Me.optionPtStateTJADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateTJADelta.FormattingEnabled = True
        Me.optionPtStateTJADelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateTJADelta.Name = "optionPtStateTJADelta"
        Me.optionPtStateTJADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateTJADelta.TabIndex = 20
        '
        'Label215
        '
        Me.Label215.AutoSize = True
        Me.Label215.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label215.Location = New System.Drawing.Point(463, 40)
        Me.Label215.Name = "Label215"
        Me.Label215.Size = New System.Drawing.Size(71, 20)
        Me.Label215.TabIndex = 19
        Me.Label215.Text = "Passed"
        '
        'optionVersionTJADelta
        '
        Me.optionVersionTJADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionTJADelta.FormattingEnabled = True
        Me.optionVersionTJADelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionTJADelta.Name = "optionVersionTJADelta"
        Me.optionVersionTJADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionTJADelta.TabIndex = 18
        '
        'Label216
        '
        Me.Label216.AutoSize = True
        Me.Label216.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label216.Location = New System.Drawing.Point(104, 37)
        Me.Label216.Name = "Label216"
        Me.Label216.Size = New System.Drawing.Size(73, 20)
        Me.Label216.TabIndex = 17
        Me.Label216.Text = "Version"
        '
        'TabPage9
        '
        Me.TabPage9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage9.Controls.Add(Me.Panel10)
        Me.TabPage9.Controls.Add(Me.TabControl10)
        Me.TabPage9.Location = New System.Drawing.Point(4, 4)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "TabPage9"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.optionLabTSLA)
        Me.Panel10.Controls.Add(Me.Label217)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel10.Location = New System.Drawing.Point(3, 219)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(1130, 35)
        Me.Panel10.TabIndex = 3
        '
        'optionLabTSLA
        '
        Me.optionLabTSLA.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTSLA.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTSLA.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTSLA.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTSLA.Name = "optionLabTSLA"
        Me.optionLabTSLA.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTSLA.TabIndex = 14
        '
        'Label217
        '
        Me.Label217.AutoSize = True
        Me.Label217.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label217.Location = New System.Drawing.Point(108, 8)
        Me.Label217.Name = "Label217"
        Me.Label217.Size = New System.Drawing.Size(96, 20)
        Me.Label217.TabIndex = 14
        Me.Label217.Text = "LabT_SLA"
        '
        'TabControl10
        '
        Me.TabControl10.Controls.Add(Me.TabPage37)
        Me.TabControl10.Controls.Add(Me.TabPage38)
        Me.TabControl10.Controls.Add(Me.TabPage39)
        Me.TabControl10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl10.Location = New System.Drawing.Point(3, 3)
        Me.TabControl10.Name = "TabControl10"
        Me.TabControl10.SelectedIndex = 0
        Me.TabControl10.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl10.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl10.TabIndex = 2
        '
        'TabPage37
        '
        Me.TabPage37.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage37.Controls.Add(Me.optionDefectStateSLAFull)
        Me.TabPage37.Controls.Add(Me.Label218)
        Me.TabPage37.Controls.Add(Me.Label219)
        Me.TabPage37.Controls.Add(Me.optionDefectIdSLAFull)
        Me.TabPage37.Controls.Add(Me.Label220)
        Me.TabPage37.Controls.Add(Me.optionDefectKindSLAFull)
        Me.TabPage37.Controls.Add(Me.Label221)
        Me.TabPage37.Controls.Add(Me.optionPtIdSLAFull)
        Me.TabPage37.Controls.Add(Me.Label222)
        Me.TabPage37.Controls.Add(Me.optionFailedSLAFull)
        Me.TabPage37.Controls.Add(Me.Label223)
        Me.TabPage37.Controls.Add(Me.optionPassedSLAFull)
        Me.TabPage37.Controls.Add(Me.optionPtStateSLAFull)
        Me.TabPage37.Controls.Add(Me.Label224)
        Me.TabPage37.Controls.Add(Me.optionVersionSLAFull)
        Me.TabPage37.Controls.Add(Me.Label225)
        Me.TabPage37.Location = New System.Drawing.Point(4, 25)
        Me.TabPage37.Name = "TabPage37"
        Me.TabPage37.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage37.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage37.TabIndex = 0
        Me.TabPage37.Text = "FULL "
        '
        'optionDefectStateSLAFull
        '
        Me.optionDefectStateSLAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSLAFull.FormattingEnabled = True
        Me.optionDefectStateSLAFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSLAFull.Name = "optionDefectStateSLAFull"
        Me.optionDefectStateSLAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSLAFull.TabIndex = 16
        '
        'Label218
        '
        Me.Label218.AutoSize = True
        Me.Label218.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label218.Location = New System.Drawing.Point(762, 144)
        Me.Label218.Name = "Label218"
        Me.Label218.Size = New System.Drawing.Size(53, 20)
        Me.Label218.TabIndex = 15
        Me.Label218.Text = "State"
        '
        'Label219
        '
        Me.Label219.AutoSize = True
        Me.Label219.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label219.Location = New System.Drawing.Point(104, 141)
        Me.Label219.Name = "Label219"
        Me.Label219.Size = New System.Drawing.Size(86, 20)
        Me.Label219.TabIndex = 13
        Me.Label219.Text = "Defect id"
        '
        'optionDefectIdSLAFull
        '
        Me.optionDefectIdSLAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSLAFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSLAFull.Name = "optionDefectIdSLAFull"
        Me.optionDefectIdSLAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSLAFull.TabIndex = 12
        '
        'Label220
        '
        Me.Label220.AutoSize = True
        Me.Label220.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label220.Location = New System.Drawing.Point(463, 142)
        Me.Label220.Name = "Label220"
        Me.Label220.Size = New System.Drawing.Size(46, 20)
        Me.Label220.TabIndex = 11
        Me.Label220.Text = "Kind"
        '
        'optionDefectKindSLAFull
        '
        Me.optionDefectKindSLAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSLAFull.FormattingEnabled = True
        Me.optionDefectKindSLAFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSLAFull.Name = "optionDefectKindSLAFull"
        Me.optionDefectKindSLAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSLAFull.TabIndex = 10
        '
        'Label221
        '
        Me.Label221.AutoSize = True
        Me.Label221.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label221.Location = New System.Drawing.Point(104, 88)
        Me.Label221.Name = "Label221"
        Me.Label221.Size = New System.Drawing.Size(53, 20)
        Me.Label221.TabIndex = 9
        Me.Label221.Text = "PT id"
        '
        'optionPtIdSLAFull
        '
        Me.optionPtIdSLAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSLAFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSLAFull.Name = "optionPtIdSLAFull"
        Me.optionPtIdSLAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSLAFull.TabIndex = 8
        '
        'Label222
        '
        Me.Label222.AutoSize = True
        Me.Label222.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label222.Location = New System.Drawing.Point(463, 92)
        Me.Label222.Name = "Label222"
        Me.Label222.Size = New System.Drawing.Size(53, 20)
        Me.Label222.TabIndex = 7
        Me.Label222.Text = "State"
        '
        'optionFailedSLAFull
        '
        Me.optionFailedSLAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSLAFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSLAFull.Name = "optionFailedSLAFull"
        Me.optionFailedSLAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSLAFull.TabIndex = 6
        '
        'Label223
        '
        Me.Label223.AutoSize = True
        Me.Label223.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label223.Location = New System.Drawing.Point(762, 42)
        Me.Label223.Name = "Label223"
        Me.Label223.Size = New System.Drawing.Size(60, 20)
        Me.Label223.TabIndex = 5
        Me.Label223.Text = "Failed"
        '
        'optionPassedSLAFull
        '
        Me.optionPassedSLAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSLAFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSLAFull.Name = "optionPassedSLAFull"
        Me.optionPassedSLAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSLAFull.TabIndex = 4
        '
        'optionPtStateSLAFull
        '
        Me.optionPtStateSLAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSLAFull.FormattingEnabled = True
        Me.optionPtStateSLAFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSLAFull.Name = "optionPtStateSLAFull"
        Me.optionPtStateSLAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSLAFull.TabIndex = 3
        '
        'Label224
        '
        Me.Label224.AutoSize = True
        Me.Label224.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label224.Location = New System.Drawing.Point(463, 40)
        Me.Label224.Name = "Label224"
        Me.Label224.Size = New System.Drawing.Size(71, 20)
        Me.Label224.TabIndex = 2
        Me.Label224.Text = "Passed"
        '
        'optionVersionSLAFull
        '
        Me.optionVersionSLAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSLAFull.FormattingEnabled = True
        Me.optionVersionSLAFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSLAFull.Name = "optionVersionSLAFull"
        Me.optionVersionSLAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSLAFull.TabIndex = 1
        '
        'Label225
        '
        Me.Label225.AutoSize = True
        Me.Label225.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label225.Location = New System.Drawing.Point(104, 37)
        Me.Label225.Name = "Label225"
        Me.Label225.Size = New System.Drawing.Size(73, 20)
        Me.Label225.TabIndex = 0
        Me.Label225.Text = "Version"
        '
        'TabPage38
        '
        Me.TabPage38.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage38.Controls.Add(Me.optionDefectStateSLARegression)
        Me.TabPage38.Controls.Add(Me.Label226)
        Me.TabPage38.Controls.Add(Me.Label227)
        Me.TabPage38.Controls.Add(Me.optionDefectIdSLARegression)
        Me.TabPage38.Controls.Add(Me.Label228)
        Me.TabPage38.Controls.Add(Me.optionDefectKindSLARegression)
        Me.TabPage38.Controls.Add(Me.Label229)
        Me.TabPage38.Controls.Add(Me.optionPtIdSLARegression)
        Me.TabPage38.Controls.Add(Me.Label230)
        Me.TabPage38.Controls.Add(Me.optionFailedSLARegression)
        Me.TabPage38.Controls.Add(Me.Label231)
        Me.TabPage38.Controls.Add(Me.optionPassedSLARegression)
        Me.TabPage38.Controls.Add(Me.optionPtStateSLARegression)
        Me.TabPage38.Controls.Add(Me.Label232)
        Me.TabPage38.Controls.Add(Me.optionVersionSLARegression)
        Me.TabPage38.Controls.Add(Me.Label233)
        Me.TabPage38.Location = New System.Drawing.Point(4, 25)
        Me.TabPage38.Name = "TabPage38"
        Me.TabPage38.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage38.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage38.TabIndex = 1
        Me.TabPage38.Text = "REGRESSION"
        '
        'optionDefectStateSLARegression
        '
        Me.optionDefectStateSLARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSLARegression.FormattingEnabled = True
        Me.optionDefectStateSLARegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSLARegression.Name = "optionDefectStateSLARegression"
        Me.optionDefectStateSLARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSLARegression.TabIndex = 32
        '
        'Label226
        '
        Me.Label226.AutoSize = True
        Me.Label226.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label226.Location = New System.Drawing.Point(762, 144)
        Me.Label226.Name = "Label226"
        Me.Label226.Size = New System.Drawing.Size(53, 20)
        Me.Label226.TabIndex = 31
        Me.Label226.Text = "State"
        '
        'Label227
        '
        Me.Label227.AutoSize = True
        Me.Label227.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label227.Location = New System.Drawing.Point(104, 141)
        Me.Label227.Name = "Label227"
        Me.Label227.Size = New System.Drawing.Size(86, 20)
        Me.Label227.TabIndex = 30
        Me.Label227.Text = "Defect id"
        '
        'optionDefectIdSLARegression
        '
        Me.optionDefectIdSLARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSLARegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSLARegression.Name = "optionDefectIdSLARegression"
        Me.optionDefectIdSLARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSLARegression.TabIndex = 29
        '
        'Label228
        '
        Me.Label228.AutoSize = True
        Me.Label228.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label228.Location = New System.Drawing.Point(463, 142)
        Me.Label228.Name = "Label228"
        Me.Label228.Size = New System.Drawing.Size(46, 20)
        Me.Label228.TabIndex = 28
        Me.Label228.Text = "Kind"
        '
        'optionDefectKindSLARegression
        '
        Me.optionDefectKindSLARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSLARegression.FormattingEnabled = True
        Me.optionDefectKindSLARegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSLARegression.Name = "optionDefectKindSLARegression"
        Me.optionDefectKindSLARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSLARegression.TabIndex = 27
        '
        'Label229
        '
        Me.Label229.AutoSize = True
        Me.Label229.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label229.Location = New System.Drawing.Point(104, 88)
        Me.Label229.Name = "Label229"
        Me.Label229.Size = New System.Drawing.Size(53, 20)
        Me.Label229.TabIndex = 26
        Me.Label229.Text = "PT id"
        '
        'optionPtIdSLARegression
        '
        Me.optionPtIdSLARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSLARegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSLARegression.Name = "optionPtIdSLARegression"
        Me.optionPtIdSLARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSLARegression.TabIndex = 25
        '
        'Label230
        '
        Me.Label230.AutoSize = True
        Me.Label230.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label230.Location = New System.Drawing.Point(463, 92)
        Me.Label230.Name = "Label230"
        Me.Label230.Size = New System.Drawing.Size(53, 20)
        Me.Label230.TabIndex = 24
        Me.Label230.Text = "State"
        '
        'optionFailedSLARegression
        '
        Me.optionFailedSLARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSLARegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSLARegression.Name = "optionFailedSLARegression"
        Me.optionFailedSLARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSLARegression.TabIndex = 23
        '
        'Label231
        '
        Me.Label231.AutoSize = True
        Me.Label231.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label231.Location = New System.Drawing.Point(762, 42)
        Me.Label231.Name = "Label231"
        Me.Label231.Size = New System.Drawing.Size(60, 20)
        Me.Label231.TabIndex = 22
        Me.Label231.Text = "Failed"
        '
        'optionPassedSLARegression
        '
        Me.optionPassedSLARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSLARegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSLARegression.Name = "optionPassedSLARegression"
        Me.optionPassedSLARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSLARegression.TabIndex = 21
        '
        'optionPtStateSLARegression
        '
        Me.optionPtStateSLARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSLARegression.FormattingEnabled = True
        Me.optionPtStateSLARegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSLARegression.Name = "optionPtStateSLARegression"
        Me.optionPtStateSLARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSLARegression.TabIndex = 20
        '
        'Label232
        '
        Me.Label232.AutoSize = True
        Me.Label232.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label232.Location = New System.Drawing.Point(463, 40)
        Me.Label232.Name = "Label232"
        Me.Label232.Size = New System.Drawing.Size(71, 20)
        Me.Label232.TabIndex = 19
        Me.Label232.Text = "Passed"
        '
        'optionVersionSLARegression
        '
        Me.optionVersionSLARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSLARegression.FormattingEnabled = True
        Me.optionVersionSLARegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSLARegression.Name = "optionVersionSLARegression"
        Me.optionVersionSLARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSLARegression.TabIndex = 18
        '
        'Label233
        '
        Me.Label233.AutoSize = True
        Me.Label233.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label233.Location = New System.Drawing.Point(104, 37)
        Me.Label233.Name = "Label233"
        Me.Label233.Size = New System.Drawing.Size(73, 20)
        Me.Label233.TabIndex = 17
        Me.Label233.Text = "Version"
        '
        'TabPage39
        '
        Me.TabPage39.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage39.Controls.Add(Me.optionDefectStateSLADelta)
        Me.TabPage39.Controls.Add(Me.Label234)
        Me.TabPage39.Controls.Add(Me.Label235)
        Me.TabPage39.Controls.Add(Me.optionDefectIdSLADelta)
        Me.TabPage39.Controls.Add(Me.Label236)
        Me.TabPage39.Controls.Add(Me.optionDefectKindSLADelta)
        Me.TabPage39.Controls.Add(Me.Label237)
        Me.TabPage39.Controls.Add(Me.optionPtIdSLADelta)
        Me.TabPage39.Controls.Add(Me.Label238)
        Me.TabPage39.Controls.Add(Me.optionFailedSLADelta)
        Me.TabPage39.Controls.Add(Me.Label239)
        Me.TabPage39.Controls.Add(Me.optionPassedSLADelta)
        Me.TabPage39.Controls.Add(Me.optionPtStateSLADelta)
        Me.TabPage39.Controls.Add(Me.Label240)
        Me.TabPage39.Controls.Add(Me.optionVersionSLADelta)
        Me.TabPage39.Controls.Add(Me.Label241)
        Me.TabPage39.Location = New System.Drawing.Point(4, 25)
        Me.TabPage39.Name = "TabPage39"
        Me.TabPage39.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage39.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage39.TabIndex = 2
        Me.TabPage39.Text = "DELTA"
        '
        'optionDefectStateSLADelta
        '
        Me.optionDefectStateSLADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSLADelta.FormattingEnabled = True
        Me.optionDefectStateSLADelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSLADelta.Name = "optionDefectStateSLADelta"
        Me.optionDefectStateSLADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSLADelta.TabIndex = 32
        '
        'Label234
        '
        Me.Label234.AutoSize = True
        Me.Label234.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label234.Location = New System.Drawing.Point(762, 144)
        Me.Label234.Name = "Label234"
        Me.Label234.Size = New System.Drawing.Size(53, 20)
        Me.Label234.TabIndex = 31
        Me.Label234.Text = "State"
        '
        'Label235
        '
        Me.Label235.AutoSize = True
        Me.Label235.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label235.Location = New System.Drawing.Point(104, 141)
        Me.Label235.Name = "Label235"
        Me.Label235.Size = New System.Drawing.Size(86, 20)
        Me.Label235.TabIndex = 30
        Me.Label235.Text = "Defect id"
        '
        'optionDefectIdSLADelta
        '
        Me.optionDefectIdSLADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSLADelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSLADelta.Name = "optionDefectIdSLADelta"
        Me.optionDefectIdSLADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSLADelta.TabIndex = 29
        '
        'Label236
        '
        Me.Label236.AutoSize = True
        Me.Label236.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label236.Location = New System.Drawing.Point(463, 142)
        Me.Label236.Name = "Label236"
        Me.Label236.Size = New System.Drawing.Size(46, 20)
        Me.Label236.TabIndex = 28
        Me.Label236.Text = "Kind"
        '
        'optionDefectKindSLADelta
        '
        Me.optionDefectKindSLADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSLADelta.FormattingEnabled = True
        Me.optionDefectKindSLADelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSLADelta.Name = "optionDefectKindSLADelta"
        Me.optionDefectKindSLADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSLADelta.TabIndex = 27
        '
        'Label237
        '
        Me.Label237.AutoSize = True
        Me.Label237.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label237.Location = New System.Drawing.Point(104, 88)
        Me.Label237.Name = "Label237"
        Me.Label237.Size = New System.Drawing.Size(53, 20)
        Me.Label237.TabIndex = 26
        Me.Label237.Text = "PT id"
        '
        'optionPtIdSLADelta
        '
        Me.optionPtIdSLADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSLADelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSLADelta.Name = "optionPtIdSLADelta"
        Me.optionPtIdSLADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSLADelta.TabIndex = 25
        '
        'Label238
        '
        Me.Label238.AutoSize = True
        Me.Label238.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label238.Location = New System.Drawing.Point(463, 92)
        Me.Label238.Name = "Label238"
        Me.Label238.Size = New System.Drawing.Size(53, 20)
        Me.Label238.TabIndex = 24
        Me.Label238.Text = "State"
        '
        'optionFailedSLADelta
        '
        Me.optionFailedSLADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSLADelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSLADelta.Name = "optionFailedSLADelta"
        Me.optionFailedSLADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSLADelta.TabIndex = 23
        '
        'Label239
        '
        Me.Label239.AutoSize = True
        Me.Label239.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label239.Location = New System.Drawing.Point(762, 42)
        Me.Label239.Name = "Label239"
        Me.Label239.Size = New System.Drawing.Size(60, 20)
        Me.Label239.TabIndex = 22
        Me.Label239.Text = "Failed"
        '
        'optionPassedSLADelta
        '
        Me.optionPassedSLADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSLADelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSLADelta.Name = "optionPassedSLADelta"
        Me.optionPassedSLADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSLADelta.TabIndex = 21
        '
        'optionPtStateSLADelta
        '
        Me.optionPtStateSLADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSLADelta.FormattingEnabled = True
        Me.optionPtStateSLADelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSLADelta.Name = "optionPtStateSLADelta"
        Me.optionPtStateSLADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSLADelta.TabIndex = 20
        '
        'Label240
        '
        Me.Label240.AutoSize = True
        Me.Label240.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label240.Location = New System.Drawing.Point(463, 40)
        Me.Label240.Name = "Label240"
        Me.Label240.Size = New System.Drawing.Size(71, 20)
        Me.Label240.TabIndex = 19
        Me.Label240.Text = "Passed"
        '
        'optionVersionSLADelta
        '
        Me.optionVersionSLADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSLADelta.FormattingEnabled = True
        Me.optionVersionSLADelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSLADelta.Name = "optionVersionSLADelta"
        Me.optionVersionSLADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSLADelta.TabIndex = 18
        '
        'Label241
        '
        Me.Label241.AutoSize = True
        Me.Label241.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label241.Location = New System.Drawing.Point(104, 37)
        Me.Label241.Name = "Label241"
        Me.Label241.Size = New System.Drawing.Size(73, 20)
        Me.Label241.TabIndex = 17
        Me.Label241.Text = "Version"
        '
        'TabPage10
        '
        Me.TabPage10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage10.Controls.Add(Me.Panel11)
        Me.TabPage10.Controls.Add(Me.TabControl11)
        Me.TabPage10.Location = New System.Drawing.Point(4, 4)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage10.TabIndex = 9
        Me.TabPage10.Text = "TabPage10"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.optionLabTHMA)
        Me.Panel11.Controls.Add(Me.Label242)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel11.Location = New System.Drawing.Point(3, 219)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(1130, 35)
        Me.Panel11.TabIndex = 3
        '
        'optionLabTHMA
        '
        Me.optionLabTHMA.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTHMA.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTHMA.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTHMA.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTHMA.Name = "optionLabTHMA"
        Me.optionLabTHMA.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTHMA.TabIndex = 14
        '
        'Label242
        '
        Me.Label242.AutoSize = True
        Me.Label242.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label242.Location = New System.Drawing.Point(108, 8)
        Me.Label242.Name = "Label242"
        Me.Label242.Size = New System.Drawing.Size(102, 20)
        Me.Label242.TabIndex = 14
        Me.Label242.Text = "LabT_HMA"
        '
        'TabControl11
        '
        Me.TabControl11.Controls.Add(Me.TabPage40)
        Me.TabControl11.Controls.Add(Me.TabPage41)
        Me.TabControl11.Controls.Add(Me.TabPage42)
        Me.TabControl11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl11.Location = New System.Drawing.Point(3, 3)
        Me.TabControl11.Name = "TabControl11"
        Me.TabControl11.SelectedIndex = 0
        Me.TabControl11.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl11.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl11.TabIndex = 2
        '
        'TabPage40
        '
        Me.TabPage40.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage40.Controls.Add(Me.optionDefectStateHMAFull)
        Me.TabPage40.Controls.Add(Me.Label243)
        Me.TabPage40.Controls.Add(Me.Label244)
        Me.TabPage40.Controls.Add(Me.optionDefectIdHMAFull)
        Me.TabPage40.Controls.Add(Me.Label245)
        Me.TabPage40.Controls.Add(Me.optionDefectKindHMAFull)
        Me.TabPage40.Controls.Add(Me.Label246)
        Me.TabPage40.Controls.Add(Me.optionPtIdHMAFull)
        Me.TabPage40.Controls.Add(Me.Label247)
        Me.TabPage40.Controls.Add(Me.optionFailedHMAFull)
        Me.TabPage40.Controls.Add(Me.Label248)
        Me.TabPage40.Controls.Add(Me.optionPassedHMAFull)
        Me.TabPage40.Controls.Add(Me.optionPtStateHMAFull)
        Me.TabPage40.Controls.Add(Me.Label249)
        Me.TabPage40.Controls.Add(Me.optionVersionHMAFull)
        Me.TabPage40.Controls.Add(Me.Label250)
        Me.TabPage40.Location = New System.Drawing.Point(4, 25)
        Me.TabPage40.Name = "TabPage40"
        Me.TabPage40.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage40.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage40.TabIndex = 0
        Me.TabPage40.Text = "FULL "
        '
        'optionDefectStateHMAFull
        '
        Me.optionDefectStateHMAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateHMAFull.FormattingEnabled = True
        Me.optionDefectStateHMAFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateHMAFull.Name = "optionDefectStateHMAFull"
        Me.optionDefectStateHMAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateHMAFull.TabIndex = 16
        '
        'Label243
        '
        Me.Label243.AutoSize = True
        Me.Label243.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label243.Location = New System.Drawing.Point(762, 144)
        Me.Label243.Name = "Label243"
        Me.Label243.Size = New System.Drawing.Size(53, 20)
        Me.Label243.TabIndex = 15
        Me.Label243.Text = "State"
        '
        'Label244
        '
        Me.Label244.AutoSize = True
        Me.Label244.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label244.Location = New System.Drawing.Point(104, 141)
        Me.Label244.Name = "Label244"
        Me.Label244.Size = New System.Drawing.Size(86, 20)
        Me.Label244.TabIndex = 13
        Me.Label244.Text = "Defect id"
        '
        'optionDefectIdHMAFull
        '
        Me.optionDefectIdHMAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdHMAFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdHMAFull.Name = "optionDefectIdHMAFull"
        Me.optionDefectIdHMAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdHMAFull.TabIndex = 12
        '
        'Label245
        '
        Me.Label245.AutoSize = True
        Me.Label245.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label245.Location = New System.Drawing.Point(463, 142)
        Me.Label245.Name = "Label245"
        Me.Label245.Size = New System.Drawing.Size(46, 20)
        Me.Label245.TabIndex = 11
        Me.Label245.Text = "Kind"
        '
        'optionDefectKindHMAFull
        '
        Me.optionDefectKindHMAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindHMAFull.FormattingEnabled = True
        Me.optionDefectKindHMAFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindHMAFull.Name = "optionDefectKindHMAFull"
        Me.optionDefectKindHMAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindHMAFull.TabIndex = 10
        '
        'Label246
        '
        Me.Label246.AutoSize = True
        Me.Label246.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label246.Location = New System.Drawing.Point(104, 88)
        Me.Label246.Name = "Label246"
        Me.Label246.Size = New System.Drawing.Size(53, 20)
        Me.Label246.TabIndex = 9
        Me.Label246.Text = "PT id"
        '
        'optionPtIdHMAFull
        '
        Me.optionPtIdHMAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdHMAFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdHMAFull.Name = "optionPtIdHMAFull"
        Me.optionPtIdHMAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdHMAFull.TabIndex = 8
        '
        'Label247
        '
        Me.Label247.AutoSize = True
        Me.Label247.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label247.Location = New System.Drawing.Point(463, 92)
        Me.Label247.Name = "Label247"
        Me.Label247.Size = New System.Drawing.Size(53, 20)
        Me.Label247.TabIndex = 7
        Me.Label247.Text = "State"
        '
        'optionFailedHMAFull
        '
        Me.optionFailedHMAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedHMAFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedHMAFull.Name = "optionFailedHMAFull"
        Me.optionFailedHMAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedHMAFull.TabIndex = 6
        '
        'Label248
        '
        Me.Label248.AutoSize = True
        Me.Label248.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label248.Location = New System.Drawing.Point(762, 42)
        Me.Label248.Name = "Label248"
        Me.Label248.Size = New System.Drawing.Size(60, 20)
        Me.Label248.TabIndex = 5
        Me.Label248.Text = "Failed"
        '
        'optionPassedHMAFull
        '
        Me.optionPassedHMAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedHMAFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedHMAFull.Name = "optionPassedHMAFull"
        Me.optionPassedHMAFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedHMAFull.TabIndex = 4
        '
        'optionPtStateHMAFull
        '
        Me.optionPtStateHMAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateHMAFull.FormattingEnabled = True
        Me.optionPtStateHMAFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateHMAFull.Name = "optionPtStateHMAFull"
        Me.optionPtStateHMAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateHMAFull.TabIndex = 3
        '
        'Label249
        '
        Me.Label249.AutoSize = True
        Me.Label249.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label249.Location = New System.Drawing.Point(463, 40)
        Me.Label249.Name = "Label249"
        Me.Label249.Size = New System.Drawing.Size(71, 20)
        Me.Label249.TabIndex = 2
        Me.Label249.Text = "Passed"
        '
        'optionVersionHMAFull
        '
        Me.optionVersionHMAFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionHMAFull.FormattingEnabled = True
        Me.optionVersionHMAFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionHMAFull.Name = "optionVersionHMAFull"
        Me.optionVersionHMAFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionHMAFull.TabIndex = 1
        '
        'Label250
        '
        Me.Label250.AutoSize = True
        Me.Label250.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label250.Location = New System.Drawing.Point(104, 37)
        Me.Label250.Name = "Label250"
        Me.Label250.Size = New System.Drawing.Size(73, 20)
        Me.Label250.TabIndex = 0
        Me.Label250.Text = "Version"
        '
        'TabPage41
        '
        Me.TabPage41.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage41.Controls.Add(Me.optionDefectStateHMARegression)
        Me.TabPage41.Controls.Add(Me.Label251)
        Me.TabPage41.Controls.Add(Me.Label252)
        Me.TabPage41.Controls.Add(Me.optionDefectIdHMARegression)
        Me.TabPage41.Controls.Add(Me.Label253)
        Me.TabPage41.Controls.Add(Me.optionDefectKindHMARegression)
        Me.TabPage41.Controls.Add(Me.Label254)
        Me.TabPage41.Controls.Add(Me.optionPtIdHMARegression)
        Me.TabPage41.Controls.Add(Me.Label255)
        Me.TabPage41.Controls.Add(Me.optionFailedHMARegression)
        Me.TabPage41.Controls.Add(Me.Label256)
        Me.TabPage41.Controls.Add(Me.optionPassedHMARegression)
        Me.TabPage41.Controls.Add(Me.optionPtStateHMARegression)
        Me.TabPage41.Controls.Add(Me.Label257)
        Me.TabPage41.Controls.Add(Me.optionVersionHMARegression)
        Me.TabPage41.Controls.Add(Me.Label258)
        Me.TabPage41.Location = New System.Drawing.Point(4, 25)
        Me.TabPage41.Name = "TabPage41"
        Me.TabPage41.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage41.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage41.TabIndex = 1
        Me.TabPage41.Text = "REGRESSION"
        '
        'optionDefectStateHMARegression
        '
        Me.optionDefectStateHMARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateHMARegression.FormattingEnabled = True
        Me.optionDefectStateHMARegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateHMARegression.Name = "optionDefectStateHMARegression"
        Me.optionDefectStateHMARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateHMARegression.TabIndex = 32
        '
        'Label251
        '
        Me.Label251.AutoSize = True
        Me.Label251.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label251.Location = New System.Drawing.Point(762, 144)
        Me.Label251.Name = "Label251"
        Me.Label251.Size = New System.Drawing.Size(53, 20)
        Me.Label251.TabIndex = 31
        Me.Label251.Text = "State"
        '
        'Label252
        '
        Me.Label252.AutoSize = True
        Me.Label252.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label252.Location = New System.Drawing.Point(104, 141)
        Me.Label252.Name = "Label252"
        Me.Label252.Size = New System.Drawing.Size(86, 20)
        Me.Label252.TabIndex = 30
        Me.Label252.Text = "Defect id"
        '
        'optionDefectIdHMARegression
        '
        Me.optionDefectIdHMARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdHMARegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdHMARegression.Name = "optionDefectIdHMARegression"
        Me.optionDefectIdHMARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdHMARegression.TabIndex = 29
        '
        'Label253
        '
        Me.Label253.AutoSize = True
        Me.Label253.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label253.Location = New System.Drawing.Point(463, 142)
        Me.Label253.Name = "Label253"
        Me.Label253.Size = New System.Drawing.Size(46, 20)
        Me.Label253.TabIndex = 28
        Me.Label253.Text = "Kind"
        '
        'optionDefectKindHMARegression
        '
        Me.optionDefectKindHMARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindHMARegression.FormattingEnabled = True
        Me.optionDefectKindHMARegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindHMARegression.Name = "optionDefectKindHMARegression"
        Me.optionDefectKindHMARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindHMARegression.TabIndex = 27
        '
        'Label254
        '
        Me.Label254.AutoSize = True
        Me.Label254.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label254.Location = New System.Drawing.Point(104, 88)
        Me.Label254.Name = "Label254"
        Me.Label254.Size = New System.Drawing.Size(53, 20)
        Me.Label254.TabIndex = 26
        Me.Label254.Text = "PT id"
        '
        'optionPtIdHMARegression
        '
        Me.optionPtIdHMARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdHMARegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdHMARegression.Name = "optionPtIdHMARegression"
        Me.optionPtIdHMARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdHMARegression.TabIndex = 25
        '
        'Label255
        '
        Me.Label255.AutoSize = True
        Me.Label255.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label255.Location = New System.Drawing.Point(463, 92)
        Me.Label255.Name = "Label255"
        Me.Label255.Size = New System.Drawing.Size(53, 20)
        Me.Label255.TabIndex = 24
        Me.Label255.Text = "State"
        '
        'optionFailedHMARegression
        '
        Me.optionFailedHMARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedHMARegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedHMARegression.Name = "optionFailedHMARegression"
        Me.optionFailedHMARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedHMARegression.TabIndex = 23
        '
        'Label256
        '
        Me.Label256.AutoSize = True
        Me.Label256.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label256.Location = New System.Drawing.Point(762, 42)
        Me.Label256.Name = "Label256"
        Me.Label256.Size = New System.Drawing.Size(60, 20)
        Me.Label256.TabIndex = 22
        Me.Label256.Text = "Failed"
        '
        'optionPassedHMARegression
        '
        Me.optionPassedHMARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedHMARegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedHMARegression.Name = "optionPassedHMARegression"
        Me.optionPassedHMARegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedHMARegression.TabIndex = 21
        '
        'optionPtStateHMARegression
        '
        Me.optionPtStateHMARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateHMARegression.FormattingEnabled = True
        Me.optionPtStateHMARegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateHMARegression.Name = "optionPtStateHMARegression"
        Me.optionPtStateHMARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateHMARegression.TabIndex = 20
        '
        'Label257
        '
        Me.Label257.AutoSize = True
        Me.Label257.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label257.Location = New System.Drawing.Point(463, 40)
        Me.Label257.Name = "Label257"
        Me.Label257.Size = New System.Drawing.Size(71, 20)
        Me.Label257.TabIndex = 19
        Me.Label257.Text = "Passed"
        '
        'optionVersionHMARegression
        '
        Me.optionVersionHMARegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionHMARegression.FormattingEnabled = True
        Me.optionVersionHMARegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionHMARegression.Name = "optionVersionHMARegression"
        Me.optionVersionHMARegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionHMARegression.TabIndex = 18
        '
        'Label258
        '
        Me.Label258.AutoSize = True
        Me.Label258.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label258.Location = New System.Drawing.Point(104, 37)
        Me.Label258.Name = "Label258"
        Me.Label258.Size = New System.Drawing.Size(73, 20)
        Me.Label258.TabIndex = 17
        Me.Label258.Text = "Version"
        '
        'TabPage42
        '
        Me.TabPage42.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage42.Controls.Add(Me.optionDefectStateHMADelta)
        Me.TabPage42.Controls.Add(Me.Label259)
        Me.TabPage42.Controls.Add(Me.Label260)
        Me.TabPage42.Controls.Add(Me.optionDefectIdHMADelta)
        Me.TabPage42.Controls.Add(Me.Label261)
        Me.TabPage42.Controls.Add(Me.optionDefectKindHMADelta)
        Me.TabPage42.Controls.Add(Me.Label262)
        Me.TabPage42.Controls.Add(Me.optionPtIdHMADelta)
        Me.TabPage42.Controls.Add(Me.Label263)
        Me.TabPage42.Controls.Add(Me.optionFailedHMADelta)
        Me.TabPage42.Controls.Add(Me.Label264)
        Me.TabPage42.Controls.Add(Me.optionPassedHMADelta)
        Me.TabPage42.Controls.Add(Me.optionPtStateHMADelta)
        Me.TabPage42.Controls.Add(Me.Label265)
        Me.TabPage42.Controls.Add(Me.optionVersionHMADelta)
        Me.TabPage42.Controls.Add(Me.Label266)
        Me.TabPage42.Location = New System.Drawing.Point(4, 25)
        Me.TabPage42.Name = "TabPage42"
        Me.TabPage42.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage42.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage42.TabIndex = 2
        Me.TabPage42.Text = "DELTA"
        '
        'optionDefectStateHMADelta
        '
        Me.optionDefectStateHMADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateHMADelta.FormattingEnabled = True
        Me.optionDefectStateHMADelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateHMADelta.Name = "optionDefectStateHMADelta"
        Me.optionDefectStateHMADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateHMADelta.TabIndex = 32
        '
        'Label259
        '
        Me.Label259.AutoSize = True
        Me.Label259.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label259.Location = New System.Drawing.Point(762, 144)
        Me.Label259.Name = "Label259"
        Me.Label259.Size = New System.Drawing.Size(53, 20)
        Me.Label259.TabIndex = 31
        Me.Label259.Text = "State"
        '
        'Label260
        '
        Me.Label260.AutoSize = True
        Me.Label260.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label260.Location = New System.Drawing.Point(104, 141)
        Me.Label260.Name = "Label260"
        Me.Label260.Size = New System.Drawing.Size(86, 20)
        Me.Label260.TabIndex = 30
        Me.Label260.Text = "Defect id"
        '
        'optionDefectIdHMADelta
        '
        Me.optionDefectIdHMADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdHMADelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdHMADelta.Name = "optionDefectIdHMADelta"
        Me.optionDefectIdHMADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdHMADelta.TabIndex = 29
        '
        'Label261
        '
        Me.Label261.AutoSize = True
        Me.Label261.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label261.Location = New System.Drawing.Point(463, 142)
        Me.Label261.Name = "Label261"
        Me.Label261.Size = New System.Drawing.Size(46, 20)
        Me.Label261.TabIndex = 28
        Me.Label261.Text = "Kind"
        '
        'optionDefectKindHMADelta
        '
        Me.optionDefectKindHMADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindHMADelta.FormattingEnabled = True
        Me.optionDefectKindHMADelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindHMADelta.Name = "optionDefectKindHMADelta"
        Me.optionDefectKindHMADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindHMADelta.TabIndex = 27
        '
        'Label262
        '
        Me.Label262.AutoSize = True
        Me.Label262.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label262.Location = New System.Drawing.Point(104, 88)
        Me.Label262.Name = "Label262"
        Me.Label262.Size = New System.Drawing.Size(53, 20)
        Me.Label262.TabIndex = 26
        Me.Label262.Text = "PT id"
        '
        'optionPtIdHMADelta
        '
        Me.optionPtIdHMADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdHMADelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdHMADelta.Name = "optionPtIdHMADelta"
        Me.optionPtIdHMADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdHMADelta.TabIndex = 25
        '
        'Label263
        '
        Me.Label263.AutoSize = True
        Me.Label263.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label263.Location = New System.Drawing.Point(463, 92)
        Me.Label263.Name = "Label263"
        Me.Label263.Size = New System.Drawing.Size(53, 20)
        Me.Label263.TabIndex = 24
        Me.Label263.Text = "State"
        '
        'optionFailedHMADelta
        '
        Me.optionFailedHMADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedHMADelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedHMADelta.Name = "optionFailedHMADelta"
        Me.optionFailedHMADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedHMADelta.TabIndex = 23
        '
        'Label264
        '
        Me.Label264.AutoSize = True
        Me.Label264.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label264.Location = New System.Drawing.Point(762, 42)
        Me.Label264.Name = "Label264"
        Me.Label264.Size = New System.Drawing.Size(60, 20)
        Me.Label264.TabIndex = 22
        Me.Label264.Text = "Failed"
        '
        'optionPassedHMADelta
        '
        Me.optionPassedHMADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedHMADelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedHMADelta.Name = "optionPassedHMADelta"
        Me.optionPassedHMADelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedHMADelta.TabIndex = 21
        '
        'optionPtStateHMADelta
        '
        Me.optionPtStateHMADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateHMADelta.FormattingEnabled = True
        Me.optionPtStateHMADelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateHMADelta.Name = "optionPtStateHMADelta"
        Me.optionPtStateHMADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateHMADelta.TabIndex = 20
        '
        'Label265
        '
        Me.Label265.AutoSize = True
        Me.Label265.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label265.Location = New System.Drawing.Point(463, 40)
        Me.Label265.Name = "Label265"
        Me.Label265.Size = New System.Drawing.Size(71, 20)
        Me.Label265.TabIndex = 19
        Me.Label265.Text = "Passed"
        '
        'optionVersionHMADelta
        '
        Me.optionVersionHMADelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionHMADelta.FormattingEnabled = True
        Me.optionVersionHMADelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionHMADelta.Name = "optionVersionHMADelta"
        Me.optionVersionHMADelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionHMADelta.TabIndex = 18
        '
        'Label266
        '
        Me.Label266.AutoSize = True
        Me.Label266.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label266.Location = New System.Drawing.Point(104, 37)
        Me.Label266.Name = "Label266"
        Me.Label266.Size = New System.Drawing.Size(73, 20)
        Me.Label266.TabIndex = 17
        Me.Label266.Text = "Version"
        '
        'TabPage11
        '
        Me.TabPage11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage11.Controls.Add(Me.Panel12)
        Me.TabPage11.Controls.Add(Me.TabControl12)
        Me.TabPage11.Location = New System.Drawing.Point(4, 4)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage11.TabIndex = 10
        Me.TabPage11.Text = "TabPage11"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.optionLabTVehicle)
        Me.Panel12.Controls.Add(Me.Label267)
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel12.Location = New System.Drawing.Point(3, 219)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(1130, 35)
        Me.Panel12.TabIndex = 3
        '
        'optionLabTVehicle
        '
        Me.optionLabTVehicle.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTVehicle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTVehicle.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTVehicle.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTVehicle.Name = "optionLabTVehicle"
        Me.optionLabTVehicle.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTVehicle.TabIndex = 14
        '
        'Label267
        '
        Me.Label267.AutoSize = True
        Me.Label267.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label267.Location = New System.Drawing.Point(108, 8)
        Me.Label267.Name = "Label267"
        Me.Label267.Size = New System.Drawing.Size(140, 20)
        Me.Label267.TabIndex = 14
        Me.Label267.Text = "LabT_VEHICLE"
        '
        'TabControl12
        '
        Me.TabControl12.Controls.Add(Me.TabPage43)
        Me.TabControl12.Controls.Add(Me.TabPage44)
        Me.TabControl12.Controls.Add(Me.TabPage45)
        Me.TabControl12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl12.Location = New System.Drawing.Point(3, 3)
        Me.TabControl12.Name = "TabControl12"
        Me.TabControl12.SelectedIndex = 0
        Me.TabControl12.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl12.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl12.TabIndex = 2
        '
        'TabPage43
        '
        Me.TabPage43.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage43.Controls.Add(Me.optionDefectStateVehicleFull)
        Me.TabPage43.Controls.Add(Me.Label268)
        Me.TabPage43.Controls.Add(Me.Label269)
        Me.TabPage43.Controls.Add(Me.optionDefectIdVehicleFull)
        Me.TabPage43.Controls.Add(Me.Label270)
        Me.TabPage43.Controls.Add(Me.optionDefectKindVehicleFull)
        Me.TabPage43.Controls.Add(Me.Label271)
        Me.TabPage43.Controls.Add(Me.optionPtIdVehicleFull)
        Me.TabPage43.Controls.Add(Me.Label272)
        Me.TabPage43.Controls.Add(Me.optionFailedVehicleFull)
        Me.TabPage43.Controls.Add(Me.Label273)
        Me.TabPage43.Controls.Add(Me.optionPassedVehicleFull)
        Me.TabPage43.Controls.Add(Me.optionPtStateVehicleFull)
        Me.TabPage43.Controls.Add(Me.Label274)
        Me.TabPage43.Controls.Add(Me.optionVersionVehicleFull)
        Me.TabPage43.Controls.Add(Me.Label275)
        Me.TabPage43.Location = New System.Drawing.Point(4, 25)
        Me.TabPage43.Name = "TabPage43"
        Me.TabPage43.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage43.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage43.TabIndex = 0
        Me.TabPage43.Text = "FULL "
        '
        'optionDefectStateVehicleFull
        '
        Me.optionDefectStateVehicleFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateVehicleFull.FormattingEnabled = True
        Me.optionDefectStateVehicleFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateVehicleFull.Name = "optionDefectStateVehicleFull"
        Me.optionDefectStateVehicleFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateVehicleFull.TabIndex = 16
        '
        'Label268
        '
        Me.Label268.AutoSize = True
        Me.Label268.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label268.Location = New System.Drawing.Point(762, 144)
        Me.Label268.Name = "Label268"
        Me.Label268.Size = New System.Drawing.Size(53, 20)
        Me.Label268.TabIndex = 15
        Me.Label268.Text = "State"
        '
        'Label269
        '
        Me.Label269.AutoSize = True
        Me.Label269.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label269.Location = New System.Drawing.Point(104, 141)
        Me.Label269.Name = "Label269"
        Me.Label269.Size = New System.Drawing.Size(86, 20)
        Me.Label269.TabIndex = 13
        Me.Label269.Text = "Defect id"
        '
        'optionDefectIdVehicleFull
        '
        Me.optionDefectIdVehicleFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdVehicleFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdVehicleFull.Name = "optionDefectIdVehicleFull"
        Me.optionDefectIdVehicleFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdVehicleFull.TabIndex = 12
        '
        'Label270
        '
        Me.Label270.AutoSize = True
        Me.Label270.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label270.Location = New System.Drawing.Point(463, 142)
        Me.Label270.Name = "Label270"
        Me.Label270.Size = New System.Drawing.Size(46, 20)
        Me.Label270.TabIndex = 11
        Me.Label270.Text = "Kind"
        '
        'optionDefectKindVehicleFull
        '
        Me.optionDefectKindVehicleFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindVehicleFull.FormattingEnabled = True
        Me.optionDefectKindVehicleFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindVehicleFull.Name = "optionDefectKindVehicleFull"
        Me.optionDefectKindVehicleFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindVehicleFull.TabIndex = 10
        '
        'Label271
        '
        Me.Label271.AutoSize = True
        Me.Label271.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label271.Location = New System.Drawing.Point(104, 88)
        Me.Label271.Name = "Label271"
        Me.Label271.Size = New System.Drawing.Size(53, 20)
        Me.Label271.TabIndex = 9
        Me.Label271.Text = "PT id"
        '
        'optionPtIdVehicleFull
        '
        Me.optionPtIdVehicleFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdVehicleFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdVehicleFull.Name = "optionPtIdVehicleFull"
        Me.optionPtIdVehicleFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdVehicleFull.TabIndex = 8
        '
        'Label272
        '
        Me.Label272.AutoSize = True
        Me.Label272.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label272.Location = New System.Drawing.Point(463, 92)
        Me.Label272.Name = "Label272"
        Me.Label272.Size = New System.Drawing.Size(53, 20)
        Me.Label272.TabIndex = 7
        Me.Label272.Text = "State"
        '
        'optionFailedVehicleFull
        '
        Me.optionFailedVehicleFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedVehicleFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedVehicleFull.Name = "optionFailedVehicleFull"
        Me.optionFailedVehicleFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedVehicleFull.TabIndex = 6
        '
        'Label273
        '
        Me.Label273.AutoSize = True
        Me.Label273.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label273.Location = New System.Drawing.Point(762, 42)
        Me.Label273.Name = "Label273"
        Me.Label273.Size = New System.Drawing.Size(60, 20)
        Me.Label273.TabIndex = 5
        Me.Label273.Text = "Failed"
        '
        'optionPassedVehicleFull
        '
        Me.optionPassedVehicleFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedVehicleFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedVehicleFull.Name = "optionPassedVehicleFull"
        Me.optionPassedVehicleFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedVehicleFull.TabIndex = 4
        '
        'optionPtStateVehicleFull
        '
        Me.optionPtStateVehicleFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateVehicleFull.FormattingEnabled = True
        Me.optionPtStateVehicleFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateVehicleFull.Name = "optionPtStateVehicleFull"
        Me.optionPtStateVehicleFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateVehicleFull.TabIndex = 3
        '
        'Label274
        '
        Me.Label274.AutoSize = True
        Me.Label274.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label274.Location = New System.Drawing.Point(463, 40)
        Me.Label274.Name = "Label274"
        Me.Label274.Size = New System.Drawing.Size(71, 20)
        Me.Label274.TabIndex = 2
        Me.Label274.Text = "Passed"
        '
        'optionVersionVehicleFull
        '
        Me.optionVersionVehicleFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionVehicleFull.FormattingEnabled = True
        Me.optionVersionVehicleFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionVehicleFull.Name = "optionVersionVehicleFull"
        Me.optionVersionVehicleFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionVehicleFull.TabIndex = 1
        '
        'Label275
        '
        Me.Label275.AutoSize = True
        Me.Label275.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label275.Location = New System.Drawing.Point(104, 37)
        Me.Label275.Name = "Label275"
        Me.Label275.Size = New System.Drawing.Size(73, 20)
        Me.Label275.TabIndex = 0
        Me.Label275.Text = "Version"
        '
        'TabPage44
        '
        Me.TabPage44.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage44.Controls.Add(Me.optionDefectStateVehicleRegression)
        Me.TabPage44.Controls.Add(Me.Label276)
        Me.TabPage44.Controls.Add(Me.Label277)
        Me.TabPage44.Controls.Add(Me.optionDefectIdVehicleRegression)
        Me.TabPage44.Controls.Add(Me.Label278)
        Me.TabPage44.Controls.Add(Me.optionDefectKindVehicleRegression)
        Me.TabPage44.Controls.Add(Me.Label279)
        Me.TabPage44.Controls.Add(Me.optionPtIdVehicleRegression)
        Me.TabPage44.Controls.Add(Me.Label280)
        Me.TabPage44.Controls.Add(Me.optionFailedVehicleRegression)
        Me.TabPage44.Controls.Add(Me.Label281)
        Me.TabPage44.Controls.Add(Me.optionPassedVehicleRegression)
        Me.TabPage44.Controls.Add(Me.optionPtStateVehicleRegression)
        Me.TabPage44.Controls.Add(Me.Label282)
        Me.TabPage44.Controls.Add(Me.optionVersionVehicleRegression)
        Me.TabPage44.Controls.Add(Me.Label283)
        Me.TabPage44.Location = New System.Drawing.Point(4, 25)
        Me.TabPage44.Name = "TabPage44"
        Me.TabPage44.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage44.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage44.TabIndex = 1
        Me.TabPage44.Text = "REGRESSION"
        '
        'optionDefectStateVehicleRegression
        '
        Me.optionDefectStateVehicleRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateVehicleRegression.FormattingEnabled = True
        Me.optionDefectStateVehicleRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateVehicleRegression.Name = "optionDefectStateVehicleRegression"
        Me.optionDefectStateVehicleRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateVehicleRegression.TabIndex = 32
        '
        'Label276
        '
        Me.Label276.AutoSize = True
        Me.Label276.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label276.Location = New System.Drawing.Point(762, 144)
        Me.Label276.Name = "Label276"
        Me.Label276.Size = New System.Drawing.Size(53, 20)
        Me.Label276.TabIndex = 31
        Me.Label276.Text = "State"
        '
        'Label277
        '
        Me.Label277.AutoSize = True
        Me.Label277.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label277.Location = New System.Drawing.Point(104, 141)
        Me.Label277.Name = "Label277"
        Me.Label277.Size = New System.Drawing.Size(86, 20)
        Me.Label277.TabIndex = 30
        Me.Label277.Text = "Defect id"
        '
        'optionDefectIdVehicleRegression
        '
        Me.optionDefectIdVehicleRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdVehicleRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdVehicleRegression.Name = "optionDefectIdVehicleRegression"
        Me.optionDefectIdVehicleRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdVehicleRegression.TabIndex = 29
        '
        'Label278
        '
        Me.Label278.AutoSize = True
        Me.Label278.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label278.Location = New System.Drawing.Point(463, 142)
        Me.Label278.Name = "Label278"
        Me.Label278.Size = New System.Drawing.Size(46, 20)
        Me.Label278.TabIndex = 28
        Me.Label278.Text = "Kind"
        '
        'optionDefectKindVehicleRegression
        '
        Me.optionDefectKindVehicleRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindVehicleRegression.FormattingEnabled = True
        Me.optionDefectKindVehicleRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindVehicleRegression.Name = "optionDefectKindVehicleRegression"
        Me.optionDefectKindVehicleRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindVehicleRegression.TabIndex = 27
        '
        'Label279
        '
        Me.Label279.AutoSize = True
        Me.Label279.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label279.Location = New System.Drawing.Point(104, 88)
        Me.Label279.Name = "Label279"
        Me.Label279.Size = New System.Drawing.Size(53, 20)
        Me.Label279.TabIndex = 26
        Me.Label279.Text = "PT id"
        '
        'optionPtIdVehicleRegression
        '
        Me.optionPtIdVehicleRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdVehicleRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdVehicleRegression.Name = "optionPtIdVehicleRegression"
        Me.optionPtIdVehicleRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdVehicleRegression.TabIndex = 25
        '
        'Label280
        '
        Me.Label280.AutoSize = True
        Me.Label280.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label280.Location = New System.Drawing.Point(463, 92)
        Me.Label280.Name = "Label280"
        Me.Label280.Size = New System.Drawing.Size(53, 20)
        Me.Label280.TabIndex = 24
        Me.Label280.Text = "State"
        '
        'optionFailedVehicleRegression
        '
        Me.optionFailedVehicleRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedVehicleRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedVehicleRegression.Name = "optionFailedVehicleRegression"
        Me.optionFailedVehicleRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedVehicleRegression.TabIndex = 23
        '
        'Label281
        '
        Me.Label281.AutoSize = True
        Me.Label281.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label281.Location = New System.Drawing.Point(762, 42)
        Me.Label281.Name = "Label281"
        Me.Label281.Size = New System.Drawing.Size(60, 20)
        Me.Label281.TabIndex = 22
        Me.Label281.Text = "Failed"
        '
        'optionPassedVehicleRegression
        '
        Me.optionPassedVehicleRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedVehicleRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedVehicleRegression.Name = "optionPassedVehicleRegression"
        Me.optionPassedVehicleRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedVehicleRegression.TabIndex = 21
        '
        'optionPtStateVehicleRegression
        '
        Me.optionPtStateVehicleRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateVehicleRegression.FormattingEnabled = True
        Me.optionPtStateVehicleRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateVehicleRegression.Name = "optionPtStateVehicleRegression"
        Me.optionPtStateVehicleRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateVehicleRegression.TabIndex = 20
        '
        'Label282
        '
        Me.Label282.AutoSize = True
        Me.Label282.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label282.Location = New System.Drawing.Point(463, 40)
        Me.Label282.Name = "Label282"
        Me.Label282.Size = New System.Drawing.Size(71, 20)
        Me.Label282.TabIndex = 19
        Me.Label282.Text = "Passed"
        '
        'optionVersionVehicleRegression
        '
        Me.optionVersionVehicleRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionVehicleRegression.FormattingEnabled = True
        Me.optionVersionVehicleRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionVehicleRegression.Name = "optionVersionVehicleRegression"
        Me.optionVersionVehicleRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionVehicleRegression.TabIndex = 18
        '
        'Label283
        '
        Me.Label283.AutoSize = True
        Me.Label283.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label283.Location = New System.Drawing.Point(104, 37)
        Me.Label283.Name = "Label283"
        Me.Label283.Size = New System.Drawing.Size(73, 20)
        Me.Label283.TabIndex = 17
        Me.Label283.Text = "Version"
        '
        'TabPage45
        '
        Me.TabPage45.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage45.Controls.Add(Me.optionDefectStateVehicleDelta)
        Me.TabPage45.Controls.Add(Me.Label284)
        Me.TabPage45.Controls.Add(Me.Label285)
        Me.TabPage45.Controls.Add(Me.optionDefectIdVehicleDelta)
        Me.TabPage45.Controls.Add(Me.Label286)
        Me.TabPage45.Controls.Add(Me.optionDefectKindVehicleDelta)
        Me.TabPage45.Controls.Add(Me.Label287)
        Me.TabPage45.Controls.Add(Me.optionPtIdVehicleDelta)
        Me.TabPage45.Controls.Add(Me.Label288)
        Me.TabPage45.Controls.Add(Me.optionFailedVehicleDelta)
        Me.TabPage45.Controls.Add(Me.Label289)
        Me.TabPage45.Controls.Add(Me.optionPassedVehicleDelta)
        Me.TabPage45.Controls.Add(Me.optionPtStateVehicleDelta)
        Me.TabPage45.Controls.Add(Me.Label290)
        Me.TabPage45.Controls.Add(Me.optionVersionVehicleDelta)
        Me.TabPage45.Controls.Add(Me.Label291)
        Me.TabPage45.Location = New System.Drawing.Point(4, 25)
        Me.TabPage45.Name = "TabPage45"
        Me.TabPage45.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage45.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage45.TabIndex = 2
        Me.TabPage45.Text = "DELTA"
        '
        'optionDefectStateVehicleDelta
        '
        Me.optionDefectStateVehicleDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateVehicleDelta.FormattingEnabled = True
        Me.optionDefectStateVehicleDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateVehicleDelta.Name = "optionDefectStateVehicleDelta"
        Me.optionDefectStateVehicleDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateVehicleDelta.TabIndex = 32
        '
        'Label284
        '
        Me.Label284.AutoSize = True
        Me.Label284.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label284.Location = New System.Drawing.Point(762, 144)
        Me.Label284.Name = "Label284"
        Me.Label284.Size = New System.Drawing.Size(53, 20)
        Me.Label284.TabIndex = 31
        Me.Label284.Text = "State"
        '
        'Label285
        '
        Me.Label285.AutoSize = True
        Me.Label285.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label285.Location = New System.Drawing.Point(104, 141)
        Me.Label285.Name = "Label285"
        Me.Label285.Size = New System.Drawing.Size(86, 20)
        Me.Label285.TabIndex = 30
        Me.Label285.Text = "Defect id"
        '
        'optionDefectIdVehicleDelta
        '
        Me.optionDefectIdVehicleDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdVehicleDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdVehicleDelta.Name = "optionDefectIdVehicleDelta"
        Me.optionDefectIdVehicleDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdVehicleDelta.TabIndex = 29
        '
        'Label286
        '
        Me.Label286.AutoSize = True
        Me.Label286.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label286.Location = New System.Drawing.Point(463, 142)
        Me.Label286.Name = "Label286"
        Me.Label286.Size = New System.Drawing.Size(46, 20)
        Me.Label286.TabIndex = 28
        Me.Label286.Text = "Kind"
        '
        'optionDefectKindVehicleDelta
        '
        Me.optionDefectKindVehicleDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindVehicleDelta.FormattingEnabled = True
        Me.optionDefectKindVehicleDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindVehicleDelta.Name = "optionDefectKindVehicleDelta"
        Me.optionDefectKindVehicleDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindVehicleDelta.TabIndex = 27
        '
        'Label287
        '
        Me.Label287.AutoSize = True
        Me.Label287.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label287.Location = New System.Drawing.Point(104, 88)
        Me.Label287.Name = "Label287"
        Me.Label287.Size = New System.Drawing.Size(53, 20)
        Me.Label287.TabIndex = 26
        Me.Label287.Text = "PT id"
        '
        'optionPtIdVehicleDelta
        '
        Me.optionPtIdVehicleDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdVehicleDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdVehicleDelta.Name = "optionPtIdVehicleDelta"
        Me.optionPtIdVehicleDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdVehicleDelta.TabIndex = 25
        '
        'Label288
        '
        Me.Label288.AutoSize = True
        Me.Label288.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label288.Location = New System.Drawing.Point(463, 92)
        Me.Label288.Name = "Label288"
        Me.Label288.Size = New System.Drawing.Size(53, 20)
        Me.Label288.TabIndex = 24
        Me.Label288.Text = "State"
        '
        'optionFailedVehicleDelta
        '
        Me.optionFailedVehicleDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedVehicleDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedVehicleDelta.Name = "optionFailedVehicleDelta"
        Me.optionFailedVehicleDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedVehicleDelta.TabIndex = 23
        '
        'Label289
        '
        Me.Label289.AutoSize = True
        Me.Label289.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label289.Location = New System.Drawing.Point(762, 42)
        Me.Label289.Name = "Label289"
        Me.Label289.Size = New System.Drawing.Size(60, 20)
        Me.Label289.TabIndex = 22
        Me.Label289.Text = "Failed"
        '
        'optionPassedVehicleDelta
        '
        Me.optionPassedVehicleDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedVehicleDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedVehicleDelta.Name = "optionPassedVehicleDelta"
        Me.optionPassedVehicleDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedVehicleDelta.TabIndex = 21
        '
        'optionPtStateVehicleDelta
        '
        Me.optionPtStateVehicleDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateVehicleDelta.FormattingEnabled = True
        Me.optionPtStateVehicleDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateVehicleDelta.Name = "optionPtStateVehicleDelta"
        Me.optionPtStateVehicleDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateVehicleDelta.TabIndex = 20
        '
        'Label290
        '
        Me.Label290.AutoSize = True
        Me.Label290.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label290.Location = New System.Drawing.Point(463, 40)
        Me.Label290.Name = "Label290"
        Me.Label290.Size = New System.Drawing.Size(71, 20)
        Me.Label290.TabIndex = 19
        Me.Label290.Text = "Passed"
        '
        'optionVersionVehicleDelta
        '
        Me.optionVersionVehicleDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionVehicleDelta.FormattingEnabled = True
        Me.optionVersionVehicleDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionVehicleDelta.Name = "optionVersionVehicleDelta"
        Me.optionVersionVehicleDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionVehicleDelta.TabIndex = 18
        '
        'Label291
        '
        Me.Label291.AutoSize = True
        Me.Label291.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label291.Location = New System.Drawing.Point(104, 37)
        Me.Label291.Name = "Label291"
        Me.Label291.Size = New System.Drawing.Size(73, 20)
        Me.Label291.TabIndex = 17
        Me.Label291.Text = "Version"
        '
        'TabPage12
        '
        Me.TabPage12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage12.Controls.Add(Me.Panel13)
        Me.TabPage12.Controls.Add(Me.TabControl13)
        Me.TabPage12.Location = New System.Drawing.Point(4, 4)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage12.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage12.TabIndex = 11
        Me.TabPage12.Text = "TabPage12"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.optionLabTSIT)
        Me.Panel13.Controls.Add(Me.Label292)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel13.Location = New System.Drawing.Point(3, 219)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(1130, 35)
        Me.Panel13.TabIndex = 3
        '
        'optionLabTSIT
        '
        Me.optionLabTSIT.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTSIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTSIT.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTSIT.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTSIT.Name = "optionLabTSIT"
        Me.optionLabTSIT.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTSIT.TabIndex = 14
        '
        'Label292
        '
        Me.Label292.AutoSize = True
        Me.Label292.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label292.Location = New System.Drawing.Point(108, 8)
        Me.Label292.Name = "Label292"
        Me.Label292.Size = New System.Drawing.Size(89, 20)
        Me.Label292.TabIndex = 14
        Me.Label292.Text = "LabT_SIT"
        '
        'TabControl13
        '
        Me.TabControl13.Controls.Add(Me.TabPage46)
        Me.TabControl13.Controls.Add(Me.TabPage47)
        Me.TabControl13.Controls.Add(Me.TabPage48)
        Me.TabControl13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl13.Location = New System.Drawing.Point(3, 3)
        Me.TabControl13.Name = "TabControl13"
        Me.TabControl13.SelectedIndex = 0
        Me.TabControl13.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl13.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl13.TabIndex = 2
        '
        'TabPage46
        '
        Me.TabPage46.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage46.Controls.Add(Me.optionDefectStateSITFull)
        Me.TabPage46.Controls.Add(Me.Label293)
        Me.TabPage46.Controls.Add(Me.Label294)
        Me.TabPage46.Controls.Add(Me.optionDefectIdSITFull)
        Me.TabPage46.Controls.Add(Me.Label295)
        Me.TabPage46.Controls.Add(Me.optionDefectKindSITFull)
        Me.TabPage46.Controls.Add(Me.Label296)
        Me.TabPage46.Controls.Add(Me.optionPtIdSITFull)
        Me.TabPage46.Controls.Add(Me.Label297)
        Me.TabPage46.Controls.Add(Me.optionFailedSITFull)
        Me.TabPage46.Controls.Add(Me.Label298)
        Me.TabPage46.Controls.Add(Me.optionPassedSITFull)
        Me.TabPage46.Controls.Add(Me.optionPtStateSITFull)
        Me.TabPage46.Controls.Add(Me.Label299)
        Me.TabPage46.Controls.Add(Me.optionVersionSITFull)
        Me.TabPage46.Controls.Add(Me.Label300)
        Me.TabPage46.Location = New System.Drawing.Point(4, 25)
        Me.TabPage46.Name = "TabPage46"
        Me.TabPage46.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage46.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage46.TabIndex = 0
        Me.TabPage46.Text = "FULL "
        '
        'optionDefectStateSITFull
        '
        Me.optionDefectStateSITFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSITFull.FormattingEnabled = True
        Me.optionDefectStateSITFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSITFull.Name = "optionDefectStateSITFull"
        Me.optionDefectStateSITFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSITFull.TabIndex = 16
        '
        'Label293
        '
        Me.Label293.AutoSize = True
        Me.Label293.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label293.Location = New System.Drawing.Point(762, 144)
        Me.Label293.Name = "Label293"
        Me.Label293.Size = New System.Drawing.Size(53, 20)
        Me.Label293.TabIndex = 15
        Me.Label293.Text = "State"
        '
        'Label294
        '
        Me.Label294.AutoSize = True
        Me.Label294.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label294.Location = New System.Drawing.Point(104, 141)
        Me.Label294.Name = "Label294"
        Me.Label294.Size = New System.Drawing.Size(86, 20)
        Me.Label294.TabIndex = 13
        Me.Label294.Text = "Defect id"
        '
        'optionDefectIdSITFull
        '
        Me.optionDefectIdSITFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSITFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSITFull.Name = "optionDefectIdSITFull"
        Me.optionDefectIdSITFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSITFull.TabIndex = 12
        '
        'Label295
        '
        Me.Label295.AutoSize = True
        Me.Label295.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label295.Location = New System.Drawing.Point(463, 142)
        Me.Label295.Name = "Label295"
        Me.Label295.Size = New System.Drawing.Size(46, 20)
        Me.Label295.TabIndex = 11
        Me.Label295.Text = "Kind"
        '
        'optionDefectKindSITFull
        '
        Me.optionDefectKindSITFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSITFull.FormattingEnabled = True
        Me.optionDefectKindSITFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSITFull.Name = "optionDefectKindSITFull"
        Me.optionDefectKindSITFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSITFull.TabIndex = 10
        '
        'Label296
        '
        Me.Label296.AutoSize = True
        Me.Label296.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label296.Location = New System.Drawing.Point(104, 88)
        Me.Label296.Name = "Label296"
        Me.Label296.Size = New System.Drawing.Size(53, 20)
        Me.Label296.TabIndex = 9
        Me.Label296.Text = "PT id"
        '
        'optionPtIdSITFull
        '
        Me.optionPtIdSITFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSITFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSITFull.Name = "optionPtIdSITFull"
        Me.optionPtIdSITFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSITFull.TabIndex = 8
        '
        'Label297
        '
        Me.Label297.AutoSize = True
        Me.Label297.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label297.Location = New System.Drawing.Point(463, 92)
        Me.Label297.Name = "Label297"
        Me.Label297.Size = New System.Drawing.Size(53, 20)
        Me.Label297.TabIndex = 7
        Me.Label297.Text = "State"
        '
        'optionFailedSITFull
        '
        Me.optionFailedSITFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSITFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSITFull.Name = "optionFailedSITFull"
        Me.optionFailedSITFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSITFull.TabIndex = 6
        '
        'Label298
        '
        Me.Label298.AutoSize = True
        Me.Label298.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label298.Location = New System.Drawing.Point(762, 42)
        Me.Label298.Name = "Label298"
        Me.Label298.Size = New System.Drawing.Size(60, 20)
        Me.Label298.TabIndex = 5
        Me.Label298.Text = "Failed"
        '
        'optionPassedSITFull
        '
        Me.optionPassedSITFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSITFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSITFull.Name = "optionPassedSITFull"
        Me.optionPassedSITFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSITFull.TabIndex = 4
        '
        'optionPtStateSITFull
        '
        Me.optionPtStateSITFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSITFull.FormattingEnabled = True
        Me.optionPtStateSITFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSITFull.Name = "optionPtStateSITFull"
        Me.optionPtStateSITFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSITFull.TabIndex = 3
        '
        'Label299
        '
        Me.Label299.AutoSize = True
        Me.Label299.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label299.Location = New System.Drawing.Point(463, 40)
        Me.Label299.Name = "Label299"
        Me.Label299.Size = New System.Drawing.Size(71, 20)
        Me.Label299.TabIndex = 2
        Me.Label299.Text = "Passed"
        '
        'optionVersionSITFull
        '
        Me.optionVersionSITFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSITFull.FormattingEnabled = True
        Me.optionVersionSITFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSITFull.Name = "optionVersionSITFull"
        Me.optionVersionSITFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSITFull.TabIndex = 1
        '
        'Label300
        '
        Me.Label300.AutoSize = True
        Me.Label300.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label300.Location = New System.Drawing.Point(104, 37)
        Me.Label300.Name = "Label300"
        Me.Label300.Size = New System.Drawing.Size(73, 20)
        Me.Label300.TabIndex = 0
        Me.Label300.Text = "Version"
        '
        'TabPage47
        '
        Me.TabPage47.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage47.Controls.Add(Me.optionDefectStateSITRegression)
        Me.TabPage47.Controls.Add(Me.Label301)
        Me.TabPage47.Controls.Add(Me.Label302)
        Me.TabPage47.Controls.Add(Me.optionDefectIdSITRegression)
        Me.TabPage47.Controls.Add(Me.Label303)
        Me.TabPage47.Controls.Add(Me.optionDefectKindSITRegression)
        Me.TabPage47.Controls.Add(Me.Label304)
        Me.TabPage47.Controls.Add(Me.optionPtIdSITRegression)
        Me.TabPage47.Controls.Add(Me.Label305)
        Me.TabPage47.Controls.Add(Me.optionFailedSITRegression)
        Me.TabPage47.Controls.Add(Me.Label306)
        Me.TabPage47.Controls.Add(Me.optionPassedSITRegression)
        Me.TabPage47.Controls.Add(Me.optionPtStateSITRegression)
        Me.TabPage47.Controls.Add(Me.Label307)
        Me.TabPage47.Controls.Add(Me.optionVersionSITRegression)
        Me.TabPage47.Controls.Add(Me.Label308)
        Me.TabPage47.Location = New System.Drawing.Point(4, 25)
        Me.TabPage47.Name = "TabPage47"
        Me.TabPage47.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage47.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage47.TabIndex = 1
        Me.TabPage47.Text = "REGRESSION"
        '
        'optionDefectStateSITRegression
        '
        Me.optionDefectStateSITRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSITRegression.FormattingEnabled = True
        Me.optionDefectStateSITRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSITRegression.Name = "optionDefectStateSITRegression"
        Me.optionDefectStateSITRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSITRegression.TabIndex = 32
        '
        'Label301
        '
        Me.Label301.AutoSize = True
        Me.Label301.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label301.Location = New System.Drawing.Point(762, 144)
        Me.Label301.Name = "Label301"
        Me.Label301.Size = New System.Drawing.Size(53, 20)
        Me.Label301.TabIndex = 31
        Me.Label301.Text = "State"
        '
        'Label302
        '
        Me.Label302.AutoSize = True
        Me.Label302.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label302.Location = New System.Drawing.Point(104, 141)
        Me.Label302.Name = "Label302"
        Me.Label302.Size = New System.Drawing.Size(86, 20)
        Me.Label302.TabIndex = 30
        Me.Label302.Text = "Defect id"
        '
        'optionDefectIdSITRegression
        '
        Me.optionDefectIdSITRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSITRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSITRegression.Name = "optionDefectIdSITRegression"
        Me.optionDefectIdSITRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSITRegression.TabIndex = 29
        '
        'Label303
        '
        Me.Label303.AutoSize = True
        Me.Label303.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label303.Location = New System.Drawing.Point(463, 142)
        Me.Label303.Name = "Label303"
        Me.Label303.Size = New System.Drawing.Size(46, 20)
        Me.Label303.TabIndex = 28
        Me.Label303.Text = "Kind"
        '
        'optionDefectKindSITRegression
        '
        Me.optionDefectKindSITRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSITRegression.FormattingEnabled = True
        Me.optionDefectKindSITRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSITRegression.Name = "optionDefectKindSITRegression"
        Me.optionDefectKindSITRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSITRegression.TabIndex = 27
        '
        'Label304
        '
        Me.Label304.AutoSize = True
        Me.Label304.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label304.Location = New System.Drawing.Point(104, 88)
        Me.Label304.Name = "Label304"
        Me.Label304.Size = New System.Drawing.Size(53, 20)
        Me.Label304.TabIndex = 26
        Me.Label304.Text = "PT id"
        '
        'optionPtIdSITRegression
        '
        Me.optionPtIdSITRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSITRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSITRegression.Name = "optionPtIdSITRegression"
        Me.optionPtIdSITRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSITRegression.TabIndex = 25
        '
        'Label305
        '
        Me.Label305.AutoSize = True
        Me.Label305.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label305.Location = New System.Drawing.Point(463, 92)
        Me.Label305.Name = "Label305"
        Me.Label305.Size = New System.Drawing.Size(53, 20)
        Me.Label305.TabIndex = 24
        Me.Label305.Text = "State"
        '
        'optionFailedSITRegression
        '
        Me.optionFailedSITRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSITRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSITRegression.Name = "optionFailedSITRegression"
        Me.optionFailedSITRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSITRegression.TabIndex = 23
        '
        'Label306
        '
        Me.Label306.AutoSize = True
        Me.Label306.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label306.Location = New System.Drawing.Point(762, 42)
        Me.Label306.Name = "Label306"
        Me.Label306.Size = New System.Drawing.Size(60, 20)
        Me.Label306.TabIndex = 22
        Me.Label306.Text = "Failed"
        '
        'optionPassedSITRegression
        '
        Me.optionPassedSITRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSITRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSITRegression.Name = "optionPassedSITRegression"
        Me.optionPassedSITRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSITRegression.TabIndex = 21
        '
        'optionPtStateSITRegression
        '
        Me.optionPtStateSITRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSITRegression.FormattingEnabled = True
        Me.optionPtStateSITRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSITRegression.Name = "optionPtStateSITRegression"
        Me.optionPtStateSITRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSITRegression.TabIndex = 20
        '
        'Label307
        '
        Me.Label307.AutoSize = True
        Me.Label307.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label307.Location = New System.Drawing.Point(463, 40)
        Me.Label307.Name = "Label307"
        Me.Label307.Size = New System.Drawing.Size(71, 20)
        Me.Label307.TabIndex = 19
        Me.Label307.Text = "Passed"
        '
        'optionVersionSITRegression
        '
        Me.optionVersionSITRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSITRegression.FormattingEnabled = True
        Me.optionVersionSITRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSITRegression.Name = "optionVersionSITRegression"
        Me.optionVersionSITRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSITRegression.TabIndex = 18
        '
        'Label308
        '
        Me.Label308.AutoSize = True
        Me.Label308.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label308.Location = New System.Drawing.Point(104, 37)
        Me.Label308.Name = "Label308"
        Me.Label308.Size = New System.Drawing.Size(73, 20)
        Me.Label308.TabIndex = 17
        Me.Label308.Text = "Version"
        '
        'TabPage48
        '
        Me.TabPage48.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage48.Controls.Add(Me.optionDefectStateSITDelta)
        Me.TabPage48.Controls.Add(Me.Label309)
        Me.TabPage48.Controls.Add(Me.Label310)
        Me.TabPage48.Controls.Add(Me.optionDefectIdSITDelta)
        Me.TabPage48.Controls.Add(Me.Label311)
        Me.TabPage48.Controls.Add(Me.optionDefectKindSITDelta)
        Me.TabPage48.Controls.Add(Me.Label312)
        Me.TabPage48.Controls.Add(Me.optionPtIdSITDelta)
        Me.TabPage48.Controls.Add(Me.Label313)
        Me.TabPage48.Controls.Add(Me.optionFailedSITDelta)
        Me.TabPage48.Controls.Add(Me.Label314)
        Me.TabPage48.Controls.Add(Me.optionPassedSITDelta)
        Me.TabPage48.Controls.Add(Me.optionPtStateSITDelta)
        Me.TabPage48.Controls.Add(Me.Label315)
        Me.TabPage48.Controls.Add(Me.optionVersionSITDelta)
        Me.TabPage48.Controls.Add(Me.Label316)
        Me.TabPage48.Location = New System.Drawing.Point(4, 25)
        Me.TabPage48.Name = "TabPage48"
        Me.TabPage48.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage48.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage48.TabIndex = 2
        Me.TabPage48.Text = "DELTA"
        '
        'optionDefectStateSITDelta
        '
        Me.optionDefectStateSITDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSITDelta.FormattingEnabled = True
        Me.optionDefectStateSITDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSITDelta.Name = "optionDefectStateSITDelta"
        Me.optionDefectStateSITDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSITDelta.TabIndex = 32
        '
        'Label309
        '
        Me.Label309.AutoSize = True
        Me.Label309.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label309.Location = New System.Drawing.Point(762, 144)
        Me.Label309.Name = "Label309"
        Me.Label309.Size = New System.Drawing.Size(53, 20)
        Me.Label309.TabIndex = 31
        Me.Label309.Text = "State"
        '
        'Label310
        '
        Me.Label310.AutoSize = True
        Me.Label310.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label310.Location = New System.Drawing.Point(104, 141)
        Me.Label310.Name = "Label310"
        Me.Label310.Size = New System.Drawing.Size(86, 20)
        Me.Label310.TabIndex = 30
        Me.Label310.Text = "Defect id"
        '
        'optionDefectIdSITDelta
        '
        Me.optionDefectIdSITDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSITDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSITDelta.Name = "optionDefectIdSITDelta"
        Me.optionDefectIdSITDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSITDelta.TabIndex = 29
        '
        'Label311
        '
        Me.Label311.AutoSize = True
        Me.Label311.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label311.Location = New System.Drawing.Point(463, 142)
        Me.Label311.Name = "Label311"
        Me.Label311.Size = New System.Drawing.Size(46, 20)
        Me.Label311.TabIndex = 28
        Me.Label311.Text = "Kind"
        '
        'optionDefectKindSITDelta
        '
        Me.optionDefectKindSITDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSITDelta.FormattingEnabled = True
        Me.optionDefectKindSITDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSITDelta.Name = "optionDefectKindSITDelta"
        Me.optionDefectKindSITDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSITDelta.TabIndex = 27
        '
        'Label312
        '
        Me.Label312.AutoSize = True
        Me.Label312.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label312.Location = New System.Drawing.Point(104, 88)
        Me.Label312.Name = "Label312"
        Me.Label312.Size = New System.Drawing.Size(53, 20)
        Me.Label312.TabIndex = 26
        Me.Label312.Text = "PT id"
        '
        'optionPtIdSITDelta
        '
        Me.optionPtIdSITDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSITDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSITDelta.Name = "optionPtIdSITDelta"
        Me.optionPtIdSITDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSITDelta.TabIndex = 25
        '
        'Label313
        '
        Me.Label313.AutoSize = True
        Me.Label313.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label313.Location = New System.Drawing.Point(463, 92)
        Me.Label313.Name = "Label313"
        Me.Label313.Size = New System.Drawing.Size(53, 20)
        Me.Label313.TabIndex = 24
        Me.Label313.Text = "State"
        '
        'optionFailedSITDelta
        '
        Me.optionFailedSITDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSITDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSITDelta.Name = "optionFailedSITDelta"
        Me.optionFailedSITDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSITDelta.TabIndex = 23
        '
        'Label314
        '
        Me.Label314.AutoSize = True
        Me.Label314.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label314.Location = New System.Drawing.Point(762, 42)
        Me.Label314.Name = "Label314"
        Me.Label314.Size = New System.Drawing.Size(60, 20)
        Me.Label314.TabIndex = 22
        Me.Label314.Text = "Failed"
        '
        'optionPassedSITDelta
        '
        Me.optionPassedSITDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSITDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSITDelta.Name = "optionPassedSITDelta"
        Me.optionPassedSITDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSITDelta.TabIndex = 21
        '
        'optionPtStateSITDelta
        '
        Me.optionPtStateSITDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSITDelta.FormattingEnabled = True
        Me.optionPtStateSITDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSITDelta.Name = "optionPtStateSITDelta"
        Me.optionPtStateSITDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSITDelta.TabIndex = 20
        '
        'Label315
        '
        Me.Label315.AutoSize = True
        Me.Label315.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label315.Location = New System.Drawing.Point(463, 40)
        Me.Label315.Name = "Label315"
        Me.Label315.Size = New System.Drawing.Size(71, 20)
        Me.Label315.TabIndex = 19
        Me.Label315.Text = "Passed"
        '
        'optionVersionSITDelta
        '
        Me.optionVersionSITDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSITDelta.FormattingEnabled = True
        Me.optionVersionSITDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSITDelta.Name = "optionVersionSITDelta"
        Me.optionVersionSITDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSITDelta.TabIndex = 18
        '
        'Label316
        '
        Me.Label316.AutoSize = True
        Me.Label316.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label316.Location = New System.Drawing.Point(104, 37)
        Me.Label316.Name = "Label316"
        Me.Label316.Size = New System.Drawing.Size(73, 20)
        Me.Label316.TabIndex = 17
        Me.Label316.Text = "Version"
        '
        'TabPage49
        '
        Me.TabPage49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage49.Controls.Add(Me.Panel14)
        Me.TabPage49.Controls.Add(Me.TabControl14)
        Me.TabPage49.Location = New System.Drawing.Point(4, 4)
        Me.TabPage49.Name = "TabPage49"
        Me.TabPage49.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage49.Size = New System.Drawing.Size(1138, 259)
        Me.TabPage49.TabIndex = 12
        Me.TabPage49.Text = "TabPage49"
        Me.TabPage49.UseVisualStyleBackColor = True
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.optionLabTSRCheck)
        Me.Panel14.Controls.Add(Me.Label317)
        Me.Panel14.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel14.Location = New System.Drawing.Point(3, 219)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(1130, 35)
        Me.Panel14.TabIndex = 5
        '
        'optionLabTSRCheck
        '
        Me.optionLabTSRCheck.BackColor = System.Drawing.Color.PeachPuff
        Me.optionLabTSRCheck.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionLabTSRCheck.ForeColor = System.Drawing.Color.Blue
        Me.optionLabTSRCheck.Location = New System.Drawing.Point(256, 5)
        Me.optionLabTSRCheck.Name = "optionLabTSRCheck"
        Me.optionLabTSRCheck.Size = New System.Drawing.Size(781, 26)
        Me.optionLabTSRCheck.TabIndex = 14
        '
        'Label317
        '
        Me.Label317.AutoSize = True
        Me.Label317.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label317.Location = New System.Drawing.Point(108, 8)
        Me.Label317.Name = "Label317"
        Me.Label317.Size = New System.Drawing.Size(104, 20)
        Me.Label317.TabIndex = 14
        Me.Label317.Text = "SR CHECK"
        '
        'TabControl14
        '
        Me.TabControl14.Controls.Add(Me.TabPage50)
        Me.TabControl14.Controls.Add(Me.TabPage51)
        Me.TabControl14.Controls.Add(Me.TabPage52)
        Me.TabControl14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl14.Location = New System.Drawing.Point(3, 3)
        Me.TabControl14.Name = "TabControl14"
        Me.TabControl14.SelectedIndex = 0
        Me.TabControl14.Size = New System.Drawing.Size(1130, 251)
        Me.TabControl14.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl14.TabIndex = 4
        '
        'TabPage50
        '
        Me.TabPage50.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage50.Controls.Add(Me.optionDefectStateSRCheckFull)
        Me.TabPage50.Controls.Add(Me.Label318)
        Me.TabPage50.Controls.Add(Me.Label319)
        Me.TabPage50.Controls.Add(Me.optionDefectIdSRCheckFull)
        Me.TabPage50.Controls.Add(Me.Label320)
        Me.TabPage50.Controls.Add(Me.optionDefectKindSRCheckFull)
        Me.TabPage50.Controls.Add(Me.Label321)
        Me.TabPage50.Controls.Add(Me.optionPtIdSRCheckFull)
        Me.TabPage50.Controls.Add(Me.Label322)
        Me.TabPage50.Controls.Add(Me.optionFailedSRCheckFull)
        Me.TabPage50.Controls.Add(Me.Label323)
        Me.TabPage50.Controls.Add(Me.optionPassedSRCheckFull)
        Me.TabPage50.Controls.Add(Me.optionPtStateSRCheckFull)
        Me.TabPage50.Controls.Add(Me.Label324)
        Me.TabPage50.Controls.Add(Me.optionVersionSRCheckFull)
        Me.TabPage50.Controls.Add(Me.Label325)
        Me.TabPage50.Location = New System.Drawing.Point(4, 25)
        Me.TabPage50.Name = "TabPage50"
        Me.TabPage50.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage50.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage50.TabIndex = 0
        Me.TabPage50.Text = "FULL "
        '
        'optionDefectStateSRCheckFull
        '
        Me.optionDefectStateSRCheckFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSRCheckFull.FormattingEnabled = True
        Me.optionDefectStateSRCheckFull.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSRCheckFull.Name = "optionDefectStateSRCheckFull"
        Me.optionDefectStateSRCheckFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSRCheckFull.TabIndex = 16
        '
        'Label318
        '
        Me.Label318.AutoSize = True
        Me.Label318.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label318.Location = New System.Drawing.Point(762, 144)
        Me.Label318.Name = "Label318"
        Me.Label318.Size = New System.Drawing.Size(53, 20)
        Me.Label318.TabIndex = 15
        Me.Label318.Text = "State"
        '
        'Label319
        '
        Me.Label319.AutoSize = True
        Me.Label319.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label319.Location = New System.Drawing.Point(104, 141)
        Me.Label319.Name = "Label319"
        Me.Label319.Size = New System.Drawing.Size(86, 20)
        Me.Label319.TabIndex = 13
        Me.Label319.Text = "Defect id"
        '
        'optionDefectIdSRCheckFull
        '
        Me.optionDefectIdSRCheckFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSRCheckFull.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSRCheckFull.Name = "optionDefectIdSRCheckFull"
        Me.optionDefectIdSRCheckFull.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSRCheckFull.TabIndex = 12
        '
        'Label320
        '
        Me.Label320.AutoSize = True
        Me.Label320.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label320.Location = New System.Drawing.Point(463, 142)
        Me.Label320.Name = "Label320"
        Me.Label320.Size = New System.Drawing.Size(46, 20)
        Me.Label320.TabIndex = 11
        Me.Label320.Text = "Kind"
        '
        'optionDefectKindSRCheckFull
        '
        Me.optionDefectKindSRCheckFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSRCheckFull.FormattingEnabled = True
        Me.optionDefectKindSRCheckFull.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSRCheckFull.Name = "optionDefectKindSRCheckFull"
        Me.optionDefectKindSRCheckFull.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSRCheckFull.TabIndex = 10
        '
        'Label321
        '
        Me.Label321.AutoSize = True
        Me.Label321.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label321.Location = New System.Drawing.Point(104, 88)
        Me.Label321.Name = "Label321"
        Me.Label321.Size = New System.Drawing.Size(53, 20)
        Me.Label321.TabIndex = 9
        Me.Label321.Text = "PT id"
        '
        'optionPtIdSRCheckFull
        '
        Me.optionPtIdSRCheckFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSRCheckFull.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSRCheckFull.Name = "optionPtIdSRCheckFull"
        Me.optionPtIdSRCheckFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSRCheckFull.TabIndex = 8
        '
        'Label322
        '
        Me.Label322.AutoSize = True
        Me.Label322.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label322.Location = New System.Drawing.Point(463, 92)
        Me.Label322.Name = "Label322"
        Me.Label322.Size = New System.Drawing.Size(53, 20)
        Me.Label322.TabIndex = 7
        Me.Label322.Text = "State"
        '
        'optionFailedSRCheckFull
        '
        Me.optionFailedSRCheckFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSRCheckFull.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSRCheckFull.Name = "optionFailedSRCheckFull"
        Me.optionFailedSRCheckFull.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSRCheckFull.TabIndex = 6
        '
        'Label323
        '
        Me.Label323.AutoSize = True
        Me.Label323.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label323.Location = New System.Drawing.Point(762, 42)
        Me.Label323.Name = "Label323"
        Me.Label323.Size = New System.Drawing.Size(60, 20)
        Me.Label323.TabIndex = 5
        Me.Label323.Text = "Failed"
        '
        'optionPassedSRCheckFull
        '
        Me.optionPassedSRCheckFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSRCheckFull.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSRCheckFull.Name = "optionPassedSRCheckFull"
        Me.optionPassedSRCheckFull.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSRCheckFull.TabIndex = 4
        '
        'optionPtStateSRCheckFull
        '
        Me.optionPtStateSRCheckFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSRCheckFull.FormattingEnabled = True
        Me.optionPtStateSRCheckFull.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSRCheckFull.Name = "optionPtStateSRCheckFull"
        Me.optionPtStateSRCheckFull.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSRCheckFull.TabIndex = 3
        '
        'Label324
        '
        Me.Label324.AutoSize = True
        Me.Label324.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label324.Location = New System.Drawing.Point(463, 40)
        Me.Label324.Name = "Label324"
        Me.Label324.Size = New System.Drawing.Size(71, 20)
        Me.Label324.TabIndex = 2
        Me.Label324.Text = "Passed"
        '
        'optionVersionSRCheckFull
        '
        Me.optionVersionSRCheckFull.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSRCheckFull.FormattingEnabled = True
        Me.optionVersionSRCheckFull.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSRCheckFull.Name = "optionVersionSRCheckFull"
        Me.optionVersionSRCheckFull.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSRCheckFull.TabIndex = 1
        '
        'Label325
        '
        Me.Label325.AutoSize = True
        Me.Label325.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label325.Location = New System.Drawing.Point(104, 37)
        Me.Label325.Name = "Label325"
        Me.Label325.Size = New System.Drawing.Size(73, 20)
        Me.Label325.TabIndex = 0
        Me.Label325.Text = "Version"
        '
        'TabPage51
        '
        Me.TabPage51.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage51.Controls.Add(Me.optionDefectStateSRCheckRegression)
        Me.TabPage51.Controls.Add(Me.Label326)
        Me.TabPage51.Controls.Add(Me.Label327)
        Me.TabPage51.Controls.Add(Me.optionDefectIdSRCheckRegression)
        Me.TabPage51.Controls.Add(Me.Label328)
        Me.TabPage51.Controls.Add(Me.optionDefectKindSRCheckRegression)
        Me.TabPage51.Controls.Add(Me.Label329)
        Me.TabPage51.Controls.Add(Me.optionPtIdSRCheckRegression)
        Me.TabPage51.Controls.Add(Me.Label330)
        Me.TabPage51.Controls.Add(Me.optionFailedSRCheckRegression)
        Me.TabPage51.Controls.Add(Me.Label331)
        Me.TabPage51.Controls.Add(Me.optionPassedSRCheckRegression)
        Me.TabPage51.Controls.Add(Me.optionPtStateSRCheckRegression)
        Me.TabPage51.Controls.Add(Me.Label332)
        Me.TabPage51.Controls.Add(Me.optionVersionSRCheckRegression)
        Me.TabPage51.Controls.Add(Me.Label333)
        Me.TabPage51.Location = New System.Drawing.Point(4, 25)
        Me.TabPage51.Name = "TabPage51"
        Me.TabPage51.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage51.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage51.TabIndex = 1
        Me.TabPage51.Text = "REGRESSION"
        '
        'optionDefectStateSRCheckRegression
        '
        Me.optionDefectStateSRCheckRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSRCheckRegression.FormattingEnabled = True
        Me.optionDefectStateSRCheckRegression.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSRCheckRegression.Name = "optionDefectStateSRCheckRegression"
        Me.optionDefectStateSRCheckRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSRCheckRegression.TabIndex = 32
        '
        'Label326
        '
        Me.Label326.AutoSize = True
        Me.Label326.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label326.Location = New System.Drawing.Point(762, 144)
        Me.Label326.Name = "Label326"
        Me.Label326.Size = New System.Drawing.Size(53, 20)
        Me.Label326.TabIndex = 31
        Me.Label326.Text = "State"
        '
        'Label327
        '
        Me.Label327.AutoSize = True
        Me.Label327.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label327.Location = New System.Drawing.Point(104, 141)
        Me.Label327.Name = "Label327"
        Me.Label327.Size = New System.Drawing.Size(86, 20)
        Me.Label327.TabIndex = 30
        Me.Label327.Text = "Defect id"
        '
        'optionDefectIdSRCheckRegression
        '
        Me.optionDefectIdSRCheckRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSRCheckRegression.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSRCheckRegression.Name = "optionDefectIdSRCheckRegression"
        Me.optionDefectIdSRCheckRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSRCheckRegression.TabIndex = 29
        '
        'Label328
        '
        Me.Label328.AutoSize = True
        Me.Label328.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label328.Location = New System.Drawing.Point(463, 142)
        Me.Label328.Name = "Label328"
        Me.Label328.Size = New System.Drawing.Size(46, 20)
        Me.Label328.TabIndex = 28
        Me.Label328.Text = "Kind"
        '
        'optionDefectKindSRCheckRegression
        '
        Me.optionDefectKindSRCheckRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSRCheckRegression.FormattingEnabled = True
        Me.optionDefectKindSRCheckRegression.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSRCheckRegression.Name = "optionDefectKindSRCheckRegression"
        Me.optionDefectKindSRCheckRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSRCheckRegression.TabIndex = 27
        '
        'Label329
        '
        Me.Label329.AutoSize = True
        Me.Label329.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label329.Location = New System.Drawing.Point(104, 88)
        Me.Label329.Name = "Label329"
        Me.Label329.Size = New System.Drawing.Size(53, 20)
        Me.Label329.TabIndex = 26
        Me.Label329.Text = "PT id"
        '
        'optionPtIdSRCheckRegression
        '
        Me.optionPtIdSRCheckRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSRCheckRegression.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSRCheckRegression.Name = "optionPtIdSRCheckRegression"
        Me.optionPtIdSRCheckRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSRCheckRegression.TabIndex = 25
        '
        'Label330
        '
        Me.Label330.AutoSize = True
        Me.Label330.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label330.Location = New System.Drawing.Point(463, 92)
        Me.Label330.Name = "Label330"
        Me.Label330.Size = New System.Drawing.Size(53, 20)
        Me.Label330.TabIndex = 24
        Me.Label330.Text = "State"
        '
        'optionFailedSRCheckRegression
        '
        Me.optionFailedSRCheckRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSRCheckRegression.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSRCheckRegression.Name = "optionFailedSRCheckRegression"
        Me.optionFailedSRCheckRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSRCheckRegression.TabIndex = 23
        '
        'Label331
        '
        Me.Label331.AutoSize = True
        Me.Label331.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label331.Location = New System.Drawing.Point(762, 42)
        Me.Label331.Name = "Label331"
        Me.Label331.Size = New System.Drawing.Size(60, 20)
        Me.Label331.TabIndex = 22
        Me.Label331.Text = "Failed"
        '
        'optionPassedSRCheckRegression
        '
        Me.optionPassedSRCheckRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSRCheckRegression.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSRCheckRegression.Name = "optionPassedSRCheckRegression"
        Me.optionPassedSRCheckRegression.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSRCheckRegression.TabIndex = 21
        '
        'optionPtStateSRCheckRegression
        '
        Me.optionPtStateSRCheckRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSRCheckRegression.FormattingEnabled = True
        Me.optionPtStateSRCheckRegression.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSRCheckRegression.Name = "optionPtStateSRCheckRegression"
        Me.optionPtStateSRCheckRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSRCheckRegression.TabIndex = 20
        '
        'Label332
        '
        Me.Label332.AutoSize = True
        Me.Label332.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label332.Location = New System.Drawing.Point(463, 40)
        Me.Label332.Name = "Label332"
        Me.Label332.Size = New System.Drawing.Size(71, 20)
        Me.Label332.TabIndex = 19
        Me.Label332.Text = "Passed"
        '
        'optionVersionSRCheckRegression
        '
        Me.optionVersionSRCheckRegression.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSRCheckRegression.FormattingEnabled = True
        Me.optionVersionSRCheckRegression.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSRCheckRegression.Name = "optionVersionSRCheckRegression"
        Me.optionVersionSRCheckRegression.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSRCheckRegression.TabIndex = 18
        '
        'Label333
        '
        Me.Label333.AutoSize = True
        Me.Label333.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label333.Location = New System.Drawing.Point(104, 37)
        Me.Label333.Name = "Label333"
        Me.Label333.Size = New System.Drawing.Size(73, 20)
        Me.Label333.TabIndex = 17
        Me.Label333.Text = "Version"
        '
        'TabPage52
        '
        Me.TabPage52.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TabPage52.Controls.Add(Me.optionDefectStateSRCheckDelta)
        Me.TabPage52.Controls.Add(Me.Label334)
        Me.TabPage52.Controls.Add(Me.Label335)
        Me.TabPage52.Controls.Add(Me.optionDefectIdSRCheckDelta)
        Me.TabPage52.Controls.Add(Me.Label336)
        Me.TabPage52.Controls.Add(Me.optionDefectKindSRCheckDelta)
        Me.TabPage52.Controls.Add(Me.Label337)
        Me.TabPage52.Controls.Add(Me.optionPtIdSRCheckDelta)
        Me.TabPage52.Controls.Add(Me.Label338)
        Me.TabPage52.Controls.Add(Me.optionFailedSRCheckDelta)
        Me.TabPage52.Controls.Add(Me.Label339)
        Me.TabPage52.Controls.Add(Me.optionPassedSRCheckDelta)
        Me.TabPage52.Controls.Add(Me.optionPtStateSRCheckDelta)
        Me.TabPage52.Controls.Add(Me.Label340)
        Me.TabPage52.Controls.Add(Me.optionVersionSRCheckDelta)
        Me.TabPage52.Controls.Add(Me.Label341)
        Me.TabPage52.Location = New System.Drawing.Point(4, 25)
        Me.TabPage52.Name = "TabPage52"
        Me.TabPage52.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage52.Size = New System.Drawing.Size(1122, 222)
        Me.TabPage52.TabIndex = 2
        Me.TabPage52.Text = "DELTA"
        '
        'optionDefectStateSRCheckDelta
        '
        Me.optionDefectStateSRCheckDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectStateSRCheckDelta.FormattingEnabled = True
        Me.optionDefectStateSRCheckDelta.Location = New System.Drawing.Point(828, 141)
        Me.optionDefectStateSRCheckDelta.Name = "optionDefectStateSRCheckDelta"
        Me.optionDefectStateSRCheckDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectStateSRCheckDelta.TabIndex = 32
        '
        'Label334
        '
        Me.Label334.AutoSize = True
        Me.Label334.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label334.Location = New System.Drawing.Point(762, 144)
        Me.Label334.Name = "Label334"
        Me.Label334.Size = New System.Drawing.Size(53, 20)
        Me.Label334.TabIndex = 31
        Me.Label334.Text = "State"
        '
        'Label335
        '
        Me.Label335.AutoSize = True
        Me.Label335.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label335.Location = New System.Drawing.Point(104, 141)
        Me.Label335.Name = "Label335"
        Me.Label335.Size = New System.Drawing.Size(86, 20)
        Me.Label335.TabIndex = 30
        Me.Label335.Text = "Defect id"
        '
        'optionDefectIdSRCheckDelta
        '
        Me.optionDefectIdSRCheckDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectIdSRCheckDelta.Location = New System.Drawing.Point(252, 141)
        Me.optionDefectIdSRCheckDelta.Name = "optionDefectIdSRCheckDelta"
        Me.optionDefectIdSRCheckDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionDefectIdSRCheckDelta.TabIndex = 29
        '
        'Label336
        '
        Me.Label336.AutoSize = True
        Me.Label336.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label336.Location = New System.Drawing.Point(463, 142)
        Me.Label336.Name = "Label336"
        Me.Label336.Size = New System.Drawing.Size(46, 20)
        Me.Label336.TabIndex = 28
        Me.Label336.Text = "Kind"
        '
        'optionDefectKindSRCheckDelta
        '
        Me.optionDefectKindSRCheckDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionDefectKindSRCheckDelta.FormattingEnabled = True
        Me.optionDefectKindSRCheckDelta.Location = New System.Drawing.Point(540, 139)
        Me.optionDefectKindSRCheckDelta.Name = "optionDefectKindSRCheckDelta"
        Me.optionDefectKindSRCheckDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionDefectKindSRCheckDelta.TabIndex = 27
        '
        'Label337
        '
        Me.Label337.AutoSize = True
        Me.Label337.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label337.Location = New System.Drawing.Point(104, 88)
        Me.Label337.Name = "Label337"
        Me.Label337.Size = New System.Drawing.Size(53, 20)
        Me.Label337.TabIndex = 26
        Me.Label337.Text = "PT id"
        '
        'optionPtIdSRCheckDelta
        '
        Me.optionPtIdSRCheckDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtIdSRCheckDelta.Location = New System.Drawing.Point(252, 88)
        Me.optionPtIdSRCheckDelta.Name = "optionPtIdSRCheckDelta"
        Me.optionPtIdSRCheckDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPtIdSRCheckDelta.TabIndex = 25
        '
        'Label338
        '
        Me.Label338.AutoSize = True
        Me.Label338.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label338.Location = New System.Drawing.Point(463, 92)
        Me.Label338.Name = "Label338"
        Me.Label338.Size = New System.Drawing.Size(53, 20)
        Me.Label338.TabIndex = 24
        Me.Label338.Text = "State"
        '
        'optionFailedSRCheckDelta
        '
        Me.optionFailedSRCheckDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionFailedSRCheckDelta.Location = New System.Drawing.Point(828, 42)
        Me.optionFailedSRCheckDelta.Name = "optionFailedSRCheckDelta"
        Me.optionFailedSRCheckDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionFailedSRCheckDelta.TabIndex = 23
        '
        'Label339
        '
        Me.Label339.AutoSize = True
        Me.Label339.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label339.Location = New System.Drawing.Point(762, 42)
        Me.Label339.Name = "Label339"
        Me.Label339.Size = New System.Drawing.Size(60, 20)
        Me.Label339.TabIndex = 22
        Me.Label339.Text = "Failed"
        '
        'optionPassedSRCheckDelta
        '
        Me.optionPassedSRCheckDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPassedSRCheckDelta.Location = New System.Drawing.Point(540, 40)
        Me.optionPassedSRCheckDelta.Name = "optionPassedSRCheckDelta"
        Me.optionPassedSRCheckDelta.Size = New System.Drawing.Size(205, 26)
        Me.optionPassedSRCheckDelta.TabIndex = 21
        '
        'optionPtStateSRCheckDelta
        '
        Me.optionPtStateSRCheckDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionPtStateSRCheckDelta.FormattingEnabled = True
        Me.optionPtStateSRCheckDelta.Location = New System.Drawing.Point(540, 86)
        Me.optionPtStateSRCheckDelta.Name = "optionPtStateSRCheckDelta"
        Me.optionPtStateSRCheckDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionPtStateSRCheckDelta.TabIndex = 20
        '
        'Label340
        '
        Me.Label340.AutoSize = True
        Me.Label340.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label340.Location = New System.Drawing.Point(463, 40)
        Me.Label340.Name = "Label340"
        Me.Label340.Size = New System.Drawing.Size(71, 20)
        Me.Label340.TabIndex = 19
        Me.Label340.Text = "Passed"
        '
        'optionVersionSRCheckDelta
        '
        Me.optionVersionSRCheckDelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optionVersionSRCheckDelta.FormattingEnabled = True
        Me.optionVersionSRCheckDelta.Location = New System.Drawing.Point(252, 37)
        Me.optionVersionSRCheckDelta.Name = "optionVersionSRCheckDelta"
        Me.optionVersionSRCheckDelta.Size = New System.Drawing.Size(205, 28)
        Me.optionVersionSRCheckDelta.TabIndex = 18
        '
        'Label341
        '
        Me.Label341.AutoSize = True
        Me.Label341.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label341.Location = New System.Drawing.Point(104, 37)
        Me.Label341.Name = "Label341"
        Me.Label341.Size = New System.Drawing.Size(73, 20)
        Me.Label341.TabIndex = 17
        Me.Label341.Text = "Version"
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.DarkGreen
        Me.Button17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button17.Location = New System.Drawing.Point(441, 870)
        Me.Button17.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(127, 33)
        Me.Button17.TabIndex = 26
        Me.Button17.Text = "RESET"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'TestReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1735, 914)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.terminal)
        Me.Controls.Add(Me.ouputReportLocation)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "TestReport"
        Me.Text = "Test Report"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.Panel32.ResumeLayout(False)
        Me.Panel32.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.Panel33.ResumeLayout(False)
        Me.Panel33.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel34.ResumeLayout(False)
        Me.Panel34.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.Panel35.ResumeLayout(False)
        Me.Panel35.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        Me.Panel36.ResumeLayout(False)
        Me.Panel36.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.Panel37.ResumeLayout(False)
        Me.Panel37.PerformLayout()
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel38.ResumeLayout(False)
        Me.Panel38.PerformLayout()
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.Panel39.ResumeLayout(False)
        Me.Panel39.PerformLayout()
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel40.ResumeLayout(False)
        Me.Panel40.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage13.PerformLayout()
        Me.TabPage14.ResumeLayout(False)
        Me.TabPage14.PerformLayout()
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage15.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage16.ResumeLayout(False)
        Me.TabPage16.PerformLayout()
        Me.TabPage17.ResumeLayout(False)
        Me.TabPage17.PerformLayout()
        Me.TabPage18.ResumeLayout(False)
        Me.TabPage18.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.TabControl4.ResumeLayout(False)
        Me.TabPage19.ResumeLayout(False)
        Me.TabPage19.PerformLayout()
        Me.TabPage20.ResumeLayout(False)
        Me.TabPage20.PerformLayout()
        Me.TabPage21.ResumeLayout(False)
        Me.TabPage21.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.TabControl5.ResumeLayout(False)
        Me.TabPage22.ResumeLayout(False)
        Me.TabPage22.PerformLayout()
        Me.TabPage23.ResumeLayout(False)
        Me.TabPage23.PerformLayout()
        Me.TabPage24.ResumeLayout(False)
        Me.TabPage24.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.TabControl6.ResumeLayout(False)
        Me.TabPage25.ResumeLayout(False)
        Me.TabPage25.PerformLayout()
        Me.TabPage26.ResumeLayout(False)
        Me.TabPage26.PerformLayout()
        Me.TabPage27.ResumeLayout(False)
        Me.TabPage27.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.TabControl7.ResumeLayout(False)
        Me.TabPage28.ResumeLayout(False)
        Me.TabPage28.PerformLayout()
        Me.TabPage29.ResumeLayout(False)
        Me.TabPage29.PerformLayout()
        Me.TabPage30.ResumeLayout(False)
        Me.TabPage30.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.TabControl8.ResumeLayout(False)
        Me.TabPage31.ResumeLayout(False)
        Me.TabPage31.PerformLayout()
        Me.TabPage32.ResumeLayout(False)
        Me.TabPage32.PerformLayout()
        Me.TabPage33.ResumeLayout(False)
        Me.TabPage33.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.TabControl9.ResumeLayout(False)
        Me.TabPage34.ResumeLayout(False)
        Me.TabPage34.PerformLayout()
        Me.TabPage35.ResumeLayout(False)
        Me.TabPage35.PerformLayout()
        Me.TabPage36.ResumeLayout(False)
        Me.TabPage36.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.TabControl10.ResumeLayout(False)
        Me.TabPage37.ResumeLayout(False)
        Me.TabPage37.PerformLayout()
        Me.TabPage38.ResumeLayout(False)
        Me.TabPage38.PerformLayout()
        Me.TabPage39.ResumeLayout(False)
        Me.TabPage39.PerformLayout()
        Me.TabPage10.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.TabControl11.ResumeLayout(False)
        Me.TabPage40.ResumeLayout(False)
        Me.TabPage40.PerformLayout()
        Me.TabPage41.ResumeLayout(False)
        Me.TabPage41.PerformLayout()
        Me.TabPage42.ResumeLayout(False)
        Me.TabPage42.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.TabControl12.ResumeLayout(False)
        Me.TabPage43.ResumeLayout(False)
        Me.TabPage43.PerformLayout()
        Me.TabPage44.ResumeLayout(False)
        Me.TabPage44.PerformLayout()
        Me.TabPage45.ResumeLayout(False)
        Me.TabPage45.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.TabControl13.ResumeLayout(False)
        Me.TabPage46.ResumeLayout(False)
        Me.TabPage46.PerformLayout()
        Me.TabPage47.ResumeLayout(False)
        Me.TabPage47.PerformLayout()
        Me.TabPage48.ResumeLayout(False)
        Me.TabPage48.PerformLayout()
        Me.TabPage49.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.TabControl14.ResumeLayout(False)
        Me.TabPage50.ResumeLayout(False)
        Me.TabPage50.PerformLayout()
        Me.TabPage51.ResumeLayout(False)
        Me.TabPage51.PerformLayout()
        Me.TabPage52.ResumeLayout(False)
        Me.TabPage52.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents swVariant As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents swRelease As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents swHMA As CheckBox
    Friend WithEvents swVehicle As CheckBox
    Friend WithEvents swELK As CheckBox
    Friend WithEvents swTJA As CheckBox
    Friend WithEvents swLDW As CheckBox
    Friend WithEvents swSLA As CheckBox
    Friend WithEvents swLKS As CheckBox
    Friend WithEvents swCOM As CheckBox
    Friend WithEvents swRDP As CheckBox
    Friend WithEvents swEM As CheckBox
    Friend WithEvents swDCOM As CheckBox
    Friend WithEvents swVersion As ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents documentVersion As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents startDate As DateTimePicker
    Friend WithEvents testCoordinator As ComboBox
    Friend WithEvents levelOfTesting As ComboBox
    Friend WithEvents endDate As DateTimePicker
    Friend WithEvents swSIT As CheckBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents modifiedBy As TextBox
    Friend WithEvents documentOwner As TextBox
    Friend WithEvents releaseDate As DateTimePicker
    Friend WithEvents Label21 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents swDelivery As RichTextBox
    Friend WithEvents swCoresi As RichTextBox
    Friend WithEvents swSource As RichTextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents ouputReportLocation As TextBox
    Friend WithEvents terminal As RichTextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents TabPage14 As TabPage
    Friend WithEvents TabPage15 As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents optionVersionDCOMFull As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents optionFailedDCOMFull As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents optionPassedDCOMFull As TextBox
    Friend WithEvents optionPtStateDCOMFull As ComboBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents optionPtIdDCOMFull As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents optionDefectIdDCOMFull As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents optionDefectKindDCOMFull As ComboBox
    Friend WithEvents optionLabTDCOM As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents swSRCheck As CheckBox
    Friend WithEvents Label39 As Label
    Friend WithEvents optionDefectStateDCOMFull As ComboBox
    Friend WithEvents optionDefectStateDCOMRegression As ComboBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents optionDefectIdDCOMRegression As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents optionDefectKindDCOMRegression As ComboBox
    Friend WithEvents Label28 As Label
    Friend WithEvents optionPtIdDCOMRegression As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents optionFailedDCOMRegression As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents optionPassedDCOMRegression As TextBox
    Friend WithEvents optionPtStateDCOMRegression As ComboBox
    Friend WithEvents Label31 As Label
    Friend WithEvents optionVersionDCOMRegression As ComboBox
    Friend WithEvents Label32 As Label
    Friend WithEvents optionDefectStateDCOMDelta As ComboBox
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents optionDefectIdDCOMDelta As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents optionDefectKindDCOMDelta As ComboBox
    Friend WithEvents Label36 As Label
    Friend WithEvents optionPtIdDCOMDelta As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents optionFailedDCOMDelta As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents optionPassedDCOMDelta As TextBox
    Friend WithEvents optionPtStateDCOMDelta As ComboBox
    Friend WithEvents Label40 As Label
    Friend WithEvents optionVersionDCOMDelta As ComboBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents optionLabTEM As TextBox
    Friend WithEvents Label42 As Label
    Friend WithEvents TabControl3 As TabControl
    Friend WithEvents TabPage16 As TabPage
    Friend WithEvents optionDefectStateEMFull As ComboBox
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents optionDefectIdEMFull As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents optionDefectKindEMFull As ComboBox
    Friend WithEvents Label46 As Label
    Friend WithEvents optionPtIdEMFull As TextBox
    Friend WithEvents Label47 As Label
    Friend WithEvents optionFailedEMFull As TextBox
    Friend WithEvents Label48 As Label
    Friend WithEvents optionPassedEMFull As TextBox
    Friend WithEvents optionPtStateEMFull As ComboBox
    Friend WithEvents Label49 As Label
    Friend WithEvents optionVersionEMFull As ComboBox
    Friend WithEvents Label50 As Label
    Friend WithEvents TabPage17 As TabPage
    Friend WithEvents optionDefectStateEMRegression As ComboBox
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents optionDefectIdEMRegression As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents optionDefectKindEMRegression As ComboBox
    Friend WithEvents Label54 As Label
    Friend WithEvents optionPtIdEMRegression As TextBox
    Friend WithEvents Label55 As Label
    Friend WithEvents optionFailedEMRegression As TextBox
    Friend WithEvents Label56 As Label
    Friend WithEvents optionPassedEMRegression As TextBox
    Friend WithEvents optionPtStateEMRegression As ComboBox
    Friend WithEvents Label57 As Label
    Friend WithEvents optionVersionEMRegression As ComboBox
    Friend WithEvents Label58 As Label
    Friend WithEvents TabPage18 As TabPage
    Friend WithEvents optionDefectStateEMDelta As ComboBox
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents optionDefectIdEMDelta As TextBox
    Friend WithEvents Label61 As Label
    Friend WithEvents optionDefectKindEMDelta As ComboBox
    Friend WithEvents Label62 As Label
    Friend WithEvents optionPtIdEMDelta As TextBox
    Friend WithEvents Label63 As Label
    Friend WithEvents optionFailedEMDelta As TextBox
    Friend WithEvents Label64 As Label
    Friend WithEvents optionPassedEMDelta As TextBox
    Friend WithEvents optionPtStateEMDelta As ComboBox
    Friend WithEvents Label65 As Label
    Friend WithEvents optionVersionEMDelta As ComboBox
    Friend WithEvents Label66 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents optionLabTCOM As TextBox
    Friend WithEvents Label67 As Label
    Friend WithEvents TabControl4 As TabControl
    Friend WithEvents TabPage19 As TabPage
    Friend WithEvents optionDefectStateCOMFull As ComboBox
    Friend WithEvents Label68 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents optionDefectIdCOMFull As TextBox
    Friend WithEvents Label70 As Label
    Friend WithEvents optionDefectKindCOMFull As ComboBox
    Friend WithEvents Label71 As Label
    Friend WithEvents optionPtIdCOMFull As TextBox
    Friend WithEvents Label72 As Label
    Friend WithEvents optionFailedCOMFull As TextBox
    Friend WithEvents Label73 As Label
    Friend WithEvents optionPassedCOMFull As TextBox
    Friend WithEvents optionPtStateCOMFull As ComboBox
    Friend WithEvents Label74 As Label
    Friend WithEvents optionVersionCOMFull As ComboBox
    Friend WithEvents Label75 As Label
    Friend WithEvents TabPage20 As TabPage
    Friend WithEvents optionDefectStateCOMRegression As ComboBox
    Friend WithEvents Label76 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents optionDefectIdCOMRegression As TextBox
    Friend WithEvents Label78 As Label
    Friend WithEvents optionDefectKindCOMRegression As ComboBox
    Friend WithEvents Label79 As Label
    Friend WithEvents optionPtIdCOMRegression As TextBox
    Friend WithEvents Label80 As Label
    Friend WithEvents optionFailedCOMRegression As TextBox
    Friend WithEvents Label81 As Label
    Friend WithEvents optionPassedCOMRegression As TextBox
    Friend WithEvents optionPtStateCOMRegression As ComboBox
    Friend WithEvents Label82 As Label
    Friend WithEvents optionVersionCOMRegression As ComboBox
    Friend WithEvents Label83 As Label
    Friend WithEvents optionDefectStateCOMDelta As ComboBox
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents optionDefectIdCOMDelta As TextBox
    Friend WithEvents Label86 As Label
    Friend WithEvents optionDefectKindCOMDelta As ComboBox
    Friend WithEvents Label87 As Label
    Friend WithEvents optionPtIdCOMDelta As TextBox
    Friend WithEvents Label88 As Label
    Friend WithEvents optionFailedCOMDelta As TextBox
    Friend WithEvents Label89 As Label
    Friend WithEvents optionPassedCOMDelta As TextBox
    Friend WithEvents optionPtStateCOMDelta As ComboBox
    Friend WithEvents Label90 As Label
    Friend WithEvents optionVersionCOMDelta As ComboBox
    Friend WithEvents Label91 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents optionLabTLDW As TextBox
    Friend WithEvents Label92 As Label
    Friend WithEvents TabControl5 As TabControl
    Friend WithEvents TabPage22 As TabPage
    Friend WithEvents optionDefectStateLDWFull As ComboBox
    Friend WithEvents Label93 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents optionDefectIdLDWFull As TextBox
    Friend WithEvents Label95 As Label
    Friend WithEvents optionDefectKindLDWFull As ComboBox
    Friend WithEvents Label96 As Label
    Friend WithEvents optionPtIdLDWFull As TextBox
    Friend WithEvents Label97 As Label
    Friend WithEvents optionFailedLDWFull As TextBox
    Friend WithEvents Label98 As Label
    Friend WithEvents optionPassedLDWFull As TextBox
    Friend WithEvents optionPtStateLDWFull As ComboBox
    Friend WithEvents Label99 As Label
    Friend WithEvents optionVersionLDWFull As ComboBox
    Friend WithEvents Label100 As Label
    Friend WithEvents TabPage23 As TabPage
    Friend WithEvents optionDefectStateLDWRegression As ComboBox
    Friend WithEvents Label101 As Label
    Friend WithEvents Label102 As Label
    Friend WithEvents optionDefectIdLDWRegression As TextBox
    Friend WithEvents Label103 As Label
    Friend WithEvents optionDefectKindLDWRegression As ComboBox
    Friend WithEvents Label104 As Label
    Friend WithEvents optionPtIdLDWRegression As TextBox
    Friend WithEvents Label106 As Label
    Friend WithEvents optionFailedLDWRegression As TextBox
    Friend WithEvents Label107 As Label
    Friend WithEvents optionPassedLDWRegression As TextBox
    Friend WithEvents optionPtStateLDWRegression As ComboBox
    Friend WithEvents Label108 As Label
    Friend WithEvents optionVersionLDWRegression As ComboBox
    Friend WithEvents Label109 As Label
    Friend WithEvents TabPage24 As TabPage
    Friend WithEvents optionDefectStateLDWDelta As ComboBox
    Friend WithEvents Label110 As Label
    Friend WithEvents Label111 As Label
    Friend WithEvents optionDefectIdLDWDelta As TextBox
    Friend WithEvents Label112 As Label
    Friend WithEvents optionDefectKindLDWDelta As ComboBox
    Friend WithEvents Label113 As Label
    Friend WithEvents optionPtIdLDWDelta As TextBox
    Friend WithEvents Label114 As Label
    Friend WithEvents optionFailedLDWDelta As TextBox
    Friend WithEvents Label115 As Label
    Friend WithEvents optionPassedLDWDelta As TextBox
    Friend WithEvents optionPtStateLDWDelta As ComboBox
    Friend WithEvents Label116 As Label
    Friend WithEvents optionVersionLDWDelta As ComboBox
    Friend WithEvents Label117 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents optionLabTLKS As TextBox
    Friend WithEvents Label105 As Label
    Friend WithEvents TabControl6 As TabControl
    Friend WithEvents TabPage25 As TabPage
    Friend WithEvents optionDefectStateLKSFull As ComboBox
    Friend WithEvents Label118 As Label
    Friend WithEvents Label119 As Label
    Friend WithEvents optionDefectIdLKSFull As TextBox
    Friend WithEvents Label120 As Label
    Friend WithEvents optionDefectKindLKSFull As ComboBox
    Friend WithEvents Label121 As Label
    Friend WithEvents optionPtIdLKSFull As TextBox
    Friend WithEvents Label122 As Label
    Friend WithEvents optionFailedLKSFull As TextBox
    Friend WithEvents Label123 As Label
    Friend WithEvents optionPassedLKSFull As TextBox
    Friend WithEvents optionPtStateLKSFull As ComboBox
    Friend WithEvents Label124 As Label
    Friend WithEvents optionVersionLKSFull As ComboBox
    Friend WithEvents Label125 As Label
    Friend WithEvents TabPage26 As TabPage
    Friend WithEvents optionDefectStateLKSRegression As ComboBox
    Friend WithEvents Label126 As Label
    Friend WithEvents Label127 As Label
    Friend WithEvents optionDefectIdLKSRegression As TextBox
    Friend WithEvents Label128 As Label
    Friend WithEvents optionDefectKindLKSRegression As ComboBox
    Friend WithEvents Label129 As Label
    Friend WithEvents optionPtIdLKSRegression As TextBox
    Friend WithEvents Label130 As Label
    Friend WithEvents optionFailedLKSRegression As TextBox
    Friend WithEvents Label131 As Label
    Friend WithEvents optionPassedLKSRegression As TextBox
    Friend WithEvents optionPtStateLKSRegression As ComboBox
    Friend WithEvents Label132 As Label
    Friend WithEvents optionVersionLKSRegression As ComboBox
    Friend WithEvents Label133 As Label
    Friend WithEvents TabPage27 As TabPage
    Friend WithEvents optionDefectStateLKSDelta As ComboBox
    Friend WithEvents Label134 As Label
    Friend WithEvents Label135 As Label
    Friend WithEvents optionDefectIdLKSDelta As TextBox
    Friend WithEvents Label136 As Label
    Friend WithEvents optionDefectKindLKSDelta As ComboBox
    Friend WithEvents Label137 As Label
    Friend WithEvents optionPtIdLKSDelta As TextBox
    Friend WithEvents Label138 As Label
    Friend WithEvents optionFailedLKSDelta As TextBox
    Friend WithEvents Label139 As Label
    Friend WithEvents optionPassedLKSDelta As TextBox
    Friend WithEvents optionPtStateLKSDelta As ComboBox
    Friend WithEvents Label140 As Label
    Friend WithEvents optionVersionLKSDelta As ComboBox
    Friend WithEvents Label141 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents optionLabTRDP As TextBox
    Friend WithEvents Label142 As Label
    Friend WithEvents TabControl7 As TabControl
    Friend WithEvents TabPage28 As TabPage
    Friend WithEvents optionDefectStateRDPFull As ComboBox
    Friend WithEvents Label143 As Label
    Friend WithEvents Label144 As Label
    Friend WithEvents optionDefectIdRDPFull As TextBox
    Friend WithEvents Label145 As Label
    Friend WithEvents optionDefectKindRDPFull As ComboBox
    Friend WithEvents Label146 As Label
    Friend WithEvents optionPtIdRDPFull As TextBox
    Friend WithEvents Label147 As Label
    Friend WithEvents optionFailedRDPFull As TextBox
    Friend WithEvents Label148 As Label
    Friend WithEvents optionPassedRDPFull As TextBox
    Friend WithEvents optionPtStateRDPFull As ComboBox
    Friend WithEvents Label150 As Label
    Friend WithEvents optionVersionRDPFull As ComboBox
    Friend WithEvents Label151 As Label
    Friend WithEvents TabPage29 As TabPage
    Friend WithEvents optionDefectStateRDPRegression As ComboBox
    Friend WithEvents Label152 As Label
    Friend WithEvents Label153 As Label
    Friend WithEvents optionDefectIdRDPRegression As TextBox
    Friend WithEvents Label154 As Label
    Friend WithEvents optionDefectKindRDPRegression As ComboBox
    Friend WithEvents Label155 As Label
    Friend WithEvents optionPtIdRDPRegression As TextBox
    Friend WithEvents Label156 As Label
    Friend WithEvents optionFailedRDPRegression As TextBox
    Friend WithEvents Label157 As Label
    Friend WithEvents optionPassedRDPRegression As TextBox
    Friend WithEvents optionPtStateRDPRegression As ComboBox
    Friend WithEvents Label158 As Label
    Friend WithEvents optionVersionRDPRegression As ComboBox
    Friend WithEvents Label159 As Label
    Friend WithEvents TabPage30 As TabPage
    Friend WithEvents optionDefectStateRDPDelta As ComboBox
    Friend WithEvents Label160 As Label
    Friend WithEvents Label161 As Label
    Friend WithEvents optionDefectIdRDPDelta As TextBox
    Friend WithEvents Label162 As Label
    Friend WithEvents optionDefectKindRDPDelta As ComboBox
    Friend WithEvents Label163 As Label
    Friend WithEvents optionPtIdRDPDelta As TextBox
    Friend WithEvents Label164 As Label
    Friend WithEvents optionFailedRDPDelta As TextBox
    Friend WithEvents Label165 As Label
    Friend WithEvents optionPassedRDPDelta As TextBox
    Friend WithEvents optionPtStateRDPDelta As ComboBox
    Friend WithEvents Label166 As Label
    Friend WithEvents optionVersionRDPDelta As ComboBox
    Friend WithEvents Label167 As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents optionLabTELK As TextBox
    Friend WithEvents Label149 As Label
    Friend WithEvents TabControl8 As TabControl
    Friend WithEvents TabPage31 As TabPage
    Friend WithEvents optionDefectStateELKFull As ComboBox
    Friend WithEvents Label168 As Label
    Friend WithEvents Label169 As Label
    Friend WithEvents optionDefectIdELKFull As TextBox
    Friend WithEvents Label170 As Label
    Friend WithEvents optionDefectKindELKFull As ComboBox
    Friend WithEvents Label171 As Label
    Friend WithEvents optionPtIdELKFull As TextBox
    Friend WithEvents Label172 As Label
    Friend WithEvents optionFailedELKFull As TextBox
    Friend WithEvents Label173 As Label
    Friend WithEvents optionPassedELKFull As TextBox
    Friend WithEvents optionPtStateELKFull As ComboBox
    Friend WithEvents Label174 As Label
    Friend WithEvents optionVersionELKFull As ComboBox
    Friend WithEvents Label175 As Label
    Friend WithEvents TabPage32 As TabPage
    Friend WithEvents optionDefectStateELKRegression As ComboBox
    Friend WithEvents Label176 As Label
    Friend WithEvents Label177 As Label
    Friend WithEvents optionDefectIdELKRegression As TextBox
    Friend WithEvents Label178 As Label
    Friend WithEvents optionDefectKindELKRegression As ComboBox
    Friend WithEvents Label179 As Label
    Friend WithEvents optionPtIdELKRegression As TextBox
    Friend WithEvents Label180 As Label
    Friend WithEvents optionFailedELKRegression As TextBox
    Friend WithEvents Label181 As Label
    Friend WithEvents optionPassedELKRegression As TextBox
    Friend WithEvents optionPtStateELKRegression As ComboBox
    Friend WithEvents Label182 As Label
    Friend WithEvents optionVersionELKRegression As ComboBox
    Friend WithEvents Label183 As Label
    Friend WithEvents TabPage33 As TabPage
    Friend WithEvents optionDefectStateELKDelta As ComboBox
    Friend WithEvents Label184 As Label
    Friend WithEvents Label185 As Label
    Friend WithEvents optionDefectIdELKDelta As TextBox
    Friend WithEvents Label186 As Label
    Friend WithEvents optionDefectKindELKDelta As ComboBox
    Friend WithEvents Label187 As Label
    Friend WithEvents optionPtIdELKDelta As TextBox
    Friend WithEvents Label188 As Label
    Friend WithEvents optionFailedELKDelta As TextBox
    Friend WithEvents Label189 As Label
    Friend WithEvents optionPassedELKDelta As TextBox
    Friend WithEvents optionPtStateELKDelta As ComboBox
    Friend WithEvents Label190 As Label
    Friend WithEvents optionVersionELKDelta As ComboBox
    Friend WithEvents Label191 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents optionLabTTJA As TextBox
    Friend WithEvents Label192 As Label
    Friend WithEvents TabControl9 As TabControl
    Friend WithEvents TabPage34 As TabPage
    Friend WithEvents optionDefectStateTJAFull As ComboBox
    Friend WithEvents Label193 As Label
    Friend WithEvents Label194 As Label
    Friend WithEvents optionDefectIdTJAFull As TextBox
    Friend WithEvents Label195 As Label
    Friend WithEvents optionDefectKindTJAFull As ComboBox
    Friend WithEvents Label196 As Label
    Friend WithEvents optionPtIdTJAFull As TextBox
    Friend WithEvents Label197 As Label
    Friend WithEvents optionFailedTJAFull As TextBox
    Friend WithEvents Label198 As Label
    Friend WithEvents optionPassedTJAFull As TextBox
    Friend WithEvents optionPtStateTJAFull As ComboBox
    Friend WithEvents Label199 As Label
    Friend WithEvents optionVersionTJAFull As ComboBox
    Friend WithEvents Label200 As Label
    Friend WithEvents TabPage35 As TabPage
    Friend WithEvents optionDefectStateTJARegression As ComboBox
    Friend WithEvents Label201 As Label
    Friend WithEvents Label202 As Label
    Friend WithEvents optionDefectIdTJARegression As TextBox
    Friend WithEvents Label203 As Label
    Friend WithEvents optionDefectKindTJARegression As ComboBox
    Friend WithEvents Label204 As Label
    Friend WithEvents optionPtIdTJARegression As TextBox
    Friend WithEvents Label205 As Label
    Friend WithEvents optionFailedTJARegression As TextBox
    Friend WithEvents Label206 As Label
    Friend WithEvents optionPassedTJARegression As TextBox
    Friend WithEvents optionPtStateTJARegression As ComboBox
    Friend WithEvents Label207 As Label
    Friend WithEvents optionVersionTJARegression As ComboBox
    Friend WithEvents Label208 As Label
    Friend WithEvents TabPage36 As TabPage
    Friend WithEvents optionDefectStateTJADelta As ComboBox
    Friend WithEvents Label209 As Label
    Friend WithEvents Label210 As Label
    Friend WithEvents optionDefectIdTJADelta As TextBox
    Friend WithEvents Label211 As Label
    Friend WithEvents optionDefectKindTJADelta As ComboBox
    Friend WithEvents Label212 As Label
    Friend WithEvents optionPtIdTJADelta As TextBox
    Friend WithEvents Label213 As Label
    Friend WithEvents optionFailedTJADelta As TextBox
    Friend WithEvents Label214 As Label
    Friend WithEvents optionPassedTJADelta As TextBox
    Friend WithEvents optionPtStateTJADelta As ComboBox
    Friend WithEvents Label215 As Label
    Friend WithEvents optionVersionTJADelta As ComboBox
    Friend WithEvents Label216 As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents optionLabTSLA As TextBox
    Friend WithEvents Label217 As Label
    Friend WithEvents TabControl10 As TabControl
    Friend WithEvents TabPage37 As TabPage
    Friend WithEvents optionDefectStateSLAFull As ComboBox
    Friend WithEvents Label218 As Label
    Friend WithEvents Label219 As Label
    Friend WithEvents optionDefectIdSLAFull As TextBox
    Friend WithEvents Label220 As Label
    Friend WithEvents optionDefectKindSLAFull As ComboBox
    Friend WithEvents Label221 As Label
    Friend WithEvents optionPtIdSLAFull As TextBox
    Friend WithEvents Label222 As Label
    Friend WithEvents optionFailedSLAFull As TextBox
    Friend WithEvents Label223 As Label
    Friend WithEvents optionPassedSLAFull As TextBox
    Friend WithEvents optionPtStateSLAFull As ComboBox
    Friend WithEvents Label224 As Label
    Friend WithEvents optionVersionSLAFull As ComboBox
    Friend WithEvents Label225 As Label
    Friend WithEvents TabPage38 As TabPage
    Friend WithEvents optionDefectStateSLARegression As ComboBox
    Friend WithEvents Label226 As Label
    Friend WithEvents Label227 As Label
    Friend WithEvents optionDefectIdSLARegression As TextBox
    Friend WithEvents Label228 As Label
    Friend WithEvents optionDefectKindSLARegression As ComboBox
    Friend WithEvents Label229 As Label
    Friend WithEvents optionPtIdSLARegression As TextBox
    Friend WithEvents Label230 As Label
    Friend WithEvents optionFailedSLARegression As TextBox
    Friend WithEvents Label231 As Label
    Friend WithEvents optionPassedSLARegression As TextBox
    Friend WithEvents optionPtStateSLARegression As ComboBox
    Friend WithEvents Label232 As Label
    Friend WithEvents optionVersionSLARegression As ComboBox
    Friend WithEvents Label233 As Label
    Friend WithEvents TabPage39 As TabPage
    Friend WithEvents optionDefectStateSLADelta As ComboBox
    Friend WithEvents Label234 As Label
    Friend WithEvents Label235 As Label
    Friend WithEvents optionDefectIdSLADelta As TextBox
    Friend WithEvents Label236 As Label
    Friend WithEvents optionDefectKindSLADelta As ComboBox
    Friend WithEvents Label237 As Label
    Friend WithEvents optionPtIdSLADelta As TextBox
    Friend WithEvents Label238 As Label
    Friend WithEvents optionFailedSLADelta As TextBox
    Friend WithEvents Label239 As Label
    Friend WithEvents optionPassedSLADelta As TextBox
    Friend WithEvents optionPtStateSLADelta As ComboBox
    Friend WithEvents Label240 As Label
    Friend WithEvents optionVersionSLADelta As ComboBox
    Friend WithEvents Label241 As Label
    Friend WithEvents Panel11 As Panel
    Friend WithEvents optionLabTHMA As TextBox
    Friend WithEvents Label242 As Label
    Friend WithEvents TabControl11 As TabControl
    Friend WithEvents TabPage40 As TabPage
    Friend WithEvents optionDefectStateHMAFull As ComboBox
    Friend WithEvents Label243 As Label
    Friend WithEvents Label244 As Label
    Friend WithEvents optionDefectIdHMAFull As TextBox
    Friend WithEvents Label245 As Label
    Friend WithEvents optionDefectKindHMAFull As ComboBox
    Friend WithEvents Label246 As Label
    Friend WithEvents optionPtIdHMAFull As TextBox
    Friend WithEvents Label247 As Label
    Friend WithEvents optionFailedHMAFull As TextBox
    Friend WithEvents Label248 As Label
    Friend WithEvents optionPassedHMAFull As TextBox
    Friend WithEvents optionPtStateHMAFull As ComboBox
    Friend WithEvents Label249 As Label
    Friend WithEvents optionVersionHMAFull As ComboBox
    Friend WithEvents Label250 As Label
    Friend WithEvents TabPage41 As TabPage
    Friend WithEvents optionDefectStateHMARegression As ComboBox
    Friend WithEvents Label251 As Label
    Friend WithEvents Label252 As Label
    Friend WithEvents optionDefectIdHMARegression As TextBox
    Friend WithEvents Label253 As Label
    Friend WithEvents optionDefectKindHMARegression As ComboBox
    Friend WithEvents Label254 As Label
    Friend WithEvents optionPtIdHMARegression As TextBox
    Friend WithEvents Label255 As Label
    Friend WithEvents optionFailedHMARegression As TextBox
    Friend WithEvents Label256 As Label
    Friend WithEvents optionPassedHMARegression As TextBox
    Friend WithEvents optionPtStateHMARegression As ComboBox
    Friend WithEvents Label257 As Label
    Friend WithEvents optionVersionHMARegression As ComboBox
    Friend WithEvents Label258 As Label
    Friend WithEvents TabPage42 As TabPage
    Friend WithEvents optionDefectStateHMADelta As ComboBox
    Friend WithEvents Label259 As Label
    Friend WithEvents Label260 As Label
    Friend WithEvents optionDefectIdHMADelta As TextBox
    Friend WithEvents Label261 As Label
    Friend WithEvents optionDefectKindHMADelta As ComboBox
    Friend WithEvents Label262 As Label
    Friend WithEvents optionPtIdHMADelta As TextBox
    Friend WithEvents Label263 As Label
    Friend WithEvents optionFailedHMADelta As TextBox
    Friend WithEvents Label264 As Label
    Friend WithEvents optionPassedHMADelta As TextBox
    Friend WithEvents optionPtStateHMADelta As ComboBox
    Friend WithEvents Label265 As Label
    Friend WithEvents optionVersionHMADelta As ComboBox
    Friend WithEvents Label266 As Label
    Friend WithEvents Panel12 As Panel
    Friend WithEvents optionLabTVehicle As TextBox
    Friend WithEvents Label267 As Label
    Friend WithEvents TabControl12 As TabControl
    Friend WithEvents TabPage43 As TabPage
    Friend WithEvents optionDefectStateVehicleFull As ComboBox
    Friend WithEvents Label268 As Label
    Friend WithEvents Label269 As Label
    Friend WithEvents optionDefectIdVehicleFull As TextBox
    Friend WithEvents Label270 As Label
    Friend WithEvents optionDefectKindVehicleFull As ComboBox
    Friend WithEvents Label271 As Label
    Friend WithEvents optionPtIdVehicleFull As TextBox
    Friend WithEvents Label272 As Label
    Friend WithEvents optionFailedVehicleFull As TextBox
    Friend WithEvents Label273 As Label
    Friend WithEvents optionPassedVehicleFull As TextBox
    Friend WithEvents optionPtStateVehicleFull As ComboBox
    Friend WithEvents Label274 As Label
    Friend WithEvents optionVersionVehicleFull As ComboBox
    Friend WithEvents Label275 As Label
    Friend WithEvents TabPage44 As TabPage
    Friend WithEvents optionDefectStateVehicleRegression As ComboBox
    Friend WithEvents Label276 As Label
    Friend WithEvents Label277 As Label
    Friend WithEvents optionDefectIdVehicleRegression As TextBox
    Friend WithEvents Label278 As Label
    Friend WithEvents optionDefectKindVehicleRegression As ComboBox
    Friend WithEvents Label279 As Label
    Friend WithEvents optionPtIdVehicleRegression As TextBox
    Friend WithEvents Label280 As Label
    Friend WithEvents optionFailedVehicleRegression As TextBox
    Friend WithEvents Label281 As Label
    Friend WithEvents optionPassedVehicleRegression As TextBox
    Friend WithEvents optionPtStateVehicleRegression As ComboBox
    Friend WithEvents Label282 As Label
    Friend WithEvents optionVersionVehicleRegression As ComboBox
    Friend WithEvents Label283 As Label
    Friend WithEvents TabPage45 As TabPage
    Friend WithEvents optionDefectStateVehicleDelta As ComboBox
    Friend WithEvents Label284 As Label
    Friend WithEvents Label285 As Label
    Friend WithEvents optionDefectIdVehicleDelta As TextBox
    Friend WithEvents Label286 As Label
    Friend WithEvents optionDefectKindVehicleDelta As ComboBox
    Friend WithEvents Label287 As Label
    Friend WithEvents optionPtIdVehicleDelta As TextBox
    Friend WithEvents Label288 As Label
    Friend WithEvents optionFailedVehicleDelta As TextBox
    Friend WithEvents Label289 As Label
    Friend WithEvents optionPassedVehicleDelta As TextBox
    Friend WithEvents optionPtStateVehicleDelta As ComboBox
    Friend WithEvents Label290 As Label
    Friend WithEvents optionVersionVehicleDelta As ComboBox
    Friend WithEvents Label291 As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents optionLabTSIT As TextBox
    Friend WithEvents Label292 As Label
    Friend WithEvents TabControl13 As TabControl
    Friend WithEvents TabPage46 As TabPage
    Friend WithEvents optionDefectStateSITFull As ComboBox
    Friend WithEvents Label293 As Label
    Friend WithEvents Label294 As Label
    Friend WithEvents optionDefectIdSITFull As TextBox
    Friend WithEvents Label295 As Label
    Friend WithEvents optionDefectKindSITFull As ComboBox
    Friend WithEvents Label296 As Label
    Friend WithEvents optionPtIdSITFull As TextBox
    Friend WithEvents Label297 As Label
    Friend WithEvents optionFailedSITFull As TextBox
    Friend WithEvents Label298 As Label
    Friend WithEvents optionPassedSITFull As TextBox
    Friend WithEvents optionPtStateSITFull As ComboBox
    Friend WithEvents Label299 As Label
    Friend WithEvents optionVersionSITFull As ComboBox
    Friend WithEvents Label300 As Label
    Friend WithEvents TabPage47 As TabPage
    Friend WithEvents optionDefectStateSITRegression As ComboBox
    Friend WithEvents Label301 As Label
    Friend WithEvents Label302 As Label
    Friend WithEvents optionDefectIdSITRegression As TextBox
    Friend WithEvents Label303 As Label
    Friend WithEvents optionDefectKindSITRegression As ComboBox
    Friend WithEvents Label304 As Label
    Friend WithEvents optionPtIdSITRegression As TextBox
    Friend WithEvents Label305 As Label
    Friend WithEvents optionFailedSITRegression As TextBox
    Friend WithEvents Label306 As Label
    Friend WithEvents optionPassedSITRegression As TextBox
    Friend WithEvents optionPtStateSITRegression As ComboBox
    Friend WithEvents Label307 As Label
    Friend WithEvents optionVersionSITRegression As ComboBox
    Friend WithEvents Label308 As Label
    Friend WithEvents TabPage48 As TabPage
    Friend WithEvents optionDefectStateSITDelta As ComboBox
    Friend WithEvents Label309 As Label
    Friend WithEvents Label310 As Label
    Friend WithEvents optionDefectIdSITDelta As TextBox
    Friend WithEvents Label311 As Label
    Friend WithEvents optionDefectKindSITDelta As ComboBox
    Friend WithEvents Label312 As Label
    Friend WithEvents optionPtIdSITDelta As TextBox
    Friend WithEvents Label313 As Label
    Friend WithEvents optionFailedSITDelta As TextBox
    Friend WithEvents Label314 As Label
    Friend WithEvents optionPassedSITDelta As TextBox
    Friend WithEvents optionPtStateSITDelta As ComboBox
    Friend WithEvents Label315 As Label
    Friend WithEvents optionVersionSITDelta As ComboBox
    Friend WithEvents Label316 As Label
    Friend WithEvents TabPage49 As TabPage
    Friend WithEvents Panel14 As Panel
    Friend WithEvents optionLabTSRCheck As TextBox
    Friend WithEvents Label317 As Label
    Friend WithEvents TabControl14 As TabControl
    Friend WithEvents TabPage50 As TabPage
    Friend WithEvents optionDefectStateSRCheckFull As ComboBox
    Friend WithEvents Label318 As Label
    Friend WithEvents Label319 As Label
    Friend WithEvents optionDefectIdSRCheckFull As TextBox
    Friend WithEvents Label320 As Label
    Friend WithEvents optionDefectKindSRCheckFull As ComboBox
    Friend WithEvents Label321 As Label
    Friend WithEvents optionPtIdSRCheckFull As TextBox
    Friend WithEvents Label322 As Label
    Friend WithEvents optionFailedSRCheckFull As TextBox
    Friend WithEvents Label323 As Label
    Friend WithEvents optionPassedSRCheckFull As TextBox
    Friend WithEvents optionPtStateSRCheckFull As ComboBox
    Friend WithEvents Label324 As Label
    Friend WithEvents optionVersionSRCheckFull As ComboBox
    Friend WithEvents Label325 As Label
    Friend WithEvents TabPage51 As TabPage
    Friend WithEvents optionDefectStateSRCheckRegression As ComboBox
    Friend WithEvents Label326 As Label
    Friend WithEvents Label327 As Label
    Friend WithEvents optionDefectIdSRCheckRegression As TextBox
    Friend WithEvents Label328 As Label
    Friend WithEvents optionDefectKindSRCheckRegression As ComboBox
    Friend WithEvents Label329 As Label
    Friend WithEvents optionPtIdSRCheckRegression As TextBox
    Friend WithEvents Label330 As Label
    Friend WithEvents optionFailedSRCheckRegression As TextBox
    Friend WithEvents Label331 As Label
    Friend WithEvents optionPassedSRCheckRegression As TextBox
    Friend WithEvents optionPtStateSRCheckRegression As ComboBox
    Friend WithEvents Label332 As Label
    Friend WithEvents optionVersionSRCheckRegression As ComboBox
    Friend WithEvents Label333 As Label
    Friend WithEvents TabPage52 As TabPage
    Friend WithEvents optionDefectStateSRCheckDelta As ComboBox
    Friend WithEvents Label334 As Label
    Friend WithEvents Label335 As Label
    Friend WithEvents optionDefectIdSRCheckDelta As TextBox
    Friend WithEvents Label336 As Label
    Friend WithEvents optionDefectKindSRCheckDelta As ComboBox
    Friend WithEvents Label337 As Label
    Friend WithEvents optionPtIdSRCheckDelta As TextBox
    Friend WithEvents Label338 As Label
    Friend WithEvents optionFailedSRCheckDelta As TextBox
    Friend WithEvents Label339 As Label
    Friend WithEvents optionPassedSRCheckDelta As TextBox
    Friend WithEvents optionPtStateSRCheckDelta As ComboBox
    Friend WithEvents Label340 As Label
    Friend WithEvents optionVersionSRCheckDelta As ComboBox
    Friend WithEvents Label341 As Label
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents CheckBox15 As CheckBox
    Friend WithEvents Panel17 As Panel
    Friend WithEvents CheckBox16 As CheckBox
    Friend WithEvents Panel18 As Panel
    Friend WithEvents CheckBox17 As CheckBox
    Friend WithEvents Panel19 As Panel
    Friend WithEvents CheckBox18 As CheckBox
    Friend WithEvents Panel20 As Panel
    Friend WithEvents CheckBox19 As CheckBox
    Friend WithEvents Panel21 As Panel
    Friend WithEvents CheckBox20 As CheckBox
    Friend WithEvents Panel22 As Panel
    Friend WithEvents CheckBox21 As CheckBox
    Friend WithEvents Panel23 As Panel
    Friend WithEvents CheckBox22 As CheckBox
    Friend WithEvents Panel24 As Panel
    Friend WithEvents CheckBox23 As CheckBox
    Friend WithEvents Panel25 As Panel
    Friend WithEvents CheckBox24 As CheckBox
    Friend WithEvents Panel26 As Panel
    Friend WithEvents CheckBox25 As CheckBox
    Friend WithEvents Panel27 As Panel
    Friend WithEvents CheckBox26 As CheckBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Panel28 As Panel
    Friend WithEvents optionDCOMDelta As CheckBox
    Friend WithEvents optionDCOMRegression As CheckBox
    Friend WithEvents optionDCOMFull As CheckBox
    Friend WithEvents Panel29 As Panel
    Friend WithEvents optionEMDelta As CheckBox
    Friend WithEvents optionEMRegression As CheckBox
    Friend WithEvents optionEMFull As CheckBox
    Friend WithEvents Panel30 As Panel
    Friend WithEvents optionCOMDelta As CheckBox
    Friend WithEvents optionCOMRegression As CheckBox
    Friend WithEvents optionCOMFull As CheckBox
    Friend WithEvents Panel31 As Panel
    Friend WithEvents optionLDWDelta As CheckBox
    Friend WithEvents optionLDWRegression As CheckBox
    Friend WithEvents optionLDWFull As CheckBox
    Friend WithEvents Panel32 As Panel
    Friend WithEvents optionLKSDelta As CheckBox
    Friend WithEvents optionLKSRegression As CheckBox
    Friend WithEvents optionLKSFull As CheckBox
    Friend WithEvents Panel33 As Panel
    Friend WithEvents optionRDPDelta As CheckBox
    Friend WithEvents optionRDPRegression As CheckBox
    Friend WithEvents optionRDPFull As CheckBox
    Friend WithEvents Panel34 As Panel
    Friend WithEvents optionELKDelta As CheckBox
    Friend WithEvents optionELKRegression As CheckBox
    Friend WithEvents optionELKFull As CheckBox
    Friend WithEvents Panel35 As Panel
    Friend WithEvents optionTJADelta As CheckBox
    Friend WithEvents optionTJARegression As CheckBox
    Friend WithEvents optionTJAFull As CheckBox
    Friend WithEvents Panel36 As Panel
    Friend WithEvents optionSLADelta As CheckBox
    Friend WithEvents optionSLARegression As CheckBox
    Friend WithEvents optionSLAFull As CheckBox
    Friend WithEvents Panel37 As Panel
    Friend WithEvents optionHMADelta As CheckBox
    Friend WithEvents optionHMARegression As CheckBox
    Friend WithEvents optionHMAFull As CheckBox
    Friend WithEvents Panel38 As Panel
    Friend WithEvents optionVehicleDelta As CheckBox
    Friend WithEvents optionVehicleRegression As CheckBox
    Friend WithEvents optionVehicleFull As CheckBox
    Friend WithEvents Panel39 As Panel
    Friend WithEvents optionSITDelta As CheckBox
    Friend WithEvents optionSITRegression As CheckBox
    Friend WithEvents optionSITFull As CheckBox
    Friend WithEvents Panel40 As Panel
    Friend WithEvents optionSRCheckDelta As CheckBox
    Friend WithEvents optionSRCheckRegression As CheckBox
    Friend WithEvents optionSRCheckFull As CheckBox
    Friend WithEvents TabPage21 As TabPage
    Friend WithEvents swProject As ComboBox
End Class
