﻿
Public Class TestReport

    Public Shared run As New run()
    Public Shared save As New save()
    Public Shared browse As New browse()
    Public Shared reset As New reset()
    Public Shared checkboxFunction As New checkboxFunction()
    Public Shared tabcontrolFunction As New tabcontrolFunction()
    Public Shared variableDeclaration As New variableDeclaration()
    Public Shared dbDeclaration As New dbDeclaration()
    Public Shared initialMainFormLoading As New initialMainFormLoading()
    Public Shared functionSelection As New functionSelection()
    Public Shared model_DBImport As New model_DBImport()
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Initial value will be loaded when open the tool app
        initialMainFormLoading.initialMainFormLoading()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Click this button to generate to test summary report
        run.runButton()
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Save the GUI information to the database
        save.saveGUIInformationButton()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' Browse the output folder location for the test summary report 
        browse.browseFolderButton()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles swDCOM.CheckedChanged
        ' Checkbox of DCOM
        checkboxFunction.checkboxBehavior(1)
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles swEM.CheckedChanged
        ' Checkbox of EM
        checkboxFunction.checkboxBehavior(2)
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles swCOM.CheckedChanged
        ' Checkbox of COM
        checkboxFunction.checkboxBehavior(3)
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles swLDW.CheckedChanged
        ' Checkbox of LDW
        checkboxFunction.checkboxBehavior(4)
    End Sub

    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles swLKS.CheckedChanged
        ' Checkbox of LKS
        checkboxFunction.checkboxBehavior(5)
    End Sub

    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles swRDP.CheckedChanged
        ' Checkbox of RDP
        checkboxFunction.checkboxBehavior(6)
    End Sub
    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs) Handles swELK.CheckedChanged
        ' Checkbox of ELK
        checkboxFunction.checkboxBehavior(7)
    End Sub
    Private Sub CheckBox8_CheckedChanged(sender As Object, e As EventArgs) Handles swTJA.CheckedChanged
        ' Checkbox of TJA
        checkboxFunction.checkboxBehavior(8)
    End Sub
    Private Sub CheckBox9_CheckedChanged(sender As Object, e As EventArgs) Handles swSLA.CheckedChanged
        ' Checkbox of SLA
        checkboxFunction.checkboxBehavior(9)
    End Sub
    Private Sub CheckBox10_CheckedChanged(sender As Object, e As EventArgs) Handles swHMA.CheckedChanged
        ' Checkbox of HMA
        checkboxFunction.checkboxBehavior(10)
    End Sub
    Private Sub CheckBox11_CheckedChanged(sender As Object, e As EventArgs) Handles swVehicle.CheckedChanged
        ' Checkbox of VEHICLE
        checkboxFunction.checkboxBehavior(11)
    End Sub
    Private Sub CheckBox12_CheckedChanged(sender As Object, e As EventArgs) Handles swSIT.CheckedChanged
        ' Checkbox of SIT
        checkboxFunction.checkboxBehavior(12)
    End Sub
    Private Sub CheckBox13_CheckedChanged(sender As Object, e As EventArgs) Handles swSRCheck.CheckedChanged
        ' Checkbox of SR Check
        checkboxFunction.checkboxBehavior(13)
    End Sub
    Public Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        ' Choose the DCOM information page
        functionSelection.dcomSelection()

    End Sub
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ' Choose the EM information page
        functionSelection.emSelection()
    End Sub
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        ' Choose the COM information page
        functionSelection.comSelection()
    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        ' Choose the LDW information page
        functionSelection.ldwSelection()
    End Sub
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        ' Choose the LKS information page
        functionSelection.lksSelection()
    End Sub
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        ' Choose the RDP information page
        functionSelection.rdpSelection()
    End Sub
    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        ' Choose the ELK information page
        functionSelection.elkSelection()
    End Sub
    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        ' Choose the TJA information page
        functionSelection.tjaSelection()
    End Sub
    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        ' Choose the SLA information page
        functionSelection.slaSelection()
    End Sub
    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        ' Choose the HMA information page
        functionSelection.hmaSelection()
    End Sub
    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        ' Choose the VEHICLE information page
        functionSelection.vehicleSelection()
    End Sub
    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        ' Choose the SIT information page
        functionSelection.sitSelection()
    End Sub
    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        ' Choose the SR CHECK information page
        functionSelection.srCheckSelection()
    End Sub
    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click


    End Sub

    Private Sub CheckBox14_CheckedChanged(sender As Object, e As EventArgs) Handles optionDCOMFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("dcomFull")
    End Sub
    Private Sub CheckBox27_CheckedChanged(sender As Object, e As EventArgs) Handles optionDCOMRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("dcomRegression")
    End Sub
    Private Sub CheckBox28_CheckedChanged(sender As Object, e As EventArgs) Handles optionDCOMDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("dcomDelta")
    End Sub
    Private Sub CheckBox31_CheckedChanged(sender As Object, e As EventArgs) Handles optionEMFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("emFull")
    End Sub
    Private Sub CheckBox30_CheckedChanged(sender As Object, e As EventArgs) Handles optionEMRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("emRegression")
    End Sub
    Private Sub CheckBox29_CheckedChanged(sender As Object, e As EventArgs) Handles optionEMDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("emDelta")
    End Sub
    Private Sub CheckBox34_CheckedChanged(sender As Object, e As EventArgs) Handles optionCOMFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("comFull")
    End Sub
    Private Sub CheckBox33_CheckedChanged(sender As Object, e As EventArgs) Handles optionCOMRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("comRegression")
    End Sub
    Private Sub CheckBox32_CheckedChanged(sender As Object, e As EventArgs) Handles optionCOMDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("comDelta")
    End Sub
    Private Sub CheckBox37_CheckedChanged(sender As Object, e As EventArgs) Handles optionLDWFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("ldwFull")
    End Sub
    Private Sub CheckBox36_CheckedChanged(sender As Object, e As EventArgs) Handles optionLDWRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("ldwRegression")
    End Sub
    Private Sub CheckBox35_CheckedChanged(sender As Object, e As EventArgs) Handles optionLDWDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("ldwDelta")
    End Sub
    Private Sub CheckBox40_CheckedChanged(sender As Object, e As EventArgs) Handles optionLKSFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("lksFull")
    End Sub
    Private Sub CheckBox39_CheckedChanged(sender As Object, e As EventArgs) Handles optionLKSRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("lksRegression")
    End Sub
    Private Sub CheckBox38_CheckedChanged(sender As Object, e As EventArgs) Handles optionLKSDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("lksDelta")
    End Sub
    Private Sub CheckBox43_CheckedChanged(sender As Object, e As EventArgs) Handles optionRDPFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("rdpFull")
    End Sub
    Private Sub CheckBox42_CheckedChanged(sender As Object, e As EventArgs) Handles optionRDPRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("rdpRegression")
    End Sub
    Private Sub CheckBox41_CheckedChanged(sender As Object, e As EventArgs) Handles optionRDPDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("rdpDelta")
    End Sub
    Private Sub CheckBox46_CheckedChanged(sender As Object, e As EventArgs) Handles optionELKFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("elkFull")
    End Sub
    Private Sub CheckBox45_CheckedChanged(sender As Object, e As EventArgs) Handles optionELKRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("elkRegression")
    End Sub
    Private Sub CheckBox44_CheckedChanged(sender As Object, e As EventArgs) Handles optionELKDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("elkDelta")
    End Sub
    Private Sub CheckBox49_CheckedChanged(sender As Object, e As EventArgs) Handles optionTJAFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("tjaFull")
    End Sub
    Private Sub CheckBox48_CheckedChanged(sender As Object, e As EventArgs) Handles optionTJARegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("tjaRegression")
    End Sub
    Private Sub CheckBox47_CheckedChanged(sender As Object, e As EventArgs) Handles optionTJADelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("tjaDelta")
    End Sub
    Private Sub CheckBox52_CheckedChanged(sender As Object, e As EventArgs) Handles optionSLAFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("slaFull")
    End Sub
    Private Sub CheckBox51_CheckedChanged(sender As Object, e As EventArgs) Handles optionSLARegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("slaRegression")
    End Sub
    Private Sub CheckBox50_CheckedChanged(sender As Object, e As EventArgs) Handles optionSLADelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("slaDelta")
    End Sub
    Private Sub CheckBox55_CheckedChanged(sender As Object, e As EventArgs) Handles optionHMAFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("hmaFull")
    End Sub
    Private Sub CheckBox54_CheckedChanged(sender As Object, e As EventArgs) Handles optionHMARegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("hmaRegression")
    End Sub
    Private Sub CheckBox53_CheckedChanged(sender As Object, e As EventArgs) Handles optionHMADelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("hmaDelta")
    End Sub
    Private Sub CheckBox58_CheckedChanged(sender As Object, e As EventArgs) Handles optionVehicleFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("vehicleFull")
    End Sub
    Private Sub CheckBox57_CheckedChanged(sender As Object, e As EventArgs) Handles optionVehicleRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("vehicleRegression")
    End Sub
    Private Sub CheckBox56_CheckedChanged(sender As Object, e As EventArgs) Handles optionVehicleDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("vehicleDelta")
    End Sub
    Private Sub CheckBox61_CheckedChanged(sender As Object, e As EventArgs) Handles optionSITFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("sitFull")
    End Sub
    Private Sub CheckBox60_CheckedChanged(sender As Object, e As EventArgs) Handles optionSITRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("sitRegression")
    End Sub
    Private Sub CheckBox59_CheckedChanged(sender As Object, e As EventArgs) Handles optionSITDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("sitDelta")
    End Sub
    Private Sub CheckBox64_CheckedChanged(sender As Object, e As EventArgs) Handles optionSRCheckFull.CheckedChanged
        tabcontrolFunction.childTabPageSelection("srCheckFull")
    End Sub
    Private Sub CheckBox63_CheckedChanged(sender As Object, e As EventArgs) Handles optionSRCheckRegression.CheckedChanged
        tabcontrolFunction.childTabPageSelection("srCheckRegression")
    End Sub
    Private Sub CheckBox62_CheckedChanged(sender As Object, e As EventArgs) Handles optionSRCheckDelta.CheckedChanged
        tabcontrolFunction.childTabPageSelection("srCheckDelta")
    End Sub

    Private Sub swProject_SelectedIndexChanged(sender As Object, e As EventArgs) Handles swProject.SelectedIndexChanged
        model_DBImport.model_ImportDataToGUI()
    End Sub
End Class

