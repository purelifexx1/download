﻿Imports Word = Microsoft.Office.Interop.Word
Imports Excel = Microsoft.Office.Interop.Excel
Public Class dbDeclaration
    Public Shared mswordApp As Object
    Public Shared doc As Word.Document
    Public Shared docTemplateLocation As String
    Public Shared docTemplateName As String
    Public Shared docTemplatePath As String
    Public Shared docOutputName As String
    Public Shared docOutputLocation As String
    Public Shared docOutputPath As String


    Public Shared dbLocation As String
    Public Shared dbName As String
    Public Shared dbPath As String
    Public Shared msexcelApp As Object
    Public Shared dbWB As Excel.Workbook
    Public Shared dbWS As Object

    Public Shared dbProject As Excel.Range
    Public Shared dbVariant As Excel.Range
    Public Shared dbRelease As Excel.Range
    Public Shared dbVersion As Excel.Range
    Public Shared dbLevelOfTesting As Excel.Range
    Public Shared dbDocumentOwner As Excel.Range
    Public Shared dbModifiedBy As Excel.Range
    Public Shared dbTestCoordinator As Excel.Range
    Public Shared dbDocumentVersion As Excel.Range
    Public Shared dbStartDate As Excel.Range
    Public Shared dbEndDate As Excel.Range
    Public Shared dbReleaseDate As Excel.Range
    Public Shared dbDelivery As Excel.Range
    Public Shared dbSource As Excel.Range
    Public Shared dbCoresi As Excel.Range
    Public Shared dbDCOM As Excel.Range
    Public Shared dbEM As Excel.Range
    Public Shared dbCOM As Excel.Range
    Public Shared dbLDW As Excel.Range
    Public Shared dbLKS As Excel.Range
    Public Shared dbRDP As Excel.Range
    Public Shared dbELK As Excel.Range
    Public Shared dbTJA As Excel.Range
    Public Shared dbSLA As Excel.Range
    Public Shared dbHMA As Excel.Range
    Public Shared dbVehicle As Excel.Range
    Public Shared dbSIT As Excel.Range
    Public Shared dbSRCheck As Excel.Range

    Public Shared dbDCOMFull As Excel.Range
    Public Shared dbDCOMRegression As Excel.Range
    Public Shared dbDCOMDelta As Excel.Range
    Public Shared dbEMFull As Excel.Range
    Public Shared dbEMRegression As Excel.Range
    Public Shared dbEMDelta As Excel.Range
    Public Shared dbCOMFull As Excel.Range
    Public Shared dbCOMRegression As Excel.Range
    Public Shared dbCOMDelta As Excel.Range
    Public Shared dbLDWFull As Excel.Range
    Public Shared dbLDWRegression As Excel.Range
    Public Shared dbLDWDelta As Excel.Range
    Public Shared dbLKSFull As Excel.Range
    Public Shared dbLKSRegression As Excel.Range
    Public Shared dbLKSDelta As Excel.Range
    Public Shared dbRDPFull As Excel.Range
    Public Shared dbRDPRegression As Excel.Range
    Public Shared dbRDPDelta As Excel.Range
    Public Shared dbELKFull As Excel.Range
    Public Shared dbELKRegression As Excel.Range
    Public Shared dbELKDelta As Excel.Range
    Public Shared dbTJAFull As Excel.Range
    Public Shared dbTJARegression As Excel.Range
    Public Shared dbTJADelta As Excel.Range
    Public Shared dbSLAFull As Excel.Range
    Public Shared dbSLARegression As Excel.Range
    Public Shared dbSLADelta As Excel.Range
    Public Shared dbHMAFull As Excel.Range
    Public Shared dbHMARegression As Excel.Range
    Public Shared dbHMADelta As Excel.Range
    Public Shared dbVehicleFull As Excel.Range
    Public Shared dbVehicleRegression As Excel.Range
    Public Shared dbVehicleDelta As Excel.Range
    Public Shared dbSITFull As Excel.Range
    Public Shared dbSITRegression As Excel.Range
    Public Shared dbSITDelta As Excel.Range
    Public Shared dbSRCheckFull As Excel.Range
    Public Shared dbSRCheckRegression As Excel.Range
    Public Shared dbSRCheckDelta As Excel.Range


    Public Shared dbLabtDCOM As Excel.Range
    Public Shared dbLabtEM As Excel.Range
    Public Shared dbLabtCOM As Excel.Range
    Public Shared dbLabtLDW As Excel.Range
    Public Shared dbLabtLKS As Excel.Range
    Public Shared dbLabtRDP As Excel.Range
    Public Shared dbLabtELK As Excel.Range
    Public Shared dbLabtTJA As Excel.Range
    Public Shared dbLabtSLA As Excel.Range
    Public Shared dbLabtHMA As Excel.Range
    Public Shared dbLabtVehicle As Excel.Range
    Public Shared dbLabtSIT As Excel.Range
    Public Shared dbLabtSRCheck As Excel.Range
    Public Shared dbOutputReportLocation As Excel.Range

    Public Shared dbVersionDCOMFull As Excel.Range
    Public Shared dbPassedDCOMFull As Excel.Range
    Public Shared dbFailedDCOMFull As Excel.Range
    Public Shared dbPtIdDCOMFull As Excel.Range
    Public Shared dbPtStateDCOMFull As Excel.Range
    Public Shared dbDefectIdDCOMFull As Excel.Range
    Public Shared dbDefectStateDCOMFull As Excel.Range
    Public Shared dbDefectKindDCOMFull As Excel.Range
    Public Shared dbVersionDCOMRegression As Excel.Range
    Public Shared dbPassedDCOMRegression As Excel.Range
    Public Shared dbFailedDCOMRegression As Excel.Range
    Public Shared dbPtIdDCOMRegression As Excel.Range
    Public Shared dbPtStateDCOMRegression As Excel.Range
    Public Shared dbDefectIdDCOMRegression As Excel.Range
    Public Shared dbDefectStateDCOMRegression As Excel.Range
    Public Shared dbDefectKindDCOMRegression As Excel.Range
    Public Shared dbVersionDCOMDelta As Excel.Range
    Public Shared dbPassedDCOMDelta As Excel.Range
    Public Shared dbFailedDCOMDelta As Excel.Range
    Public Shared dbPtIdDCOMDelta As Excel.Range
    Public Shared dbPtStateDCOMDelta As Excel.Range
    Public Shared dbDefectIdDCOMDelta As Excel.Range
    Public Shared dbDefectStateDCOMDelta As Excel.Range
    Public Shared dbDefectKindDCOMDelta As Excel.Range
    Public Shared dbVersionEMFull As Excel.Range
    Public Shared dbPassedEMFull As Excel.Range
    Public Shared dbFailedEMFull As Excel.Range
    Public Shared dbPtIdEMFull As Excel.Range
    Public Shared dbPtStateEMFull As Excel.Range
    Public Shared dbDefectIdEMFull As Excel.Range
    Public Shared dbDefectStateEMFull As Excel.Range
    Public Shared dbDefectKindEMFull As Excel.Range
    Public Shared dbVersionEMRegression As Excel.Range
    Public Shared dbPassedEMRegression As Excel.Range
    Public Shared dbFailedEMRegression As Excel.Range
    Public Shared dbPtIdEMRegression As Excel.Range
    Public Shared dbPtStateEMRegression As Excel.Range
    Public Shared dbDefectIdEMRegression As Excel.Range
    Public Shared dbDefectStateEMRegression As Excel.Range
    Public Shared dbDefectKindEMRegression As Excel.Range
    Public Shared dbVersionEMDelta As Excel.Range
    Public Shared dbPassedEMDelta As Excel.Range
    Public Shared dbFailedEMDelta As Excel.Range
    Public Shared dbPtIdEMDelta As Excel.Range
    Public Shared dbPtStateEMDelta As Excel.Range
    Public Shared dbDefectIdEMDelta As Excel.Range
    Public Shared dbDefectStateEMDelta As Excel.Range
    Public Shared dbDefectKindEMDelta As Excel.Range
    Public Shared dbVersionCOMFull As Excel.Range
    Public Shared dbPassedCOMFull As Excel.Range
    Public Shared dbFailedCOMFull As Excel.Range
    Public Shared dbPtIdCOMFull As Excel.Range
    Public Shared dbPtStateCOMFull As Excel.Range
    Public Shared dbDefectIdCOMFull As Excel.Range
    Public Shared dbDefectStateCOMFull As Excel.Range
    Public Shared dbDefectKindCOMFull As Excel.Range
    Public Shared dbVersionCOMRegression As Excel.Range
    Public Shared dbPassedCOMRegression As Excel.Range
    Public Shared dbFailedCOMRegression As Excel.Range
    Public Shared dbPtIdCOMRegression As Excel.Range
    Public Shared dbPtStateCOMRegression As Excel.Range
    Public Shared dbDefectIdCOMRegression As Excel.Range
    Public Shared dbDefectStateCOMRegression As Excel.Range
    Public Shared dbDefectKindCOMRegression As Excel.Range
    Public Shared dbVersionCOMDelta As Excel.Range
    Public Shared dbPassedCOMDelta As Excel.Range
    Public Shared dbFailedCOMDelta As Excel.Range
    Public Shared dbPtIdCOMDelta As Excel.Range
    Public Shared dbPtStateCOMDelta As Excel.Range
    Public Shared dbDefectIdCOMDelta As Excel.Range
    Public Shared dbDefectStateCOMDelta As Excel.Range
    Public Shared dbDefectKindCOMDelta As Excel.Range
    Public Shared dbVersionLDWFull As Excel.Range
    Public Shared dbPassedLDWFull As Excel.Range
    Public Shared dbFailedLDWFull As Excel.Range
    Public Shared dbPtIdLDWFull As Excel.Range
    Public Shared dbPtStateLDWFull As Excel.Range
    Public Shared dbDefectIdLDWFull As Excel.Range
    Public Shared dbDefectStateLDWFull As Excel.Range
    Public Shared dbDefectKindLDWFull As Excel.Range
    Public Shared dbVersionLDWRegression As Excel.Range
    Public Shared dbPassedLDWRegression As Excel.Range
    Public Shared dbFailedLDWRegression As Excel.Range
    Public Shared dbPtIdLDWRegression As Excel.Range
    Public Shared dbPtStateLDWRegression As Excel.Range
    Public Shared dbDefectIdLDWRegression As Excel.Range
    Public Shared dbDefectStateLDWRegression As Excel.Range
    Public Shared dbDefectKindLDWRegression As Excel.Range
    Public Shared dbVersionLDWDelta As Excel.Range
    Public Shared dbPassedLDWDelta As Excel.Range
    Public Shared dbFailedLDWDelta As Excel.Range
    Public Shared dbPtIdLDWDelta As Excel.Range
    Public Shared dbPtStateLDWDelta As Excel.Range
    Public Shared dbDefectIdLDWDelta As Excel.Range
    Public Shared dbDefectStateLDWDelta As Excel.Range
    Public Shared dbDefectKindLDWDelta As Excel.Range
    Public Shared dbVersionLKSFull As Excel.Range
    Public Shared dbPassedLKSFull As Excel.Range
    Public Shared dbFailedLKSFull As Excel.Range
    Public Shared dbPtIdLKSFull As Excel.Range
    Public Shared dbPtStateLKSFull As Excel.Range
    Public Shared dbDefectIdLKSFull As Excel.Range
    Public Shared dbDefectStateLKSFull As Excel.Range
    Public Shared dbDefectKindLKSFull As Excel.Range
    Public Shared dbVersionLKSRegression As Excel.Range
    Public Shared dbPassedLKSRegression As Excel.Range
    Public Shared dbFailedLKSRegression As Excel.Range
    Public Shared dbPtIdLKSRegression As Excel.Range
    Public Shared dbPtStateLKSRegression As Excel.Range
    Public Shared dbDefectIdLKSRegression As Excel.Range
    Public Shared dbDefectStateLKSRegression As Excel.Range
    Public Shared dbDefectKindLKSRegression As Excel.Range
    Public Shared dbVersionLKSDelta As Excel.Range
    Public Shared dbPassedLKSDelta As Excel.Range
    Public Shared dbFailedLKSDelta As Excel.Range
    Public Shared dbPtIdLKSDelta As Excel.Range
    Public Shared dbPtStateLKSDelta As Excel.Range
    Public Shared dbDefectIdLKSDelta As Excel.Range
    Public Shared dbDefectStateLKSDelta As Excel.Range
    Public Shared dbDefectKindLKSDelta As Excel.Range
    Public Shared dbVersionRDPFull As Excel.Range
    Public Shared dbPassedRDPFull As Excel.Range
    Public Shared dbFailedRDPFull As Excel.Range
    Public Shared dbPtIdRDPFull As Excel.Range
    Public Shared dbPtStateRDPFull As Excel.Range
    Public Shared dbDefectIdRDPFull As Excel.Range
    Public Shared dbDefectStateRDPFull As Excel.Range
    Public Shared dbDefectKindRDPFull As Excel.Range
    Public Shared dbVersionRDPRegression As Excel.Range
    Public Shared dbPassedRDPRegression As Excel.Range
    Public Shared dbFailedRDPRegression As Excel.Range
    Public Shared dbPtIdRDPRegression As Excel.Range
    Public Shared dbPtStateRDPRegression As Excel.Range
    Public Shared dbDefectIdRDPRegression As Excel.Range
    Public Shared dbDefectStateRDPRegression As Excel.Range
    Public Shared dbDefectKindRDPRegression As Excel.Range
    Public Shared dbVersionRDPDelta As Excel.Range
    Public Shared dbPassedRDPDelta As Excel.Range
    Public Shared dbFailedRDPDelta As Excel.Range
    Public Shared dbPtIdRDPDelta As Excel.Range
    Public Shared dbPtStateRDPDelta As Excel.Range
    Public Shared dbDefectIdRDPDelta As Excel.Range
    Public Shared dbDefectStateRDPDelta As Excel.Range
    Public Shared dbDefectKindRDPDelta As Excel.Range
    Public Shared dbVersionELKFull As Excel.Range
    Public Shared dbPassedELKFull As Excel.Range
    Public Shared dbFailedELKFull As Excel.Range
    Public Shared dbPtIdELKFull As Excel.Range
    Public Shared dbPtStateELKFull As Excel.Range
    Public Shared dbDefectIdELKFull As Excel.Range
    Public Shared dbDefectStateELKFull As Excel.Range
    Public Shared dbDefectKindELKFull As Excel.Range
    Public Shared dbVersionELKRegression As Excel.Range
    Public Shared dbPassedELKRegression As Excel.Range
    Public Shared dbFailedELKRegression As Excel.Range
    Public Shared dbPtIdELKRegression As Excel.Range
    Public Shared dbPtStateELKRegression As Excel.Range
    Public Shared dbDefectIdELKRegression As Excel.Range
    Public Shared dbDefectStateELKRegression As Excel.Range
    Public Shared dbDefectKindELKRegression As Excel.Range
    Public Shared dbVersionELKDelta As Excel.Range
    Public Shared dbPassedELKDelta As Excel.Range
    Public Shared dbFailedELKDelta As Excel.Range
    Public Shared dbPtIdELKDelta As Excel.Range
    Public Shared dbPtStateELKDelta As Excel.Range
    Public Shared dbDefectIdELKDelta As Excel.Range
    Public Shared dbDefectStateELKDelta As Excel.Range
    Public Shared dbDefectKindELKDelta As Excel.Range
    Public Shared dbVersionTJAFull As Excel.Range
    Public Shared dbPassedTJAFull As Excel.Range
    Public Shared dbFailedTJAFull As Excel.Range
    Public Shared dbPtIdTJAFull As Excel.Range
    Public Shared dbPtStateTJAFull As Excel.Range
    Public Shared dbDefectIdTJAFull As Excel.Range
    Public Shared dbDefectStateTJAFull As Excel.Range
    Public Shared dbDefectKindTJAFull As Excel.Range
    Public Shared dbVersionTJARegression As Excel.Range
    Public Shared dbPassedTJARegression As Excel.Range
    Public Shared dbFailedTJARegression As Excel.Range
    Public Shared dbPtIdTJARegression As Excel.Range
    Public Shared dbPtStateTJARegression As Excel.Range
    Public Shared dbDefectIdTJARegression As Excel.Range
    Public Shared dbDefectStateTJARegression As Excel.Range
    Public Shared dbDefectKindTJARegression As Excel.Range
    Public Shared dbVersionTJADelta As Excel.Range
    Public Shared dbPassedTJADelta As Excel.Range
    Public Shared dbFailedTJADelta As Excel.Range
    Public Shared dbPtIdTJADelta As Excel.Range
    Public Shared dbPtStateTJADelta As Excel.Range
    Public Shared dbDefectIdTJADelta As Excel.Range
    Public Shared dbDefectStateTJADelta As Excel.Range
    Public Shared dbDefectKindTJADelta As Excel.Range
    Public Shared dbVersionSLAFull As Excel.Range
    Public Shared dbPassedSLAFull As Excel.Range
    Public Shared dbFailedSLAFull As Excel.Range
    Public Shared dbPtIdSLAFull As Excel.Range
    Public Shared dbPtStateSLAFull As Excel.Range
    Public Shared dbDefectIdSLAFull As Excel.Range
    Public Shared dbDefectStateSLAFull As Excel.Range
    Public Shared dbDefectKindSLAFull As Excel.Range
    Public Shared dbVersionSLARegression As Excel.Range
    Public Shared dbPassedSLARegression As Excel.Range
    Public Shared dbFailedSLARegression As Excel.Range
    Public Shared dbPtIdSLARegression As Excel.Range
    Public Shared dbPtStateSLARegression As Excel.Range
    Public Shared dbDefectIdSLARegression As Excel.Range
    Public Shared dbDefectStateSLARegression As Excel.Range
    Public Shared dbDefectKindSLARegression As Excel.Range
    Public Shared dbVersionSLADelta As Excel.Range
    Public Shared dbPassedSLADelta As Excel.Range
    Public Shared dbFailedSLADelta As Excel.Range
    Public Shared dbPtIdSLADelta As Excel.Range
    Public Shared dbPtStateSLADelta As Excel.Range
    Public Shared dbDefectIdSLADelta As Excel.Range
    Public Shared dbDefectStateSLADelta As Excel.Range
    Public Shared dbDefectKindSLADelta As Excel.Range
    Public Shared dbVersionHMAFull As Excel.Range
    Public Shared dbPassedHMAFull As Excel.Range
    Public Shared dbFailedHMAFull As Excel.Range
    Public Shared dbPtIdHMAFull As Excel.Range
    Public Shared dbPtStateHMAFull As Excel.Range
    Public Shared dbDefectIdHMAFull As Excel.Range
    Public Shared dbDefectStateHMAFull As Excel.Range
    Public Shared dbDefectKindHMAFull As Excel.Range
    Public Shared dbVersionHMARegression As Excel.Range
    Public Shared dbPassedHMARegression As Excel.Range
    Public Shared dbFailedHMARegression As Excel.Range
    Public Shared dbPtIdHMARegression As Excel.Range
    Public Shared dbPtStateHMARegression As Excel.Range
    Public Shared dbDefectIdHMARegression As Excel.Range
    Public Shared dbDefectStateHMARegression As Excel.Range
    Public Shared dbDefectKindHMARegression As Excel.Range
    Public Shared dbVersionHMADelta As Excel.Range
    Public Shared dbPassedHMADelta As Excel.Range
    Public Shared dbFailedHMADelta As Excel.Range
    Public Shared dbPtIdHMADelta As Excel.Range
    Public Shared dbPtStateHMADelta As Excel.Range
    Public Shared dbDefectIdHMADelta As Excel.Range
    Public Shared dbDefectStateHMADelta As Excel.Range
    Public Shared dbDefectKindHMADelta As Excel.Range
    Public Shared dbVersionVehicleFull As Excel.Range
    Public Shared dbPassedVehicleFull As Excel.Range
    Public Shared dbFailedVehicleFull As Excel.Range
    Public Shared dbPtIdVehicleFull As Excel.Range
    Public Shared dbPtStateVehicleFull As Excel.Range
    Public Shared dbDefectIdVehicleFull As Excel.Range
    Public Shared dbDefectStateVehicleFull As Excel.Range
    Public Shared dbDefectKindVehicleFull As Excel.Range
    Public Shared dbVersionVehicleRegression As Excel.Range
    Public Shared dbPassedVehicleRegression As Excel.Range
    Public Shared dbFailedVehicleRegression As Excel.Range
    Public Shared dbPtIdVehicleRegression As Excel.Range
    Public Shared dbPtStateVehicleRegression As Excel.Range
    Public Shared dbDefectIdVehicleRegression As Excel.Range
    Public Shared dbDefectStateVehicleRegression As Excel.Range
    Public Shared dbDefectKindVehicleRegression As Excel.Range
    Public Shared dbVersionVehicleDelta As Excel.Range
    Public Shared dbPassedVehicleDelta As Excel.Range
    Public Shared dbFailedVehicleDelta As Excel.Range
    Public Shared dbPtIdVehicleDelta As Excel.Range
    Public Shared dbPtStateVehicleDelta As Excel.Range
    Public Shared dbDefectIdVehicleDelta As Excel.Range
    Public Shared dbDefectStateVehicleDelta As Excel.Range
    Public Shared dbDefectKindVehicleDelta As Excel.Range
    Public Shared dbVersionSITFull As Excel.Range
    Public Shared dbPassedSITFull As Excel.Range
    Public Shared dbFailedSITFull As Excel.Range
    Public Shared dbPtIdSITFull As Excel.Range
    Public Shared dbPtStateSITFull As Excel.Range
    Public Shared dbDefectIdSITFull As Excel.Range
    Public Shared dbDefectStateSITFull As Excel.Range
    Public Shared dbDefectKindSITFull As Excel.Range
    Public Shared dbVersionSITRegression As Excel.Range
    Public Shared dbPassedSITRegression As Excel.Range
    Public Shared dbFailedSITRegression As Excel.Range
    Public Shared dbPtIdSITRegression As Excel.Range
    Public Shared dbPtStateSITRegression As Excel.Range
    Public Shared dbDefectIdSITRegression As Excel.Range
    Public Shared dbDefectStateSITRegression As Excel.Range
    Public Shared dbDefectKindSITRegression As Excel.Range
    Public Shared dbVersionSITDelta As Excel.Range
    Public Shared dbPassedSITDelta As Excel.Range
    Public Shared dbFailedSITDelta As Excel.Range
    Public Shared dbPtIdSITDelta As Excel.Range
    Public Shared dbPtStateSITDelta As Excel.Range
    Public Shared dbDefectIdSITDelta As Excel.Range
    Public Shared dbDefectStateSITDelta As Excel.Range
    Public Shared dbDefectKindSITDelta As Excel.Range
    Public Shared dbVersionSRCheckFull As Excel.Range
    Public Shared dbPassedSRCheckFull As Excel.Range
    Public Shared dbFailedSRCheckFull As Excel.Range
    Public Shared dbPtIdSRCheckFull As Excel.Range
    Public Shared dbPtStateSRCheckFull As Excel.Range
    Public Shared dbDefectIdSRCheckFull As Excel.Range
    Public Shared dbDefectStateSRCheckFull As Excel.Range
    Public Shared dbDefectKindSRCheckFull As Excel.Range
    Public Shared dbVersionSRCheckRegression As Excel.Range
    Public Shared dbPassedSRCheckRegression As Excel.Range
    Public Shared dbFailedSRCheckRegression As Excel.Range
    Public Shared dbPtIdSRCheckRegression As Excel.Range
    Public Shared dbPtStateSRCheckRegression As Excel.Range
    Public Shared dbDefectIdSRCheckRegression As Excel.Range
    Public Shared dbDefectStateSRCheckRegression As Excel.Range
    Public Shared dbDefectKindSRCheckRegression As Excel.Range
    Public Shared dbVersionSRCheckDelta As Excel.Range
    Public Shared dbPassedSRCheckDelta As Excel.Range
    Public Shared dbFailedSRCheckDelta As Excel.Range
    Public Shared dbPtIdSRCheckDelta As Excel.Range
    Public Shared dbPtStateSRCheckDelta As Excel.Range
    Public Shared dbDefectIdSRCheckDelta As Excel.Range
    Public Shared dbDefectStateSRCheckDelta As Excel.Range
    Public Shared dbDefectKindSRCheckDelta As Excel.Range
    Public Shared variableDelaration As New variableDeclaration()

    Public Sub dbDeclaration()

        ' Open Microsoft office excel 
        msexcelApp = New Excel.Application
        dbLocation = "C:\Users\nuc81hc\Documents\Visual Studio 2015\Projects\testReport\testReport\db"
        dbName = "db.xlsx"
        dbPath = dbLocation & "\" & dbName
        dbWB = msexcelApp.Workbooks.Add(dbPath)
        selectDB()
        dbWS = dbWB.Sheets(TestReport.swProject.Text)
        msexcelApp.EditDirectlyInCell = True



        ' Open Microsoft office word
        mswordApp = New Word.Application
        docTemplateLocation = "C:\Users\nuc81hc\Documents\Visual Studio 2015\Projects\testReport\testReport\db"
        docTemplateName = "testReportTemplate.doc"
        docTemplatePath = docTemplateLocation & "\" & docTemplateName
        doc = mswordApp.Documents.Add(docTemplatePath)


        ' Create output MSWord document

        docOutputLocation = TestReport.ouputReportLocation.Text & "\"
        docOutputName = variableDeclaration.project & "_" & variableDeclaration.swVariant & "_" & variableDeclaration.release & "_" & variableDeclaration.version & "_test_summary_report.doc"
        docOutputPath = docOutputLocation & docOutputName


        ' Define cells value for the Database 
        With dbWS
            dbProject = CType(.Cells(variableDeclaration.rowProject, variableDeclaration.colProject), Excel.Range)
            dbVariant = CType(.Cells(variableDeclaration.rowVariant, variableDeclaration.colVariant), Excel.Range)
            dbRelease = CType(.Cells(variableDeclaration.rowRelease, variableDeclaration.colRelease), Excel.Range)
            dbVersion = CType(.Cells(variableDeclaration.rowVersion, variableDeclaration.colVersion), Excel.Range)
            dbLevelOfTesting = CType(.Cells(variableDeclaration.rowLevelOfTesting, variableDeclaration.colLevelOfTesting), Excel.Range)
            dbDocumentOwner = CType(.Cells(variableDeclaration.rowDocumentOwner, variableDeclaration.colDocumentOwner), Excel.Range)
            dbModifiedBy = CType(.Cells(variableDeclaration.rowModifiedBy, variableDeclaration.colModifiedBy), Excel.Range)
            dbTestCoordinator = CType(.Cells(variableDeclaration.rowTestCoordinator, variableDeclaration.colTestCoordinator), Excel.Range)
            dbDocumentVersion = CType(.Cells(variableDeclaration.rowDocumentVersion, variableDeclaration.colDocumentVersion), Excel.Range)
            dbStartDate = CType(.Cells(variableDeclaration.rowStartDate, variableDeclaration.colStartDate), Excel.Range)
            dbEndDate = CType(.Cells(variableDeclaration.rowEndDate, variableDeclaration.colEndDate), Excel.Range)
            dbReleaseDate = CType(.Cells(variableDeclaration.rowReleaseDate, variableDeclaration.colReleaseDate), Excel.Range)
            dbDelivery = CType(.Cells(variableDeclaration.rowDelivery, variableDeclaration.colDelivery), Excel.Range)
            dbSource = CType(.Cells(variableDeclaration.rowSource, variableDeclaration.colSource), Excel.Range)
            dbCoresi = CType(.Cells(variableDeclaration.rowCoresi, variableDeclaration.colCoresi), Excel.Range)

            dbDCOM = CType(.Cells(variableDeclaration.rowDCOM, variableDeclaration.colDCOM), Excel.Range)
            dbEM = CType(.Cells(variableDeclaration.rowEM, variableDeclaration.colEM), Excel.Range)
            dbCOM = CType(.Cells(variableDeclaration.rowCOM, variableDeclaration.colCOM), Excel.Range)
            dbLDW = CType(.Cells(variableDeclaration.rowLDW, variableDeclaration.colLDW), Excel.Range)
            dbLKS = CType(.Cells(variableDeclaration.rowLKS, variableDeclaration.colLKS), Excel.Range)
            dbRDP = CType(.Cells(variableDeclaration.rowRDP, variableDeclaration.colRDP), Excel.Range)
            dbELK = CType(.Cells(variableDeclaration.rowELK, variableDeclaration.colELK), Excel.Range)
            dbTJA = CType(.Cells(variableDeclaration.rowTJA, variableDeclaration.colTJA), Excel.Range)
            dbSLA = CType(.Cells(variableDeclaration.rowSLA, variableDeclaration.colSLA), Excel.Range)
            dbHMA = CType(.Cells(variableDeclaration.rowHMA, variableDeclaration.colHMA), Excel.Range)
            dbVehicle = CType(.Cells(variableDeclaration.rowVehicle, variableDeclaration.colVehicle), Excel.Range)
            dbSIT = CType(.Cells(variableDeclaration.rowSIT, variableDeclaration.colSIT), Excel.Range)
            dbSRCheck = CType(.Cells(variableDeclaration.rowSRCheck, variableDeclaration.colSRCheck), Excel.Range)

            dbDCOMFull = CType(.Cells(variableDeclaration.rowDCOM, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbDCOMRegression = CType(.Cells(variableDeclaration.rowDCOM, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbDCOMDelta = CType(.Cells(variableDeclaration.rowDCOM, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbEMFull = CType(.Cells(variableDeclaration.rowEM, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbEMRegression = CType(.Cells(variableDeclaration.rowEM, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbEMDelta = CType(.Cells(variableDeclaration.rowEM, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbCOMFull = CType(.Cells(variableDeclaration.rowCOM, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbCOMRegression = CType(.Cells(variableDeclaration.rowCOM, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbCOMDelta = CType(.Cells(variableDeclaration.rowCOM, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbLDWFull = CType(.Cells(variableDeclaration.rowLDW, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbLDWRegression = CType(.Cells(variableDeclaration.rowLDW, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbLDWDelta = CType(.Cells(variableDeclaration.rowLDW, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbLKSFull = CType(.Cells(variableDeclaration.rowLKS, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbLKSRegression = CType(.Cells(variableDeclaration.rowLKS, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbLKSDelta = CType(.Cells(variableDeclaration.rowLKS, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbRDPFull = CType(.Cells(variableDeclaration.rowRDP, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbRDPRegression = CType(.Cells(variableDeclaration.rowRDP, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbRDPDelta = CType(.Cells(variableDeclaration.rowRDP, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbELKFull = CType(.Cells(variableDeclaration.rowELK, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbELKRegression = CType(.Cells(variableDeclaration.rowELK, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbELKDelta = CType(.Cells(variableDeclaration.rowELK, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbTJAFull = CType(.Cells(variableDeclaration.rowTJA, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbTJARegression = CType(.Cells(variableDeclaration.rowTJA, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbTJADelta = CType(.Cells(variableDeclaration.rowTJA, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbSLAFull = CType(.Cells(variableDeclaration.rowSLA, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbSLARegression = CType(.Cells(variableDeclaration.rowSLA, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbSLADelta = CType(.Cells(variableDeclaration.rowSLA, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbHMAFull = CType(.Cells(variableDeclaration.rowHMA, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbHMARegression = CType(.Cells(variableDeclaration.rowHMA, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbHMADelta = CType(.Cells(variableDeclaration.rowHMA, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbVehicleFull = CType(.Cells(variableDeclaration.rowVehicle, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbVehicleRegression = CType(.Cells(variableDeclaration.rowVehicle, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbVehicleDelta = CType(.Cells(variableDeclaration.rowVehicle, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbSITFull = CType(.Cells(variableDeclaration.rowSIT, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbSITRegression = CType(.Cells(variableDeclaration.rowSIT, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbSITDelta = CType(.Cells(variableDeclaration.rowSIT, variableDeclaration.colAllTestPartDelta), Excel.Range)
            dbSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheck, variableDeclaration.colAllTestPartFull), Excel.Range)
            dbSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheck, variableDeclaration.colAllTestPartRegression), Excel.Range)
            dbSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheck, variableDeclaration.colAllTestPartDelta), Excel.Range)

            dbLabtDCOM = CType(.Cells(variableDeclaration.rowDCOM, variableDeclaration.colLabtDCOM), Excel.Range)
            dbLabtEM = CType(.Cells(variableDeclaration.rowEM, variableDeclaration.colLabtEM), Excel.Range)
            dbLabtCOM = CType(.Cells(variableDeclaration.rowCOM, variableDeclaration.colLabtCOM), Excel.Range)
            dbLabtLDW = CType(.Cells(variableDeclaration.rowLDW, variableDeclaration.colLabtLDW), Excel.Range)
            dbLabtLKS = CType(.Cells(variableDeclaration.rowLKS, variableDeclaration.colLabtLKS), Excel.Range)
            dbLabtRDP = CType(.Cells(variableDeclaration.rowRDP, variableDeclaration.colLabtRDP), Excel.Range)
            dbLabtELK = CType(.Cells(variableDeclaration.rowELK, variableDeclaration.colLabtELK), Excel.Range)
            dbLabtTJA = CType(.Cells(variableDeclaration.rowTJA, variableDeclaration.colLabtTJA), Excel.Range)
            dbLabtSLA = CType(.Cells(variableDeclaration.rowSLA, variableDeclaration.colLabtSLA), Excel.Range)
            dbLabtHMA = CType(.Cells(variableDeclaration.rowHMA, variableDeclaration.colLabtHMA), Excel.Range)
            dbLabtVehicle = CType(.Cells(variableDeclaration.rowVehicle, variableDeclaration.colLabtVehicle), Excel.Range)
            dbLabtSIT = CType(.Cells(variableDeclaration.rowSIT, variableDeclaration.colLabtSIT), Excel.Range)
            dbLabtSRCheck = CType(.Cells(variableDeclaration.rowSRCheck, variableDeclaration.colLabtSRCheck), Excel.Range)

            dbOutputReportLocation = CType(.Cells(variableDeclaration.rowOutputReportLocation, variableDeclaration.colOutputReportLocation), Excel.Range)

            dbVersionDCOMFull = CType(.Cells(variableDeclaration.rowDCOMFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedDCOMFull = CType(.Cells(variableDeclaration.rowDCOMFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedDCOMFull = CType(.Cells(variableDeclaration.rowDCOMFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdDCOMFull = CType(.Cells(variableDeclaration.rowDCOMFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateDCOMFull = CType(.Cells(variableDeclaration.rowDCOMFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdDCOMFull = CType(.Cells(variableDeclaration.rowDCOMFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateDCOMFull = CType(.Cells(variableDeclaration.rowDCOMFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindDCOMFull = CType(.Cells(variableDeclaration.rowDCOMFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionDCOMRegression = CType(.Cells(variableDeclaration.rowDCOMRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedDCOMRegression = CType(.Cells(variableDeclaration.rowDCOMRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedDCOMRegression = CType(.Cells(variableDeclaration.rowDCOMRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdDCOMRegression = CType(.Cells(variableDeclaration.rowDCOMRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateDCOMRegression = CType(.Cells(variableDeclaration.rowDCOMRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdDCOMRegression = CType(.Cells(variableDeclaration.rowDCOMRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateDCOMRegression = CType(.Cells(variableDeclaration.rowDCOMRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindDCOMRegression = CType(.Cells(variableDeclaration.rowDCOMRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionDCOMDelta = CType(.Cells(variableDeclaration.rowDCOMDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedDCOMDelta = CType(.Cells(variableDeclaration.rowDCOMDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedDCOMDelta = CType(.Cells(variableDeclaration.rowDCOMDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdDCOMDelta = CType(.Cells(variableDeclaration.rowDCOMDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateDCOMDelta = CType(.Cells(variableDeclaration.rowDCOMDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdDCOMDelta = CType(.Cells(variableDeclaration.rowDCOMDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateDCOMDelta = CType(.Cells(variableDeclaration.rowDCOMDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindDCOMDelta = CType(.Cells(variableDeclaration.rowDCOMDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionEMFull = CType(.Cells(variableDeclaration.rowEMFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedEMFull = CType(.Cells(variableDeclaration.rowEMFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedEMFull = CType(.Cells(variableDeclaration.rowEMFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdEMFull = CType(.Cells(variableDeclaration.rowEMFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateEMFull = CType(.Cells(variableDeclaration.rowEMFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdEMFull = CType(.Cells(variableDeclaration.rowEMFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateEMFull = CType(.Cells(variableDeclaration.rowEMFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindEMFull = CType(.Cells(variableDeclaration.rowEMFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionEMRegression = CType(.Cells(variableDeclaration.rowEMRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedEMRegression = CType(.Cells(variableDeclaration.rowEMRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedEMRegression = CType(.Cells(variableDeclaration.rowEMRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdEMRegression = CType(.Cells(variableDeclaration.rowEMRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateEMRegression = CType(.Cells(variableDeclaration.rowEMRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdEMRegression = CType(.Cells(variableDeclaration.rowEMRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateEMRegression = CType(.Cells(variableDeclaration.rowEMRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindEMRegression = CType(.Cells(variableDeclaration.rowEMRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionEMDelta = CType(.Cells(variableDeclaration.rowEMDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedEMDelta = CType(.Cells(variableDeclaration.rowEMDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedEMDelta = CType(.Cells(variableDeclaration.rowEMDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdEMDelta = CType(.Cells(variableDeclaration.rowEMDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateEMDelta = CType(.Cells(variableDeclaration.rowEMDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdEMDelta = CType(.Cells(variableDeclaration.rowEMDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateEMDelta = CType(.Cells(variableDeclaration.rowEMDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindEMDelta = CType(.Cells(variableDeclaration.rowEMDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionCOMFull = CType(.Cells(variableDeclaration.rowCOMFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedCOMFull = CType(.Cells(variableDeclaration.rowCOMFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedCOMFull = CType(.Cells(variableDeclaration.rowCOMFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdCOMFull = CType(.Cells(variableDeclaration.rowCOMFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateCOMFull = CType(.Cells(variableDeclaration.rowCOMFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdCOMFull = CType(.Cells(variableDeclaration.rowCOMFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateCOMFull = CType(.Cells(variableDeclaration.rowCOMFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindCOMFull = CType(.Cells(variableDeclaration.rowCOMFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionCOMRegression = CType(.Cells(variableDeclaration.rowCOMRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedCOMRegression = CType(.Cells(variableDeclaration.rowCOMRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedCOMRegression = CType(.Cells(variableDeclaration.rowCOMRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdCOMRegression = CType(.Cells(variableDeclaration.rowCOMRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateCOMRegression = CType(.Cells(variableDeclaration.rowCOMRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdCOMRegression = CType(.Cells(variableDeclaration.rowCOMRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateCOMRegression = CType(.Cells(variableDeclaration.rowCOMRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindCOMRegression = CType(.Cells(variableDeclaration.rowCOMRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionCOMDelta = CType(.Cells(variableDeclaration.rowCOMDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedCOMDelta = CType(.Cells(variableDeclaration.rowCOMDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedCOMDelta = CType(.Cells(variableDeclaration.rowCOMDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdCOMDelta = CType(.Cells(variableDeclaration.rowCOMDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateCOMDelta = CType(.Cells(variableDeclaration.rowCOMDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdCOMDelta = CType(.Cells(variableDeclaration.rowCOMDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateCOMDelta = CType(.Cells(variableDeclaration.rowCOMDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindCOMDelta = CType(.Cells(variableDeclaration.rowCOMDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionLDWFull = CType(.Cells(variableDeclaration.rowLDWFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedLDWFull = CType(.Cells(variableDeclaration.rowLDWFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedLDWFull = CType(.Cells(variableDeclaration.rowLDWFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdLDWFull = CType(.Cells(variableDeclaration.rowLDWFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateLDWFull = CType(.Cells(variableDeclaration.rowLDWFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdLDWFull = CType(.Cells(variableDeclaration.rowLDWFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateLDWFull = CType(.Cells(variableDeclaration.rowLDWFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindLDWFull = CType(.Cells(variableDeclaration.rowLDWFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionLDWRegression = CType(.Cells(variableDeclaration.rowLDWRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedLDWRegression = CType(.Cells(variableDeclaration.rowLDWRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedLDWRegression = CType(.Cells(variableDeclaration.rowLDWRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdLDWRegression = CType(.Cells(variableDeclaration.rowLDWRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateLDWRegression = CType(.Cells(variableDeclaration.rowLDWRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdLDWRegression = CType(.Cells(variableDeclaration.rowLDWRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateLDWRegression = CType(.Cells(variableDeclaration.rowLDWRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindLDWRegression = CType(.Cells(variableDeclaration.rowLDWRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionLDWDelta = CType(.Cells(variableDeclaration.rowLDWDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedLDWDelta = CType(.Cells(variableDeclaration.rowLDWDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedLDWDelta = CType(.Cells(variableDeclaration.rowLDWDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdLDWDelta = CType(.Cells(variableDeclaration.rowLDWDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateLDWDelta = CType(.Cells(variableDeclaration.rowLDWDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdLDWDelta = CType(.Cells(variableDeclaration.rowLDWDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateLDWDelta = CType(.Cells(variableDeclaration.rowLDWDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindLDWDelta = CType(.Cells(variableDeclaration.rowLDWDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionLKSFull = CType(.Cells(variableDeclaration.rowLKSFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedLKSFull = CType(.Cells(variableDeclaration.rowLKSFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedLKSFull = CType(.Cells(variableDeclaration.rowLKSFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdLKSFull = CType(.Cells(variableDeclaration.rowLKSFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateLKSFull = CType(.Cells(variableDeclaration.rowLKSFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdLKSFull = CType(.Cells(variableDeclaration.rowLKSFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateLKSFull = CType(.Cells(variableDeclaration.rowLKSFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindLKSFull = CType(.Cells(variableDeclaration.rowLKSFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionLKSRegression = CType(.Cells(variableDeclaration.rowLKSRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedLKSRegression = CType(.Cells(variableDeclaration.rowLKSRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedLKSRegression = CType(.Cells(variableDeclaration.rowLKSRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdLKSRegression = CType(.Cells(variableDeclaration.rowLKSRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateLKSRegression = CType(.Cells(variableDeclaration.rowLKSRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdLKSRegression = CType(.Cells(variableDeclaration.rowLKSRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateLKSRegression = CType(.Cells(variableDeclaration.rowLKSRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindLKSRegression = CType(.Cells(variableDeclaration.rowLKSRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionLKSDelta = CType(.Cells(variableDeclaration.rowLKSDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedLKSDelta = CType(.Cells(variableDeclaration.rowLKSDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedLKSDelta = CType(.Cells(variableDeclaration.rowLKSDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdLKSDelta = CType(.Cells(variableDeclaration.rowLKSDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateLKSDelta = CType(.Cells(variableDeclaration.rowLKSDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdLKSDelta = CType(.Cells(variableDeclaration.rowLKSDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateLKSDelta = CType(.Cells(variableDeclaration.rowLKSDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindLKSDelta = CType(.Cells(variableDeclaration.rowLKSDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionRDPFull = CType(.Cells(variableDeclaration.rowRDPFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedRDPFull = CType(.Cells(variableDeclaration.rowRDPFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedRDPFull = CType(.Cells(variableDeclaration.rowRDPFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdRDPFull = CType(.Cells(variableDeclaration.rowRDPFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateRDPFull = CType(.Cells(variableDeclaration.rowRDPFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdRDPFull = CType(.Cells(variableDeclaration.rowRDPFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateRDPFull = CType(.Cells(variableDeclaration.rowRDPFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindRDPFull = CType(.Cells(variableDeclaration.rowRDPFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionRDPRegression = CType(.Cells(variableDeclaration.rowRDPRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedRDPRegression = CType(.Cells(variableDeclaration.rowRDPRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedRDPRegression = CType(.Cells(variableDeclaration.rowRDPRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdRDPRegression = CType(.Cells(variableDeclaration.rowRDPRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateRDPRegression = CType(.Cells(variableDeclaration.rowRDPRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdRDPRegression = CType(.Cells(variableDeclaration.rowRDPRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateRDPRegression = CType(.Cells(variableDeclaration.rowRDPRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindRDPRegression = CType(.Cells(variableDeclaration.rowRDPRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionRDPDelta = CType(.Cells(variableDeclaration.rowRDPDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedRDPDelta = CType(.Cells(variableDeclaration.rowRDPDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedRDPDelta = CType(.Cells(variableDeclaration.rowRDPDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdRDPDelta = CType(.Cells(variableDeclaration.rowRDPDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateRDPDelta = CType(.Cells(variableDeclaration.rowRDPDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdRDPDelta = CType(.Cells(variableDeclaration.rowRDPDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateRDPDelta = CType(.Cells(variableDeclaration.rowRDPDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindRDPDelta = CType(.Cells(variableDeclaration.rowRDPDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionELKFull = CType(.Cells(variableDeclaration.rowELKFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedELKFull = CType(.Cells(variableDeclaration.rowELKFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedELKFull = CType(.Cells(variableDeclaration.rowELKFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdELKFull = CType(.Cells(variableDeclaration.rowELKFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateELKFull = CType(.Cells(variableDeclaration.rowELKFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdELKFull = CType(.Cells(variableDeclaration.rowELKFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateELKFull = CType(.Cells(variableDeclaration.rowELKFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindELKFull = CType(.Cells(variableDeclaration.rowELKFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionELKRegression = CType(.Cells(variableDeclaration.rowELKRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedELKRegression = CType(.Cells(variableDeclaration.rowELKRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedELKRegression = CType(.Cells(variableDeclaration.rowELKRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdELKRegression = CType(.Cells(variableDeclaration.rowELKRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateELKRegression = CType(.Cells(variableDeclaration.rowELKRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdELKRegression = CType(.Cells(variableDeclaration.rowELKRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateELKRegression = CType(.Cells(variableDeclaration.rowELKRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindELKRegression = CType(.Cells(variableDeclaration.rowELKRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionELKDelta = CType(.Cells(variableDeclaration.rowELKDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedELKDelta = CType(.Cells(variableDeclaration.rowELKDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedELKDelta = CType(.Cells(variableDeclaration.rowELKDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdELKDelta = CType(.Cells(variableDeclaration.rowELKDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateELKDelta = CType(.Cells(variableDeclaration.rowELKDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdELKDelta = CType(.Cells(variableDeclaration.rowELKDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateELKDelta = CType(.Cells(variableDeclaration.rowELKDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindELKDelta = CType(.Cells(variableDeclaration.rowELKDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionTJAFull = CType(.Cells(variableDeclaration.rowTJAFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedTJAFull = CType(.Cells(variableDeclaration.rowTJAFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedTJAFull = CType(.Cells(variableDeclaration.rowTJAFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdTJAFull = CType(.Cells(variableDeclaration.rowTJAFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateTJAFull = CType(.Cells(variableDeclaration.rowTJAFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdTJAFull = CType(.Cells(variableDeclaration.rowTJAFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateTJAFull = CType(.Cells(variableDeclaration.rowTJAFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindTJAFull = CType(.Cells(variableDeclaration.rowTJAFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionTJARegression = CType(.Cells(variableDeclaration.rowTJARegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedTJARegression = CType(.Cells(variableDeclaration.rowTJARegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedTJARegression = CType(.Cells(variableDeclaration.rowTJARegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdTJARegression = CType(.Cells(variableDeclaration.rowTJARegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateTJARegression = CType(.Cells(variableDeclaration.rowTJARegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdTJARegression = CType(.Cells(variableDeclaration.rowTJARegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateTJARegression = CType(.Cells(variableDeclaration.rowTJARegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindTJARegression = CType(.Cells(variableDeclaration.rowTJARegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionTJADelta = CType(.Cells(variableDeclaration.rowTJADelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedTJADelta = CType(.Cells(variableDeclaration.rowTJADelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedTJADelta = CType(.Cells(variableDeclaration.rowTJADelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdTJADelta = CType(.Cells(variableDeclaration.rowTJADelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateTJADelta = CType(.Cells(variableDeclaration.rowTJADelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdTJADelta = CType(.Cells(variableDeclaration.rowTJADelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateTJADelta = CType(.Cells(variableDeclaration.rowTJADelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindTJADelta = CType(.Cells(variableDeclaration.rowTJADelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSLAFull = CType(.Cells(variableDeclaration.rowSLAFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSLAFull = CType(.Cells(variableDeclaration.rowSLAFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSLAFull = CType(.Cells(variableDeclaration.rowSLAFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSLAFull = CType(.Cells(variableDeclaration.rowSLAFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSLAFull = CType(.Cells(variableDeclaration.rowSLAFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSLAFull = CType(.Cells(variableDeclaration.rowSLAFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSLAFull = CType(.Cells(variableDeclaration.rowSLAFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSLAFull = CType(.Cells(variableDeclaration.rowSLAFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSLARegression = CType(.Cells(variableDeclaration.rowSLARegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSLARegression = CType(.Cells(variableDeclaration.rowSLARegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSLARegression = CType(.Cells(variableDeclaration.rowSLARegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSLARegression = CType(.Cells(variableDeclaration.rowSLARegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSLARegression = CType(.Cells(variableDeclaration.rowSLARegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSLARegression = CType(.Cells(variableDeclaration.rowSLARegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSLARegression = CType(.Cells(variableDeclaration.rowSLARegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSLARegression = CType(.Cells(variableDeclaration.rowSLARegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSLADelta = CType(.Cells(variableDeclaration.rowSLADelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSLADelta = CType(.Cells(variableDeclaration.rowSLADelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSLADelta = CType(.Cells(variableDeclaration.rowSLADelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSLADelta = CType(.Cells(variableDeclaration.rowSLADelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSLADelta = CType(.Cells(variableDeclaration.rowSLADelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSLADelta = CType(.Cells(variableDeclaration.rowSLADelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSLADelta = CType(.Cells(variableDeclaration.rowSLADelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSLADelta = CType(.Cells(variableDeclaration.rowSLADelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionHMAFull = CType(.Cells(variableDeclaration.rowHMAFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedHMAFull = CType(.Cells(variableDeclaration.rowHMAFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedHMAFull = CType(.Cells(variableDeclaration.rowHMAFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdHMAFull = CType(.Cells(variableDeclaration.rowHMAFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateHMAFull = CType(.Cells(variableDeclaration.rowHMAFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdHMAFull = CType(.Cells(variableDeclaration.rowHMAFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateHMAFull = CType(.Cells(variableDeclaration.rowHMAFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindHMAFull = CType(.Cells(variableDeclaration.rowHMAFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionHMARegression = CType(.Cells(variableDeclaration.rowHMARegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedHMARegression = CType(.Cells(variableDeclaration.rowHMARegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedHMARegression = CType(.Cells(variableDeclaration.rowHMARegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdHMARegression = CType(.Cells(variableDeclaration.rowHMARegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateHMARegression = CType(.Cells(variableDeclaration.rowHMARegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdHMARegression = CType(.Cells(variableDeclaration.rowHMARegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateHMARegression = CType(.Cells(variableDeclaration.rowHMARegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindHMARegression = CType(.Cells(variableDeclaration.rowHMARegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionHMADelta = CType(.Cells(variableDeclaration.rowHMADelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedHMADelta = CType(.Cells(variableDeclaration.rowHMADelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedHMADelta = CType(.Cells(variableDeclaration.rowHMADelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdHMADelta = CType(.Cells(variableDeclaration.rowHMADelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateHMADelta = CType(.Cells(variableDeclaration.rowHMADelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdHMADelta = CType(.Cells(variableDeclaration.rowHMADelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateHMADelta = CType(.Cells(variableDeclaration.rowHMADelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindHMADelta = CType(.Cells(variableDeclaration.rowHMADelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionVehicleFull = CType(.Cells(variableDeclaration.rowVehicleFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedVehicleFull = CType(.Cells(variableDeclaration.rowVehicleFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedVehicleFull = CType(.Cells(variableDeclaration.rowVehicleFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdVehicleFull = CType(.Cells(variableDeclaration.rowVehicleFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateVehicleFull = CType(.Cells(variableDeclaration.rowVehicleFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdVehicleFull = CType(.Cells(variableDeclaration.rowVehicleFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateVehicleFull = CType(.Cells(variableDeclaration.rowVehicleFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindVehicleFull = CType(.Cells(variableDeclaration.rowVehicleFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionVehicleRegression = CType(.Cells(variableDeclaration.rowVehicleRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedVehicleRegression = CType(.Cells(variableDeclaration.rowVehicleRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedVehicleRegression = CType(.Cells(variableDeclaration.rowVehicleRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdVehicleRegression = CType(.Cells(variableDeclaration.rowVehicleRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateVehicleRegression = CType(.Cells(variableDeclaration.rowVehicleRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdVehicleRegression = CType(.Cells(variableDeclaration.rowVehicleRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateVehicleRegression = CType(.Cells(variableDeclaration.rowVehicleRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindVehicleRegression = CType(.Cells(variableDeclaration.rowVehicleRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionVehicleDelta = CType(.Cells(variableDeclaration.rowVehicleDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedVehicleDelta = CType(.Cells(variableDeclaration.rowVehicleDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedVehicleDelta = CType(.Cells(variableDeclaration.rowVehicleDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdVehicleDelta = CType(.Cells(variableDeclaration.rowVehicleDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateVehicleDelta = CType(.Cells(variableDeclaration.rowVehicleDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdVehicleDelta = CType(.Cells(variableDeclaration.rowVehicleDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateVehicleDelta = CType(.Cells(variableDeclaration.rowVehicleDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindVehicleDelta = CType(.Cells(variableDeclaration.rowVehicleDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSITFull = CType(.Cells(variableDeclaration.rowSITFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSITFull = CType(.Cells(variableDeclaration.rowSITFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSITFull = CType(.Cells(variableDeclaration.rowSITFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSITFull = CType(.Cells(variableDeclaration.rowSITFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSITFull = CType(.Cells(variableDeclaration.rowSITFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSITFull = CType(.Cells(variableDeclaration.rowSITFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSITFull = CType(.Cells(variableDeclaration.rowSITFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSITFull = CType(.Cells(variableDeclaration.rowSITFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSITRegression = CType(.Cells(variableDeclaration.rowSITRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSITRegression = CType(.Cells(variableDeclaration.rowSITRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSITRegression = CType(.Cells(variableDeclaration.rowSITRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSITRegression = CType(.Cells(variableDeclaration.rowSITRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSITRegression = CType(.Cells(variableDeclaration.rowSITRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSITRegression = CType(.Cells(variableDeclaration.rowSITRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSITRegression = CType(.Cells(variableDeclaration.rowSITRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSITRegression = CType(.Cells(variableDeclaration.rowSITRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSITDelta = CType(.Cells(variableDeclaration.rowSITDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSITDelta = CType(.Cells(variableDeclaration.rowSITDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSITDelta = CType(.Cells(variableDeclaration.rowSITDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSITDelta = CType(.Cells(variableDeclaration.rowSITDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSITDelta = CType(.Cells(variableDeclaration.rowSITDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSITDelta = CType(.Cells(variableDeclaration.rowSITDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSITDelta = CType(.Cells(variableDeclaration.rowSITDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSITDelta = CType(.Cells(variableDeclaration.rowSITDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheckFull, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheckFull, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheckFull, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheckFull, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheckFull, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheckFull, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheckFull, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSRCheckFull = CType(.Cells(variableDeclaration.rowSRCheckFull, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheckRegression, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheckRegression, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheckRegression, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheckRegression, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheckRegression, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheckRegression, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheckRegression, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSRCheckRegression = CType(.Cells(variableDeclaration.rowSRCheckRegression, variableDeclaration.colDefectKindAllTestPart), Excel.Range)

            dbVersionSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheckDelta, variableDeclaration.colVersionAllTestPart), Excel.Range)
            dbPassedSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheckDelta, variableDeclaration.colPassedAllTestPart), Excel.Range)
            dbFailedSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheckDelta, variableDeclaration.colFailedAllTestPart), Excel.Range)
            dbPtIdSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheckDelta, variableDeclaration.colPtIdAllTestPart), Excel.Range)
            dbPtStateSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheckDelta, variableDeclaration.colPtStateAllTestPart), Excel.Range)
            dbDefectIdSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheckDelta, variableDeclaration.colDefectIdAllTestPart), Excel.Range)
            dbDefectStateSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheckDelta, variableDeclaration.colDefectStateAllTestPart), Excel.Range)
            dbDefectKindSRCheckDelta = CType(.Cells(variableDeclaration.rowSRCheckDelta, variableDeclaration.colDefectKindAllTestPart), Excel.Range)
        End With
    End Sub

    Public Sub selectDB()
        Dim curProject As String
        Dim dbWSIndex As Excel.Worksheet
        Dim temp As Integer
        temp = 0 ' DB is not available
        curProject = TestReport.swProject.Text

        For Each dbWSIndex In dbWB.Worksheets
            If curProject = dbWSIndex.Name Then
                temp += 1
            End If
        Next dbWSIndex

        If temp = 0 Then ' DB is not available

            dbWB.Sheets("DBTemplate").Copy(After:=dbWB.Sheets(dbWB.Sheets.Count))
            dbWB.Sheets(dbWB.Sheets.Count).Name = curProject
            ' dbWB.SaveAs(dbPath)
            ' dbWB.Close()
            ' msexcelApp.Quit()
        End If

    End Sub
End Class
