﻿
Public Class variableDeclaration
    Public index As Integer
    Public Shared project As String
    Public Shared swVariant As String
    Public Shared release As String
    Public Shared version As String

    Public Shared testingLevel As String
    Public Shared documentOwner As String
    Public Shared modifiedBy As String
    Public Shared testCoordinator As String
    Public Shared documentVersion As String
    Public Shared startDate As String
    Public Shared endDate As String
    Public Shared releaseDate As String

    Public Shared delivery As String
    Public Shared source As String
    Public Shared coresi As String

    Public Shared dcom As Boolean
    Public Shared em As Boolean
    Public Shared com As Boolean
    Public Shared ldw As Boolean
    Public Shared lks As Boolean
    Public Shared rdp As Boolean
    Public Shared elk As Boolean
    Public Shared tja As Boolean
    Public Shared sla As Boolean
    Public Shared hma As Boolean
    Public Shared vehicle As Boolean
    Public Shared sit As Boolean
    Public Shared srCheck As Boolean

    Public Shared dcomFull As Boolean
    Public Shared dcomRegression As Boolean
    Public Shared dcomDelta As Boolean
    Public Shared emFull As Boolean
    Public Shared emRegression As Boolean
    Public Shared emDelta As Boolean
    Public Shared comFull As Boolean
    Public Shared comRegression As Boolean
    Public Shared comDelta As Boolean
    Public Shared ldwFull As Boolean
    Public Shared ldwRegression As Boolean
    Public Shared ldwDelta As Boolean
    Public Shared lksFull As Boolean
    Public Shared lksRegression As Boolean
    Public Shared lksDelta As Boolean
    Public Shared rdpFull As Boolean
    Public Shared rdpRegression As Boolean
    Public Shared rdpDelta As Boolean
    Public Shared elkFull As Boolean
    Public Shared elkRegression As Boolean
    Public Shared elkDelta As Boolean
    Public Shared tjaFull As Boolean
    Public Shared tjaRegression As Boolean
    Public Shared tjaDelta As Boolean
    Public Shared slaFull As Boolean
    Public Shared slaRegression As Boolean
    Public Shared slaDelta As Boolean
    Public Shared hmaFull As Boolean
    Public Shared hmaRegression As Boolean
    Public Shared hmaDelta As Boolean
    Public Shared vehicleFull As Boolean
    Public Shared vehicleRegression As Boolean
    Public Shared vehicleDelta As Boolean
    Public Shared sitFull As Boolean
    Public Shared sitRegression As Boolean
    Public Shared sitDelta As Boolean
    Public Shared srCheckFull As Boolean
    Public Shared srCheckRegression As Boolean
    Public Shared srCheckDelta As Boolean

    Public Shared labtDCOM As String
    Public Shared labtEM As String
    Public Shared labtCOM As String
    Public Shared labtLDW As String
    Public Shared labtLKS As String
    Public Shared labtRDP As String
    Public Shared labtELK As String
    Public Shared labtTJA As String
    Public Shared labtSLA As String
    Public Shared labtHMA As String
    Public Shared labtVehicle As String
    Public Shared labtSIT As String
    Public Shared labtSRCheck As String

    Public Shared ouputReportLocation As String

    Public Shared versionDCOMFull As String
    Public Shared passedDCOMFull As String
    Public Shared failedDCOMFull As String
    Public Shared ptIdDCOMFull As String
    Public Shared ptStateDCOMFull As String
    Public Shared defectIdDCOMFull As String
    Public Shared defectStateDCOMFull As String
    Public Shared defectKindDCOMFull As String

    Public Shared versionDCOMRegression As String
    Public Shared passedDCOMRegression As String
    Public Shared failedDCOMRegression As String
    Public Shared ptIdDCOMRegression As String
    Public Shared ptStateDCOMRegression As String
    Public Shared defectIdDCOMRegression As String
    Public Shared defectStateDCOMRegression As String
    Public Shared defectKindDCOMRegression As String

    Public Shared versionDCOMDelta As String
    Public Shared passedDCOMDelta As String
    Public Shared failedDCOMDelta As String
    Public Shared ptIdDCOMDelta As String
    Public Shared ptStateDCOMDelta As String
    Public Shared defectIdDCOMDelta As String
    Public Shared defectStateDCOMDelta As String
    Public Shared defectKindDCOMDelta As String

    Public Shared versionEMFull As String
    Public Shared passedEMFull As String
    Public Shared failedEMFull As String
    Public Shared ptIdEMFull As String
    Public Shared ptStateEMFull As String
    Public Shared defectIdEMFull As String
    Public Shared defectStateEMFull As String
    Public Shared defectKindEMFull As String

    Public Shared versionEMRegression As String
    Public Shared passedEMRegression As String
    Public Shared failedEMRegression As String
    Public Shared ptIdEMRegression As String
    Public Shared ptStateEMRegression As String
    Public Shared defectIdEMRegression As String
    Public Shared defectStateEMRegression As String
    Public Shared defectKindEMRegression As String

    Public Shared versionEMDelta As String
    Public Shared passedEMDelta As String
    Public Shared failedEMDelta As String
    Public Shared ptIdEMDelta As String
    Public Shared ptStateEMDelta As String
    Public Shared defectIdEMDelta As String
    Public Shared defectStateEMDelta As String
    Public Shared defectKindEMDelta As String

    Public Shared versionCOMFull As String
    Public Shared passedCOMFull As String
    Public Shared failedCOMFull As String
    Public Shared ptIdCOMFull As String
    Public Shared ptStateCOMFull As String
    Public Shared defectIdCOMFull As String
    Public Shared defectStateCOMFull As String
    Public Shared defectKindCOMFull As String

    Public Shared versionCOMRegression As String
    Public Shared passedCOMRegression As String
    Public Shared failedCOMRegression As String
    Public Shared ptIdCOMRegression As String
    Public Shared ptStateCOMRegression As String
    Public Shared defectIdCOMRegression As String
    Public Shared defectStateCOMRegression As String
    Public Shared defectKindCOMRegression As String

    Public Shared versionCOMDelta As String
    Public Shared passedCOMDelta As String
    Public Shared failedCOMDelta As String
    Public Shared ptIdCOMDelta As String
    Public Shared ptStateCOMDelta As String
    Public Shared defectIdCOMDelta As String
    Public Shared defectStateCOMDelta As String
    Public Shared defectKindCOMDelta As String

    Public Shared versionLDWFull As String
    Public Shared passedLDWFull As String
    Public Shared failedLDWFull As String
    Public Shared ptIdLDWFull As String
    Public Shared ptStateLDWFull As String
    Public Shared defectIdLDWFull As String
    Public Shared defectStateLDWFull As String
    Public Shared defectKindLDWFull As String

    Public Shared versionLDWRegression As String
    Public Shared passedLDWRegression As String
    Public Shared failedLDWRegression As String
    Public Shared ptIdLDWRegression As String
    Public Shared ptStateLDWRegression As String
    Public Shared defectIdLDWRegression As String
    Public Shared defectStateLDWRegression As String
    Public Shared defectKindLDWRegression As String

    Public Shared versionLDWDelta As String
    Public Shared passedLDWDelta As String
    Public Shared failedLDWDelta As String
    Public Shared ptIdLDWDelta As String
    Public Shared ptStateLDWDelta As String
    Public Shared defectIdLDWDelta As String
    Public Shared defectStateLDWDelta As String
    Public Shared defectKindLDWDelta As String

    Public Shared versionLKSFull As String
    Public Shared passedLKSFull As String
    Public Shared failedLKSFull As String
    Public Shared ptIdLKSFull As String
    Public Shared ptStateLKSFull As String
    Public Shared defectIdLKSFull As String
    Public Shared defectStateLKSFull As String
    Public Shared defectKindLKSFull As String

    Public Shared versionLKSRegression As String
    Public Shared passedLKSRegression As String
    Public Shared failedLKSRegression As String
    Public Shared ptIdLKSRegression As String
    Public Shared ptStateLKSRegression As String
    Public Shared defectIdLKSRegression As String
    Public Shared defectStateLKSRegression As String
    Public Shared defectKindLKSRegression As String

    Public Shared versionLKSDelta As String
    Public Shared passedLKSDelta As String
    Public Shared failedLKSDelta As String
    Public Shared ptIdLKSDelta As String
    Public Shared ptStateLKSDelta As String
    Public Shared defectIdLKSDelta As String
    Public Shared defectStateLKSDelta As String
    Public Shared defectKindLKSDelta As String

    Public Shared versionRDPFull As String
    Public Shared passedRDPFull As String
    Public Shared failedRDPFull As String
    Public Shared ptIdRDPFull As String
    Public Shared ptStateRDPFull As String
    Public Shared defectIdRDPFull As String
    Public Shared defectStateRDPFull As String
    Public Shared defectKindRDPFull As String

    Public Shared versionRDPRegression As String
    Public Shared passedRDPRegression As String
    Public Shared failedRDPRegression As String
    Public Shared ptIdRDPRegression As String
    Public Shared ptStateRDPRegression As String
    Public Shared defectIdRDPRegression As String
    Public Shared defectStateRDPRegression As String
    Public Shared defectKindRDPRegression As String

    Public Shared versionRDPDelta As String
    Public Shared passedRDPDelta As String
    Public Shared failedRDPDelta As String
    Public Shared ptIdRDPDelta As String
    Public Shared ptStateRDPDelta As String
    Public Shared defectIdRDPDelta As String
    Public Shared defectStateRDPDelta As String
    Public Shared defectKindRDPDelta As String

    Public Shared versionELKFull As String
    Public Shared passedELKFull As String
    Public Shared failedELKFull As String
    Public Shared ptIdELKFull As String
    Public Shared ptStateELKFull As String
    Public Shared defectIdELKFull As String
    Public Shared defectStateELKFull As String
    Public Shared defectKindELKFull As String

    Public Shared versionELKRegression As String
    Public Shared passedELKRegression As String
    Public Shared failedELKRegression As String
    Public Shared ptIdELKRegression As String
    Public Shared ptStateELKRegression As String
    Public Shared defectIdELKRegression As String
    Public Shared defectStateELKRegression As String
    Public Shared defectKindELKRegression As String

    Public Shared versionELKDelta As String
    Public Shared passedELKDelta As String
    Public Shared failedELKDelta As String
    Public Shared ptIdELKDelta As String
    Public Shared ptStateELKDelta As String
    Public Shared defectIdELKDelta As String
    Public Shared defectStateELKDelta As String
    Public Shared defectKindELKDelta As String

    Public Shared versionTJAFull As String
    Public Shared passedTJAFull As String
    Public Shared failedTJAFull As String
    Public Shared ptIdTJAFull As String
    Public Shared ptStateTJAFull As String
    Public Shared defectIdTJAFull As String
    Public Shared defectStateTJAFull As String
    Public Shared defectKindTJAFull As String

    Public Shared versionTJARegression As String
    Public Shared passedTJARegression As String
    Public Shared failedTJARegression As String
    Public Shared ptIdTJARegression As String
    Public Shared ptStateTJARegression As String
    Public Shared defectIdTJARegression As String
    Public Shared defectStateTJARegression As String
    Public Shared defectKindTJARegression As String

    Public Shared versionTJADelta As String
    Public Shared passedTJADelta As String
    Public Shared failedTJADelta As String
    Public Shared ptIdTJADelta As String
    Public Shared ptStateTJADelta As String
    Public Shared defectIdTJADelta As String
    Public Shared defectStateTJADelta As String
    Public Shared defectKindTJADelta As String

    Public Shared versionSLAFull As String
    Public Shared passedSLAFull As String
    Public Shared failedSLAFull As String
    Public Shared ptIdSLAFull As String
    Public Shared ptStateSLAFull As String
    Public Shared defectIdSLAFull As String
    Public Shared defectStateSLAFull As String
    Public Shared defectKindSLAFull As String

    Public Shared versionSLARegression As String
    Public Shared passedSLARegression As String
    Public Shared failedSLARegression As String
    Public Shared ptIdSLARegression As String
    Public Shared ptStateSLARegression As String
    Public Shared defectIdSLARegression As String
    Public Shared defectStateSLARegression As String
    Public Shared defectKindSLARegression As String

    Public Shared versionSLADelta As String
    Public Shared passedSLADelta As String
    Public Shared failedSLADelta As String
    Public Shared ptIdSLADelta As String
    Public Shared ptStateSLADelta As String
    Public Shared defectIdSLADelta As String
    Public Shared defectStateSLADelta As String
    Public Shared defectKindSLADelta As String

    Public Shared versionHMAFull As String
    Public Shared passedHMAFull As String
    Public Shared failedHMAFull As String
    Public Shared ptIdHMAFull As String
    Public Shared ptStateHMAFull As String
    Public Shared defectIdHMAFull As String
    Public Shared defectStateHMAFull As String
    Public Shared defectKindHMAFull As String

    Public Shared versionHMARegression As String
    Public Shared passedHMARegression As String
    Public Shared failedHMARegression As String
    Public Shared ptIdHMARegression As String
    Public Shared ptStateHMARegression As String
    Public Shared defectIdHMARegression As String
    Public Shared defectStateHMARegression As String
    Public Shared defectKindHMARegression As String

    Public Shared versionHMADelta As String
    Public Shared passedHMADelta As String
    Public Shared failedHMADelta As String
    Public Shared ptIdHMADelta As String
    Public Shared ptStateHMADelta As String
    Public Shared defectIdHMADelta As String
    Public Shared defectStateHMADelta As String
    Public Shared defectKindHMADelta As String

    Public Shared versionVehicleFull As String
    Public Shared passedVehicleFull As String
    Public Shared failedVehicleFull As String
    Public Shared ptIdVehicleFull As String
    Public Shared ptStateVehicleFull As String
    Public Shared defectIdVehicleFull As String
    Public Shared defectStateVehicleFull As String
    Public Shared defectKindVehicleFull As String

    Public Shared versionVehicleRegression As String
    Public Shared passedVehicleRegression As String
    Public Shared failedVehicleRegression As String
    Public Shared ptIdVehicleRegression As String
    Public Shared ptStateVehicleRegression As String
    Public Shared defectIdVehicleRegression As String
    Public Shared defectStateVehicleRegression As String
    Public Shared defectKindVehicleRegression As String

    Public Shared versionVehicleDelta As String
    Public Shared passedVehicleDelta As String
    Public Shared failedVehicleDelta As String
    Public Shared ptIdVehicleDelta As String
    Public Shared ptStateVehicleDelta As String
    Public Shared defectIdVehicleDelta As String
    Public Shared defectStateVehicleDelta As String
    Public Shared defectKindVehicleDelta As String

    Public Shared versionSITFull As String
    Public Shared passedSITFull As String
    Public Shared failedSITFull As String
    Public Shared ptIdSITFull As String
    Public Shared ptStateSITFull As String
    Public Shared defectIdSITFull As String
    Public Shared defectStateSITFull As String
    Public Shared defectKindSITFull As String

    Public Shared versionSITRegression As String
    Public Shared passedSITRegression As String
    Public Shared failedSITRegression As String
    Public Shared ptIdSITRegression As String
    Public Shared ptStateSITRegression As String
    Public Shared defectIdSITRegression As String
    Public Shared defectStateSITRegression As String
    Public Shared defectKindSITRegression As String

    Public Shared versionSITDelta As String
    Public Shared passedSITDelta As String
    Public Shared failedSITDelta As String
    Public Shared ptIdSITDelta As String
    Public Shared ptStateSITDelta As String
    Public Shared defectIdSITDelta As String
    Public Shared defectStateSITDelta As String
    Public Shared defectKindSITDelta As String

    Public Shared versionSRCheckFull As String
    Public Shared passedSRCheckFull As String
    Public Shared failedSRCheckFull As String
    Public Shared ptIdSRCheckFull As String
    Public Shared ptStateSRCheckFull As String
    Public Shared defectIdSRCheckFull As String
    Public Shared defectStateSRCheckFull As String
    Public Shared defectKindSRCheckFull As String

    Public Shared versionSRCheckRegression As String
    Public Shared passedSRCheckRegression As String
    Public Shared failedSRCheckRegression As String
    Public Shared ptIdSRCheckRegression As String
    Public Shared ptStateSRCheckRegression As String
    Public Shared defectIdSRCheckRegression As String
    Public Shared defectStateSRCheckRegression As String
    Public Shared defectKindSRCheckRegression As String

    Public Shared versionSRCheckDelta As String
    Public Shared passedSRCheckDelta As String
    Public Shared failedSRCheckDelta As String
    Public Shared ptIdSRCheckDelta As String
    Public Shared ptStateSRCheckDelta As String
    Public Shared defectIdSRCheckDelta As String
    Public Shared defectStateSRCheckDelta As String
    Public Shared defectKindSRCheckDelta As String

    Public Shared colProject As Integer
    Public Shared colVariant As Integer
    Public Shared colRelease As Integer
    Public Shared colVersion As Integer
    Public Shared colLevelOfTesting As Integer
    Public Shared colDocumentOwner As Integer
    Public Shared colModifiedBy As Integer
    Public Shared colTestCoordinator As Integer
    Public Shared colDocumentVersion As Integer
    Public Shared colStartDate As Integer
    Public Shared colEndDate As Integer
    Public Shared colReleaseDate As Integer
    Public Shared colDelivery As Integer
    Public Shared colSource As Integer
    Public Shared colCoresi As Integer

    Public Shared colDCOM As Integer
    Public Shared colEM As Integer
    Public Shared colCOM As Integer
    Public Shared colLDW As Integer
    Public Shared colLKS As Integer
    Public Shared colRDP As Integer
    Public Shared colELK As Integer
    Public Shared colTJA As Integer
    Public Shared colSLA As Integer
    Public Shared colHMA As Integer
    Public Shared colVehicle As Integer
    Public Shared colSIT As Integer
    Public Shared colSRCheck As Integer

    Public Shared colAllTestPartFull As Integer
    Public Shared colAllTestPartRegression As Integer
    Public Shared colAllTestPartDelta As Integer

    Public Shared colLabtDCOM As Integer
    Public Shared colLabtEM As Integer
    Public Shared colLabtCOM As Integer
    Public Shared colLabtLDW As Integer
    Public Shared colLabtLKS As Integer
    Public Shared colLabtRDP As Integer
    Public Shared colLabtELK As Integer
    Public Shared colLabtTJA As Integer
    Public Shared colLabtSLA As Integer
    Public Shared colLabtHMA As Integer
    Public Shared colLabtVehicle As Integer
    Public Shared colLabtSIT As Integer
    Public Shared colLabtSRCheck As Integer
    Public Shared colOutputReportLocation As Integer

    Public Shared colVersionAllTestPart As Integer
    Public Shared colPassedAllTestPart As Integer
    Public Shared colFailedAllTestPart As Integer
    Public Shared colPtIdAllTestPart As Integer
    Public Shared colPtStateAllTestPart As Integer
    Public Shared colDefectIdAllTestPart As Integer
    Public Shared colDefectStateAllTestPart As Integer
    Public Shared colDefectKindAllTestPart As Integer

    Public Shared rowProject As Integer
    Public Shared rowVariant As Integer
    Public Shared rowRelease As Integer
    Public Shared rowVersion As Integer
    Public Shared rowLevelOfTesting As Integer
    Public Shared rowDocumentOwner As Integer
    Public Shared rowModifiedBy As Integer
    Public Shared rowTestCoordinator As Integer
    Public Shared rowDocumentVersion As Integer
    Public Shared rowStartDate As Integer
    Public Shared rowEndDate As Integer
    Public Shared rowReleaseDate As Integer
    Public Shared rowDelivery As Integer
    Public Shared rowSource As Integer
    Public Shared rowCoresi As Integer

    Public Shared rowDCOM As Integer
    Public Shared rowEM As Integer
    Public Shared rowCOM As Integer
    Public Shared rowLDW As Integer
    Public Shared rowLKS As Integer
    Public Shared rowRDP As Integer
    Public Shared rowELK As Integer
    Public Shared rowTJA As Integer
    Public Shared rowSLA As Integer
    Public Shared rowHMA As Integer
    Public Shared rowVehicle As Integer
    Public Shared rowSIT As Integer
    Public Shared rowSRCheck As Integer

    Public Shared rowOutputReportLocation As Integer

    Public Shared rowDCOMFull As Integer
    Public Shared rowDCOMRegression As Integer
    Public Shared rowDCOMDelta As Integer
    Public Shared rowEMFull As Integer
    Public Shared rowEMRegression As Integer
    Public Shared rowEMDelta As Integer
    Public Shared rowCOMFull As Integer
    Public Shared rowCOMRegression As Integer
    Public Shared rowCOMDelta As Integer
    Public Shared rowLDWFull As Integer
    Public Shared rowLDWRegression As Integer
    Public Shared rowLDWDelta As Integer
    Public Shared rowLKSFull As Integer
    Public Shared rowLKSRegression As Integer
    Public Shared rowLKSDelta As Integer
    Public Shared rowRDPFull As Integer
    Public Shared rowRDPRegression As Integer
    Public Shared rowRDPDelta As Integer
    Public Shared rowELKFull As Integer
    Public Shared rowELKRegression As Integer
    Public Shared rowELKDelta As Integer
    Public Shared rowTJAFull As Integer
    Public Shared rowTJARegression As Integer
    Public Shared rowTJADelta As Integer
    Public Shared rowSLAFull As Integer
    Public Shared rowSLARegression As Integer
    Public Shared rowSLADelta As Integer
    Public Shared rowHMAFull As Integer
    Public Shared rowHMARegression As Integer
    Public Shared rowHMADelta As Integer
    Public Shared rowVehicleFull As Integer
    Public Shared rowVehicleRegression As Integer
    Public Shared rowVehicleDelta As Integer
    Public Shared rowSITFull As Integer
    Public Shared rowSITRegression As Integer
    Public Shared rowSITDelta As Integer
    Public Shared rowSRCheckFull As Integer
    Public Shared rowSRCheckRegression As Integer
    Public Shared rowSRCheckDelta As Integer


    Public Sub assign_variable()
        index = 1

        With TestReport
            ' Data in GUI
            project = .swProject.Text
            swVariant = .swVariant.Text
            release = .swRelease.Text
            version = .swVersion.Text

            testingLevel = .levelOfTesting.Text
            documentOwner = .documentOwner.Text
            modifiedBy = .modifiedBy.Text
            testCoordinator = .testCoordinator.Text
            documentVersion = .documentVersion.Text
            startDate = .startDate.Text.Split("/")(1) & "/" & .startDate.Text.Split("/")(0) & "/" & .startDate.Text.Split("/")(2)
            endDate = .endDate.Text.Split("/")(1) & "/" & .endDate.Text.Split("/")(0) & "/" & .endDate.Text.Split("/")(2)
            releaseDate = .releaseDate.Text.Split("/")(1) & "/" & .releaseDate.Text.Split("/")(0) & "/" & .releaseDate.Text.Split("/")(2)

            delivery = .swDelivery.Text
            source = .swSource.Text
            coresi = .swCoresi.Text

            dcom = .swDCOM.Checked
            em = .swEM.Checked
            com = .swCOM.Checked
            ldw = .swLDW.Checked
            lks = .swLKS.Checked
            rdp = .swRDP.Checked
            elk = .swELK.Checked
            tja = .swTJA.Checked
            sla = .swSLA.Checked
            hma = .swHMA.Checked
            vehicle = .swVehicle.Checked
            sit = .swSIT.Checked
            srCheck = .swSRCheck.Checked

            dcomFull = .optionDCOMFull.Checked
            dcomRegression = .optionDCOMRegression.Checked
            dcomDelta = .optionDCOMDelta.Checked
            emFull = .optionEMFull.Checked
            emRegression = .optionEMRegression.Checked
            emDelta = .optionEMDelta.Checked
            comFull = .optionCOMFull.Checked
            comRegression = .optionCOMRegression.Checked
            comDelta = .optionCOMDelta.Checked
            ldwFull = .optionLDWFull.Checked
            ldwRegression = .optionLDWRegression.Checked
            ldwDelta = .optionLDWDelta.Checked
            lksFull = .optionLKSFull.Checked
            lksRegression = .optionLKSRegression.Checked
            lksDelta = .optionLKSDelta.Checked
            rdpFull = .optionRDPFull.Checked
            rdpRegression = .optionRDPRegression.Checked
            rdpDelta = .optionRDPDelta.Checked
            elkFull = .optionELKFull.Checked
            elkRegression = .optionELKRegression.Checked
            elkDelta = .optionELKDelta.Checked
            tjaFull = .optionTJAFull.Checked
            tjaRegression = .optionTJARegression.Checked
            tjaDelta = .optionTJADelta.Checked
            slaFull = .optionSLAFull.Checked
            slaRegression = .optionSLARegression.Checked
            slaDelta = .optionSLADelta.Checked
            hmaFull = .optionHMAFull.Checked
            hmaRegression = .optionHMARegression.Checked
            hmaDelta = .optionHMADelta.Checked
            vehicleFull = .optionVehicleFull.Checked
            vehicleRegression = .optionVehicleRegression.Checked
            vehicleDelta = .optionVehicleDelta.Checked
            sitFull = .optionSITFull.Checked
            sitRegression = .optionSITRegression.Checked
            sitDelta = .optionSITDelta.Checked
            srCheckFull = .optionSRCheckFull.Checked
            srCheckRegression = .optionSRCheckRegression.Checked
            srCheckDelta = .optionSRCheckDelta.Checked

            labtDCOM = .optionLabTDCOM.Text
            labtEM = .optionLabTEM.Text
            labtCOM = .optionLabTCOM.Text
            labtLDW = .optionLabTLDW.Text
            labtLKS = .optionLabTLKS.Text
            labtRDP = .optionLabTRDP.Text
            labtELK = .optionLabTELK.Text
            labtTJA = .optionLabTTJA.Text
            labtSLA = .optionLabTSLA.Text
            labtHMA = .optionLabTHMA.Text
            labtVehicle = .optionLabTVehicle.Text
            labtSIT = .optionLabTSIT.Text
            labtSRCheck = .optionLabTSRCheck.Text

            ouputReportLocation = .ouputReportLocation.Text

            versionDCOMFull = .optionVersionDCOMFull.Text
            passedDCOMFull = .optionPassedDCOMFull.Text
            failedDCOMFull = .optionFailedDCOMFull.Text
            ptIdDCOMFull = .optionPtIdDCOMFull.Text
            ptStateDCOMFull = .optionPtStateDCOMFull.Text
            defectIdDCOMFull = .optionDefectIdDCOMFull.Text
            defectStateDCOMFull = .optionDefectStateDCOMFull.Text
            defectKindDCOMFull = .optionDefectKindDCOMFull.Text

            versionDCOMRegression = .optionVersionDCOMRegression.Text
            passedDCOMRegression = .optionPassedDCOMRegression.Text
            failedDCOMRegression = .optionFailedDCOMRegression.Text
            ptIdDCOMRegression = .optionPtIdDCOMRegression.Text
            ptStateDCOMRegression = .optionPtStateDCOMRegression.Text
            defectIdDCOMRegression = .optionDefectIdDCOMRegression.Text
            defectStateDCOMRegression = .optionDefectStateDCOMRegression.Text
            defectKindDCOMRegression = .optionDefectKindDCOMRegression.Text

            versionDCOMDelta = .optionVersionDCOMDelta.Text
            passedDCOMDelta = .optionPassedDCOMDelta.Text
            failedDCOMDelta = .optionFailedDCOMDelta.Text
            ptIdDCOMDelta = .optionPtIdDCOMDelta.Text
            ptStateDCOMDelta = .optionPtStateDCOMDelta.Text
            defectIdDCOMDelta = .optionDefectIdDCOMDelta.Text
            defectStateDCOMDelta = .optionDefectStateDCOMDelta.Text
            defectKindDCOMDelta = .optionDefectKindDCOMDelta.Text

            versionEMFull = .optionVersionEMFull.Text
            passedEMFull = .optionPassedEMFull.Text
            failedEMFull = .optionFailedEMFull.Text
            ptIdEMFull = .optionPtIdEMFull.Text
            ptStateEMFull = .optionPtStateEMFull.Text
            defectIdEMFull = .optionDefectIdEMFull.Text
            defectStateEMFull = .optionDefectStateEMFull.Text
            defectKindEMFull = .optionDefectKindEMFull.Text

            versionEMRegression = .optionVersionEMRegression.Text
            passedEMRegression = .optionPassedEMRegression.Text
            failedEMRegression = .optionFailedEMRegression.Text
            ptIdEMRegression = .optionPtIdEMRegression.Text
            ptStateEMRegression = .optionPtStateEMRegression.Text
            defectIdEMRegression = .optionDefectIdEMRegression.Text
            defectStateEMRegression = .optionDefectStateEMRegression.Text
            defectKindEMRegression = .optionDefectKindEMRegression.Text

            versionEMDelta = .optionVersionEMDelta.Text
            passedEMDelta = .optionPassedEMDelta.Text
            failedEMDelta = .optionFailedEMDelta.Text
            ptIdEMDelta = .optionPtIdEMDelta.Text
            ptStateEMDelta = .optionPtStateEMDelta.Text
            defectIdEMDelta = .optionDefectIdEMDelta.Text
            defectStateEMDelta = .optionDefectStateEMDelta.Text
            defectKindEMDelta = .optionDefectKindEMDelta.Text

            versionCOMFull = .optionVersionCOMFull.Text
            passedCOMFull = .optionPassedCOMFull.Text
            failedCOMFull = .optionFailedCOMFull.Text
            ptIdCOMFull = .optionPtIdCOMFull.Text
            ptStateCOMFull = .optionPtStateCOMFull.Text
            defectIdCOMFull = .optionDefectIdCOMFull.Text
            defectStateCOMFull = .optionDefectStateCOMFull.Text
            defectKindCOMFull = .optionDefectKindCOMFull.Text

            versionCOMRegression = .optionVersionCOMRegression.Text
            passedCOMRegression = .optionPassedCOMRegression.Text
            failedCOMRegression = .optionFailedCOMRegression.Text
            ptIdCOMRegression = .optionPtIdCOMRegression.Text
            ptStateCOMRegression = .optionPtStateCOMRegression.Text
            defectIdCOMRegression = .optionDefectIdCOMRegression.Text
            defectStateCOMRegression = .optionDefectStateCOMRegression.Text
            defectKindCOMRegression = .optionDefectKindCOMRegression.Text

            versionCOMDelta = .optionVersionCOMDelta.Text
            passedCOMDelta = .optionPassedCOMDelta.Text
            failedCOMDelta = .optionFailedCOMDelta.Text
            ptIdCOMDelta = .optionPtIdCOMDelta.Text
            ptStateCOMDelta = .optionPtStateCOMDelta.Text
            defectIdCOMDelta = .optionDefectIdCOMDelta.Text
            defectStateCOMDelta = .optionDefectStateCOMDelta.Text
            defectKindCOMDelta = .optionDefectKindCOMDelta.Text

            versionLDWFull = .optionVersionLDWFull.Text
            passedLDWFull = .optionPassedLDWFull.Text
            failedLDWFull = .optionFailedLDWFull.Text
            ptIdLDWFull = .optionPtIdLDWFull.Text
            ptStateLDWFull = .optionPtStateLDWFull.Text
            defectIdLDWFull = .optionDefectIdLDWFull.Text
            defectStateLDWFull = .optionDefectStateLDWFull.Text
            defectKindLDWFull = .optionDefectKindLDWFull.Text

            versionLDWRegression = .optionVersionLDWRegression.Text
            passedLDWRegression = .optionPassedLDWRegression.Text
            failedLDWRegression = .optionFailedLDWRegression.Text
            ptIdLDWRegression = .optionPtIdLDWRegression.Text
            ptStateLDWRegression = .optionPtStateLDWRegression.Text
            defectIdLDWRegression = .optionDefectIdLDWRegression.Text
            defectStateLDWRegression = .optionDefectStateLDWRegression.Text
            defectKindLDWRegression = .optionDefectKindLDWRegression.Text

            versionLDWDelta = .optionVersionLDWDelta.Text
            passedLDWDelta = .optionPassedLDWDelta.Text
            failedLDWDelta = .optionFailedLDWDelta.Text
            ptIdLDWDelta = .optionPtIdLDWDelta.Text
            ptStateLDWDelta = .optionPtStateLDWDelta.Text
            defectIdLDWDelta = .optionDefectIdLDWDelta.Text
            defectStateLDWDelta = .optionDefectStateLDWDelta.Text
            defectKindLDWDelta = .optionDefectKindLDWDelta.Text

            versionLKSFull = .optionVersionLKSFull.Text
            passedLKSFull = .optionPassedLKSFull.Text
            failedLKSFull = .optionFailedLKSFull.Text
            ptIdLKSFull = .optionPtIdLKSFull.Text
            ptStateLKSFull = .optionPtStateLKSFull.Text
            defectIdLKSFull = .optionDefectIdLKSFull.Text
            defectStateLKSFull = .optionDefectStateLKSFull.Text
            defectKindLKSFull = .optionDefectKindLKSFull.Text

            versionLKSRegression = .optionVersionLKSRegression.Text
            passedLKSRegression = .optionPassedLKSRegression.Text
            failedLKSRegression = .optionFailedLKSRegression.Text
            ptIdLKSRegression = .optionPtIdLKSRegression.Text
            ptStateLKSRegression = .optionPtStateLKSRegression.Text
            defectIdLKSRegression = .optionDefectIdLKSRegression.Text
            defectStateLKSRegression = .optionDefectStateLKSRegression.Text
            defectKindLKSRegression = .optionDefectKindLKSRegression.Text

            versionLKSDelta = .optionVersionLKSDelta.Text
            passedLKSDelta = .optionPassedLKSDelta.Text
            failedLKSDelta = .optionFailedLKSDelta.Text
            ptIdLKSDelta = .optionPtIdLKSDelta.Text
            ptStateLKSDelta = .optionPtStateLKSDelta.Text
            defectIdLKSDelta = .optionDefectIdLKSDelta.Text
            defectStateLKSDelta = .optionDefectStateLKSDelta.Text
            defectKindLKSDelta = .optionDefectKindLKSDelta.Text

            versionRDPFull = .optionVersionRDPFull.Text
            passedRDPFull = .optionPassedRDPFull.Text
            failedRDPFull = .optionFailedRDPFull.Text
            ptIdRDPFull = .optionPtIdRDPFull.Text
            ptStateRDPFull = .optionPtStateRDPFull.Text
            defectIdRDPFull = .optionDefectIdRDPFull.Text
            defectStateRDPFull = .optionDefectStateRDPFull.Text
            defectKindRDPFull = .optionDefectKindRDPFull.Text

            versionRDPRegression = .optionVersionRDPRegression.Text
            passedRDPRegression = .optionPassedRDPRegression.Text
            failedRDPRegression = .optionFailedRDPRegression.Text
            ptIdRDPRegression = .optionPtIdRDPRegression.Text
            ptStateRDPRegression = .optionPtStateRDPRegression.Text
            defectIdRDPRegression = .optionDefectIdRDPRegression.Text
            defectStateRDPRegression = .optionDefectStateRDPRegression.Text
            defectKindRDPRegression = .optionDefectKindRDPRegression.Text

            versionRDPDelta = .optionVersionRDPDelta.Text
            passedRDPDelta = .optionPassedRDPDelta.Text
            failedRDPDelta = .optionFailedRDPDelta.Text
            ptIdRDPDelta = .optionPtIdRDPDelta.Text
            ptStateRDPDelta = .optionPtStateRDPDelta.Text
            defectIdRDPDelta = .optionDefectIdRDPDelta.Text
            defectStateRDPDelta = .optionDefectStateRDPDelta.Text
            defectKindRDPDelta = .optionDefectKindRDPDelta.Text

            versionELKFull = .optionVersionELKFull.Text
            passedELKFull = .optionPassedELKFull.Text
            failedELKFull = .optionFailedELKFull.Text
            ptIdELKFull = .optionPtIdELKFull.Text
            ptStateELKFull = .optionPtStateELKFull.Text
            defectIdELKFull = .optionDefectIdELKFull.Text
            defectStateELKFull = .optionDefectStateELKFull.Text
            defectKindELKFull = .optionDefectKindELKFull.Text

            versionELKRegression = .optionVersionELKRegression.Text
            passedELKRegression = .optionPassedELKRegression.Text
            failedELKRegression = .optionFailedELKRegression.Text
            ptIdELKRegression = .optionPtIdELKRegression.Text
            ptStateELKRegression = .optionPtStateELKRegression.Text
            defectIdELKRegression = .optionDefectIdELKRegression.Text
            defectStateELKRegression = .optionDefectStateELKRegression.Text
            defectKindELKRegression = .optionDefectKindELKRegression.Text

            versionELKDelta = .optionVersionELKDelta.Text
            passedELKDelta = .optionPassedELKDelta.Text
            failedELKDelta = .optionFailedELKDelta.Text
            ptIdELKDelta = .optionPtIdELKDelta.Text
            ptStateELKDelta = .optionPtStateELKDelta.Text
            defectIdELKDelta = .optionDefectIdELKDelta.Text
            defectStateELKDelta = .optionDefectStateELKDelta.Text
            defectKindELKDelta = .optionDefectKindELKDelta.Text

            versionTJAFull = .optionVersionTJAFull.Text
            passedTJAFull = .optionPassedTJAFull.Text
            failedTJAFull = .optionFailedTJAFull.Text
            ptIdTJAFull = .optionPtIdTJAFull.Text
            ptStateTJAFull = .optionPtStateTJAFull.Text
            defectIdTJAFull = .optionDefectIdTJAFull.Text
            defectStateTJAFull = .optionDefectStateTJAFull.Text
            defectKindTJAFull = .optionDefectKindTJAFull.Text

            versionTJARegression = .optionVersionTJARegression.Text
            passedTJARegression = .optionPassedTJARegression.Text
            failedTJARegression = .optionFailedTJARegression.Text
            ptIdTJARegression = .optionPtIdTJARegression.Text
            ptStateTJARegression = .optionPtStateTJARegression.Text
            defectIdTJARegression = .optionDefectIdTJARegression.Text
            defectStateTJARegression = .optionDefectStateTJARegression.Text
            defectKindTJARegression = .optionDefectKindTJARegression.Text

            versionTJADelta = .optionVersionTJADelta.Text
            passedTJADelta = .optionPassedTJADelta.Text
            failedTJADelta = .optionFailedTJADelta.Text
            ptIdTJADelta = .optionPtIdTJADelta.Text
            ptStateTJADelta = .optionPtStateTJADelta.Text
            defectIdTJADelta = .optionDefectIdTJADelta.Text
            defectStateTJADelta = .optionDefectStateTJADelta.Text
            defectKindTJADelta = .optionDefectKindTJADelta.Text

            versionSLAFull = .optionVersionSLAFull.Text
            passedSLAFull = .optionPassedSLAFull.Text
            failedSLAFull = .optionFailedSLAFull.Text
            ptIdSLAFull = .optionPtIdSLAFull.Text
            ptStateSLAFull = .optionPtStateSLAFull.Text
            defectIdSLAFull = .optionDefectIdSLAFull.Text
            defectStateSLAFull = .optionDefectStateSLAFull.Text
            defectKindSLAFull = .optionDefectKindSLAFull.Text

            versionSLARegression = .optionVersionSLARegression.Text
            passedSLARegression = .optionPassedSLARegression.Text
            failedSLARegression = .optionFailedSLARegression.Text
            ptIdSLARegression = .optionPtIdSLARegression.Text
            ptStateSLARegression = .optionPtStateSLARegression.Text
            defectIdSLARegression = .optionDefectIdSLARegression.Text
            defectStateSLARegression = .optionDefectStateSLARegression.Text
            defectKindSLARegression = .optionDefectKindSLARegression.Text

            versionSLADelta = .optionVersionSLADelta.Text
            passedSLADelta = .optionPassedSLADelta.Text
            failedSLADelta = .optionFailedSLADelta.Text
            ptIdSLADelta = .optionPtIdSLADelta.Text
            ptStateSLADelta = .optionPtStateSLADelta.Text
            defectIdSLADelta = .optionDefectIdSLADelta.Text
            defectStateSLADelta = .optionDefectStateSLADelta.Text
            defectKindSLADelta = .optionDefectKindSLADelta.Text

            versionHMAFull = .optionVersionHMAFull.Text
            passedHMAFull = .optionPassedHMAFull.Text
            failedHMAFull = .optionFailedHMAFull.Text
            ptIdHMAFull = .optionPtIdHMAFull.Text
            ptStateHMAFull = .optionPtStateHMAFull.Text
            defectIdHMAFull = .optionDefectIdHMAFull.Text
            defectStateHMAFull = .optionDefectStateHMAFull.Text
            defectKindHMAFull = .optionDefectKindHMAFull.Text

            versionHMARegression = .optionVersionHMARegression.Text
            passedHMARegression = .optionPassedHMARegression.Text
            failedHMARegression = .optionFailedHMARegression.Text
            ptIdHMARegression = .optionPtIdHMARegression.Text
            ptStateHMARegression = .optionPtStateHMARegression.Text
            defectIdHMARegression = .optionDefectIdHMARegression.Text
            defectStateHMARegression = .optionDefectStateHMARegression.Text
            defectKindHMARegression = .optionDefectKindHMARegression.Text

            versionHMADelta = .optionVersionHMADelta.Text
            passedHMADelta = .optionPassedHMADelta.Text
            failedHMADelta = .optionFailedHMADelta.Text
            ptIdHMADelta = .optionPtIdHMADelta.Text
            ptStateHMADelta = .optionPtStateHMADelta.Text
            defectIdHMADelta = .optionDefectIdHMADelta.Text
            defectStateHMADelta = .optionDefectStateHMADelta.Text
            defectKindHMADelta = .optionDefectKindHMADelta.Text

            versionVehicleFull = .optionVersionVehicleFull.Text
            passedVehicleFull = .optionPassedVehicleFull.Text
            failedVehicleFull = .optionFailedVehicleFull.Text
            ptIdVehicleFull = .optionPtIdVehicleFull.Text
            ptStateVehicleFull = .optionPtStateVehicleFull.Text
            defectIdVehicleFull = .optionDefectIdVehicleFull.Text
            defectStateVehicleFull = .optionDefectStateVehicleFull.Text
            defectKindVehicleFull = .optionDefectKindVehicleFull.Text

            versionVehicleRegression = .optionVersionVehicleRegression.Text
            passedVehicleRegression = .optionPassedVehicleRegression.Text
            failedVehicleRegression = .optionFailedVehicleRegression.Text
            ptIdVehicleRegression = .optionPtIdVehicleRegression.Text
            ptStateVehicleRegression = .optionPtStateVehicleRegression.Text
            defectIdVehicleRegression = .optionDefectIdVehicleRegression.Text
            defectStateVehicleRegression = .optionDefectStateVehicleRegression.Text
            defectKindVehicleRegression = .optionDefectKindVehicleRegression.Text

            versionVehicleDelta = .optionVersionVehicleDelta.Text
            passedVehicleDelta = .optionPassedVehicleDelta.Text
            failedVehicleDelta = .optionFailedVehicleDelta.Text
            ptIdVehicleDelta = .optionPtIdVehicleDelta.Text
            ptStateVehicleDelta = .optionPtStateVehicleDelta.Text
            defectIdVehicleDelta = .optionDefectIdVehicleDelta.Text
            defectStateVehicleDelta = .optionDefectStateVehicleDelta.Text
            defectKindVehicleDelta = .optionDefectKindVehicleDelta.Text

            versionSITFull = .optionVersionSITFull.Text
            passedSITFull = .optionPassedSITFull.Text
            failedSITFull = .optionFailedSITFull.Text
            ptIdSITFull = .optionPtIdSITFull.Text
            ptStateSITFull = .optionPtStateSITFull.Text
            defectIdSITFull = .optionDefectIdSITFull.Text
            defectStateSITFull = .optionDefectStateSITFull.Text
            defectKindSITFull = .optionDefectKindSITFull.Text

            versionSITRegression = .optionVersionSITRegression.Text
            passedSITRegression = .optionPassedSITRegression.Text
            failedSITRegression = .optionFailedSITRegression.Text
            ptIdSITRegression = .optionPtIdSITRegression.Text
            ptStateSITRegression = .optionPtStateSITRegression.Text
            defectIdSITRegression = .optionDefectIdSITRegression.Text
            defectStateSITRegression = .optionDefectStateSITRegression.Text
            defectKindSITRegression = .optionDefectKindSITRegression.Text

            versionSITDelta = .optionVersionSITDelta.Text
            passedSITDelta = .optionPassedSITDelta.Text
            failedSITDelta = .optionFailedSITDelta.Text
            ptIdSITDelta = .optionPtIdSITDelta.Text
            ptStateSITDelta = .optionPtStateSITDelta.Text
            defectIdSITDelta = .optionDefectIdSITDelta.Text
            defectStateSITDelta = .optionDefectStateSITDelta.Text
            defectKindSITDelta = .optionDefectKindSITDelta.Text

            versionSRCheckFull = .optionVersionSRCheckFull.Text
            passedSRCheckFull = .optionPassedSRCheckFull.Text
            failedSRCheckFull = .optionFailedSRCheckFull.Text
            ptIdSRCheckFull = .optionPtIdSRCheckFull.Text
            ptStateSRCheckFull = .optionPtStateSRCheckFull.Text
            defectIdSRCheckFull = .optionDefectIdSRCheckFull.Text
            defectStateSRCheckFull = .optionDefectStateSRCheckFull.Text
            defectKindSRCheckFull = .optionDefectKindSRCheckFull.Text

            versionSRCheckRegression = .optionVersionSRCheckRegression.Text
            passedSRCheckRegression = .optionPassedSRCheckRegression.Text
            failedSRCheckRegression = .optionFailedSRCheckRegression.Text
            ptIdSRCheckRegression = .optionPtIdSRCheckRegression.Text
            ptStateSRCheckRegression = .optionPtStateSRCheckRegression.Text
            defectIdSRCheckRegression = .optionDefectIdSRCheckRegression.Text
            defectStateSRCheckRegression = .optionDefectStateSRCheckRegression.Text
            defectKindSRCheckRegression = .optionDefectKindSRCheckRegression.Text

            versionSRCheckDelta = .optionVersionSRCheckDelta.Text
            passedSRCheckDelta = .optionPassedSRCheckDelta.Text
            failedSRCheckDelta = .optionFailedSRCheckDelta.Text
            ptIdSRCheckDelta = .optionPtIdSRCheckDelta.Text
            ptStateSRCheckDelta = .optionPtStateSRCheckDelta.Text
            defectIdSRCheckDelta = .optionDefectIdSRCheckDelta.Text
            defectStateSRCheckDelta = .optionDefectStateSRCheckDelta.Text
            defectKindSRCheckDelta = .optionDefectKindSRCheckDelta.Text

        End With

        ' Define column and row value for the Database 
        colProject = 2
        colVariant = colProject
        colRelease = colProject
        colVersion = colProject

        colLevelOfTesting = 2
        colDocumentOwner = colLevelOfTesting
        colModifiedBy = colLevelOfTesting
        colTestCoordinator = colLevelOfTesting
        colDocumentVersion = colLevelOfTesting
        colStartDate = colLevelOfTesting
        colEndDate = colLevelOfTesting
        colReleaseDate = colLevelOfTesting

        colDelivery = 2
        colSource = colDelivery
        colCoresi = colDelivery

        colDCOM = 2
        colEM = colDCOM
        colCOM = colDCOM
        colLDW = colDCOM
        colLKS = colDCOM
        colRDP = colDCOM
        colELK = colDCOM
        colTJA = colDCOM
        colSLA = colDCOM
        colHMA = colDCOM
        colVehicle = colDCOM
        colSIT = colDCOM
        colSRCheck = colDCOM

        colAllTestPartFull = colDCOM + 1
        colAllTestPartRegression = colDCOM + 2
        colAllTestPartDelta = colDCOM + 3

        colLabtDCOM = colDCOM + 4
        colLabtEM = colLabtDCOM
        colLabtCOM = colLabtDCOM
        colLabtLDW = colLabtDCOM
        colLabtLKS = colLabtDCOM
        colLabtRDP = colLabtDCOM
        colLabtELK = colLabtDCOM
        colLabtTJA = colLabtDCOM
        colLabtSLA = colLabtDCOM
        colLabtHMA = colLabtDCOM
        colLabtVehicle = colLabtDCOM
        colLabtSIT = colLabtDCOM
        colLabtSRCheck = colLabtDCOM

        colOutputReportLocation = 1

        colVersionAllTestPart = 10
        colPassedAllTestPart = colVersionAllTestPart + 1
        colFailedAllTestPart = colVersionAllTestPart + 2
        colPtIdAllTestPart = colVersionAllTestPart + 3
        colPtStateAllTestPart = colVersionAllTestPart + 4
        colDefectIdAllTestPart = colVersionAllTestPart + 5
        colDefectStateAllTestPart = colVersionAllTestPart + 6
        colDefectKindAllTestPart = colVersionAllTestPart + 7


        rowProject = 2
        rowVariant = rowProject + 1
        rowRelease = rowProject + 2
        rowVersion = rowProject + 3

        rowLevelOfTesting = 7
        rowDocumentOwner = rowLevelOfTesting + 1
        rowModifiedBy = rowLevelOfTesting + 2
        rowTestCoordinator = rowLevelOfTesting + 3
        rowDocumentVersion = rowLevelOfTesting + 4
        rowStartDate = rowLevelOfTesting + 5
        rowEndDate = rowLevelOfTesting + 6
        rowReleaseDate = rowLevelOfTesting + 7

        rowDelivery = 17
        rowSource = rowDelivery + 1
        rowCoresi = rowDelivery + 2

        rowDCOM = 22
        rowEM = rowDCOM + 1
        rowCOM = rowDCOM + 2
        rowLDW = rowDCOM + 3
        rowLKS = rowDCOM + 4
        rowRDP = rowDCOM + 5
        rowELK = rowDCOM + 6
        rowTJA = rowDCOM + 7
        rowSLA = rowDCOM + 8
        rowHMA = rowDCOM + 9
        rowVehicle = rowDCOM + 10
        rowSIT = rowDCOM + 11
        rowSRCheck = rowDCOM + 12

        rowOutputReportLocation = 37

        rowDCOMFull = 2
        rowDCOMRegression = rowDCOMFull + 1
        rowDCOMDelta = rowDCOMFull + 2
        rowEMFull = rowDCOMFull + 3
        rowEMRegression = rowDCOMFull + 4
        rowEMDelta = rowDCOMFull + 5
        rowCOMFull = rowDCOMFull + 6
        rowCOMRegression = rowDCOMFull + 7
        rowCOMDelta = rowDCOMFull + 8
        rowLDWFull = rowDCOMFull + 9
        rowLDWRegression = rowDCOMFull + 10
        rowLDWDelta = rowDCOMFull + 11
        rowLKSFull = rowDCOMFull + 12
        rowLKSRegression = rowDCOMFull + 13
        rowLKSDelta = rowDCOMFull + 14
        rowRDPFull = rowDCOMFull + 15
        rowRDPRegression = rowDCOMFull + 16
        rowRDPDelta = rowDCOMFull + 17
        rowELKFull = rowDCOMFull + 18
        rowELKRegression = rowDCOMFull + 19
        rowELKDelta = rowDCOMFull + 20
        rowTJAFull = rowDCOMFull + 21
        rowTJARegression = rowDCOMFull + 22
        rowTJADelta = rowDCOMFull + 23
        rowSLAFull = rowDCOMFull + 24
        rowSLARegression = rowDCOMFull + 25
        rowSLADelta = rowDCOMFull + 26
        rowHMAFull = rowDCOMFull + 27
        rowHMARegression = rowDCOMFull + 28
        rowHMADelta = rowDCOMFull + 29
        rowVehicleFull = rowDCOMFull + 30
        rowVehicleRegression = rowDCOMFull + 31
        rowVehicleDelta = rowDCOMFull + 32
        rowSITFull = rowDCOMFull + 33
        rowSITRegression = rowDCOMFull + 34
        rowSITDelta = rowDCOMFull + 35
        rowSRCheckFull = rowDCOMFull + 36
        rowSRCheckRegression = rowDCOMFull + 37
        rowSRCheckDelta = rowDCOMFull + 38



    End Sub


End Class
