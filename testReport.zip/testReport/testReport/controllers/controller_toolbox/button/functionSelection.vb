﻿Public Class functionSelection
    Public Shared tabcontrolFunction As New tabcontrolFunction()
    Public Sub dcomSelection()
        TestReport.Panel28.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 1) ' Parent page
        tabcontrolFunction.childTabPageSelection("dcomFull")
        tabcontrolFunction.childTabPageSelection("dcomDelta")
        tabcontrolFunction.childTabPageSelection("dcomRegression")
    End Sub

    Public Sub emSelection()
        TestReport.Panel29.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 2) ' Parent page
        tabcontrolFunction.childTabPageSelection("emFull")
        tabcontrolFunction.childTabPageSelection("emDelta")
        tabcontrolFunction.childTabPageSelection("emRegression")

    End Sub

    Public Sub comSelection()
        TestReport.Panel30.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 3) ' Parent page
        tabcontrolFunction.childTabPageSelection("comFull")
        tabcontrolFunction.childTabPageSelection("comDelta")
        tabcontrolFunction.childTabPageSelection("comRegression")

    End Sub

    Public Sub ldwSelection()
        TestReport.Panel31.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 4) ' Parent page
        tabcontrolFunction.childTabPageSelection("ldwFull")
        tabcontrolFunction.childTabPageSelection("ldwDelta")
        tabcontrolFunction.childTabPageSelection("ldwRegression")
    End Sub

    Public Sub lksSelection()
        TestReport.Panel32.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 5) ' Parent page
        tabcontrolFunction.childTabPageSelection("lksFull")
        tabcontrolFunction.childTabPageSelection("lksDelta")
        tabcontrolFunction.childTabPageSelection("lksRegression")
    End Sub

    Public Sub rdpSelection()
        TestReport.Panel33.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 6) ' Parent page
        tabcontrolFunction.childTabPageSelection("rdpFull")
        tabcontrolFunction.childTabPageSelection("rdpDelta")
        tabcontrolFunction.childTabPageSelection("rdpRegression")
    End Sub

    Public Sub elkSelection()
        TestReport.Panel34.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 7) ' Parent page
        tabcontrolFunction.childTabPageSelection("elkFull")
        tabcontrolFunction.childTabPageSelection("elkDelta")
        tabcontrolFunction.childTabPageSelection("elkRegression")

    End Sub

    Public Sub tjaSelection()
        TestReport.Panel35.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 8) ' Parent page
        tabcontrolFunction.childTabPageSelection("tjaFull")
        tabcontrolFunction.childTabPageSelection("tjaDelta")
        tabcontrolFunction.childTabPageSelection("tjaRegression")
    End Sub

    Public Sub slaSelection()
        TestReport.Panel36.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 9) ' Parent page
        tabcontrolFunction.childTabPageSelection("slaFull")
        tabcontrolFunction.childTabPageSelection("slaDelta")
        tabcontrolFunction.childTabPageSelection("slaRegression")
    End Sub

    Public Sub hmaSelection()
        TestReport.Panel37.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 10) ' Parent page
        tabcontrolFunction.childTabPageSelection("hmaFull")
        tabcontrolFunction.childTabPageSelection("hmaDelta")
        tabcontrolFunction.childTabPageSelection("hmaRegression")
    End Sub

    Public Sub vehicleSelection()
        TestReport.Panel38.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 11) ' Parent page
        tabcontrolFunction.childTabPageSelection("vehicleFull")
        tabcontrolFunction.childTabPageSelection("vehicleDelta")
        tabcontrolFunction.childTabPageSelection("vehicleRegression")
    End Sub

    Public Sub sitSelection()
        TestReport.Panel39.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 12) ' Parent page
        tabcontrolFunction.childTabPageSelection("sitFull")
        tabcontrolFunction.childTabPageSelection("sitDelta")
        tabcontrolFunction.childTabPageSelection("sitRegression")
    End Sub
    Public Sub srCheckSelection()
        TestReport.Panel40.Visible = True
        tabcontrolFunction.parentTabPageSelection(1, 13) ' Parent page
        tabcontrolFunction.childTabPageSelection("srCheckFull")
        tabcontrolFunction.childTabPageSelection("srCheckDelta")
        tabcontrolFunction.childTabPageSelection("srCheckRegression")
    End Sub
End Class
