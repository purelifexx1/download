﻿Public Class save
    Public Shared variableDeclaration As New variableDeclaration()
    Public Shared model_DBExport As New model_DBExport()
    Public Sub saveGUIInformationButton()
        model_DBExport.model_ExportDataToDB()
    End Sub
End Class
