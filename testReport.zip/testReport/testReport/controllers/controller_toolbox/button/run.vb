﻿Imports Word = Microsoft.Office.Interop.Word
Public Class run
    Public Shared variableDeclaration As New variableDeclaration()
    Public Shared dbDeclaration As New dbDeclaration()
    Public Sub runButton()
        ' Declare variables
        variableDeclaration.assign_variable()
        dbDeclaration.mswordApp.Visible = True

        ' Input all mandatory information to the report
        mandatoryInformation()

        ' Input all scope of the test to the report
        scopeOfTheTest()
        ' Input all test coverage to the report
        testCoverage()
        ' Input all summary information to the report

        ' Input all LabT link to the report
        labTSumary()
        ' Save the test summary report
        dbDeclaration.doc.SaveAs(dbDeclaration.docOutputPath)
        dbDeclaration.mswordApp.quit()
    End Sub

    Public Sub mandatoryInformation()
        With dbDeclaration.doc.Bookmarks

            ' HEADER
            .Item("headerDocumentOwner").Range.Text = variableDeclaration.documentOwner
            .Item("headerProject").Range.Text = variableDeclaration.project
            .Item("headerVariant").Range.Text = variableDeclaration.swVariant
            .Item("headerRelease").Range.Text = variableDeclaration.release
            .Item("headerVersion").Range.Text = variableDeclaration.version

            ' TITLE
            .Item("titleProject").Range.Text = variableDeclaration.project
            .Item("titleVariant").Range.Text = variableDeclaration.swVariant
            .Item("titleRelease").Range.Text = variableDeclaration.release
            .Item("titleVersion").Range.Text = variableDeclaration.version
            .Item("titleReleaseDate").Range.Text = variableDeclaration.releaseDate

            ' DOCUMENT REVISION HISTORY
            .Item("historyReleaseDate").Range.Text = variableDeclaration.releaseDate
            .Item("historyChangedBy").Range.Text = variableDeclaration.modifiedBy
            .Item("historyRelease").Range.Text = variableDeclaration.release
            .Item("historyVersion").Range.Text = variableDeclaration.version

            ' TEST PROFILE
            .Item("profileProject").Range.Text = variableDeclaration.project
            .Item("profileVariant").Range.Text = variableDeclaration.swVariant
            .Item("profileRelease").Range.Text = variableDeclaration.release
            .Item("profileVersion").Range.Text = variableDeclaration.version
            .Item("testingLevel").Range.Text = variableDeclaration.testingLevel
            .Item("profileTestCoordinator").Range.Text = variableDeclaration.testCoordinator

            ' TEST PERIOD
            .Item("startDate").Range.Text = variableDeclaration.startDate
            .Item("endDate").Range.Text = variableDeclaration.endDate
            .Item("version").Range.Text = variableDeclaration.documentVersion

            ' TESTCASE REVIEW
            .Item("tcReviewRelease").Range.Text = variableDeclaration.release
            .Item("tcReviewVersion").Range.Text = variableDeclaration.version

            ' TEST LIST
            .Item("delivery").Range.Text = variableDeclaration.delivery
            .Item("source").Range.Text = variableDeclaration.source
            .Item("coresi").Range.Text = variableDeclaration.coresi

        End With
    End Sub

    Public Sub scopeOfTheTest()
        Dim testScopeList As String
        Dim testPart As String
        Dim testScope As String
        Dim scopeTestID As Integer
        testScopeList = ""
        testPart = ""
        testScope = ""
        For scopeTestID = 1 To 39
            Select Case scopeTestID
                Case 1
                    testPart = "DCOM"
                    testScope = "Full"
                Case 2
                    testPart = "DCOM"
                    testScope = "Regression"
                Case 3
                    testPart = "DCOM"
                    testScope = "Delta"

                Case 4
                    testPart = "EM"
                    testScope = "Full"
                Case 5
                    testPart = "EM"
                    testScope = "Regression"
                Case 6
                    testPart = "EM"
                    testScope = "Delta"

                Case 7
                    testPart = "COM"
                    testScope = "Full"
                Case 8
                    testPart = "COM"
                    testScope = "Regression"
                Case 9
                    testPart = "COM"
                    testScope = "Delta"

                Case 10
                    testPart = "LDW"
                    testScope = "Full"
                Case 11
                    testPart = "LDW"
                    testScope = "Regression"
                Case 12
                    testPart = "LDW"
                    testScope = "Delta"

                Case 13
                    testPart = "LKS"
                    testScope = "Full"
                Case 14
                    testPart = "LKS"
                    testScope = "Regression"
                Case 15
                    testPart = "LKS"
                    testScope = "Delta"

                Case 16
                    testPart = "RDP"
                    testScope = "Full"
                Case 17
                    testPart = "RDP"
                    testScope = "Regression"
                Case 18
                    testPart = "RDP"
                    testScope = "Delta"

                Case 19
                    testPart = "ELK"
                    testScope = "Full"
                Case 20
                    testPart = "ELK"
                    testScope = "Regression"
                Case 21
                    testPart = "ELK"
                    testScope = "Delta"

                Case 22
                    testPart = "TJA"
                    testScope = "Full"
                Case 23
                    testPart = "TJA"
                    testScope = "Regression"
                Case 24
                    testPart = "TJA"
                    testScope = "Delta"

                Case 25
                    testPart = "SLA"
                    testScope = "Full"
                Case 26
                    testPart = "SLA"
                    testScope = "Regression"
                Case 27
                    testPart = "SLA"
                    testScope = "Delta"

                Case 28
                    testPart = "HMA"
                    testScope = "Full"
                Case 29
                    testPart = "HMA"
                    testScope = "Regression"
                Case 30
                    testPart = "HMA"
                    testScope = "Delta"

                Case 31
                    testPart = "Vehicle"
                    testScope = "Full"
                Case 32
                    testPart = "Vehicle"
                    testScope = "Regression"
                Case 33
                    testPart = "Vehicle"
                    testScope = "Delta"

                Case 34
                    testPart = "SIT"
                    testScope = "Full"
                Case 35
                    testPart = "SIT"
                    testScope = "Regression"
                Case 36
                    testPart = "SIT"
                    testScope = "Delta"

                Case 37
                    testPart = "SR Check"
                    testScope = "Full"
                Case 38
                    testPart = "SR Check"
                    testScope = "Regression"
                Case 39
                    testPart = "SR Check"
                    testScope = "Delta"

            End Select
            If scopeTestStateFunction(scopeTestID) = True Then
                testScopeList = testScopeList & "Lab Test of " & testPart & " (" & testScope & " Testing)" & Chr(10)
            End If
        Next
        testScopeList = testScopeList.Substring(0, testScopeList.Length - 1)
        With dbDeclaration.doc.Bookmarks
            .Item("testScopeList").Range.Text = testScopeList
        End With
    End Sub

    Public Sub testCoverage()

        Dim table As Word.Table
        Dim testPart As String
        Dim release As String
        Dim version As String
        Dim passed As String
        Dim failed As String
        Dim defectId As String
        Dim defectKind As String
        Dim rowNum As Integer
        Dim rowNumTemp As Integer
        Dim columnNum As Integer
        Dim testPartState As Boolean
        Dim testPartID As Integer

        Dim optionDCOM() As Boolean = {variableDeclaration.dcomFull, variableDeclaration.dcomRegression, variableDeclaration.dcomDelta}
        Dim optionEM() As Boolean = {variableDeclaration.emFull, variableDeclaration.emRegression, variableDeclaration.emDelta}
        Dim optionCOM() As Boolean = {variableDeclaration.comFull, variableDeclaration.comRegression, variableDeclaration.comDelta}
        Dim optionLDW() As Boolean = {variableDeclaration.ldwFull, variableDeclaration.ldwRegression, variableDeclaration.ldwDelta}
        Dim optionLKS() As Boolean = {variableDeclaration.lksFull, variableDeclaration.lksRegression, variableDeclaration.lksDelta}
        Dim optionRDP() As Boolean = {variableDeclaration.rdpFull, variableDeclaration.rdpRegression, variableDeclaration.rdpDelta}
        Dim optionELK() As Boolean = {variableDeclaration.elkFull, variableDeclaration.elkRegression, variableDeclaration.elkDelta}
        Dim optionTJA() As Boolean = {variableDeclaration.tjaFull, variableDeclaration.tjaRegression, variableDeclaration.tjaDelta}
        Dim optionSLA() As Boolean = {variableDeclaration.slaFull, variableDeclaration.slaRegression, variableDeclaration.slaDelta}
        Dim optionHMA() As Boolean = {variableDeclaration.hmaFull, variableDeclaration.hmaRegression, variableDeclaration.hmaDelta}
        Dim optionVehicle() As Boolean = {variableDeclaration.vehicleFull, variableDeclaration.vehicleRegression, variableDeclaration.vehicleDelta}
        Dim optionSIT() As Boolean = {variableDeclaration.sitFull, variableDeclaration.sitRegression, variableDeclaration.sitDelta}
        Dim optionSRCheck() As Boolean = {variableDeclaration.srCheckFull, variableDeclaration.srCheckRegression, variableDeclaration.srCheckDelta}

        columnNum = 3
        rowNum = 0

        testPart = ""
        release = "R1.0"
        version = "RC01"
        passed = "100"
        failed = "1"
        defectId = ""
        defectKind = ""

        For testPartID = 1 To 13
            Select Case testPartID
                Case 1
                    testPart = "DCOM"
                    rowNum += testCoverageTableRow(optionDCOM, testPart)
                Case 2
                    testPart = "EM"
                    rowNum += testCoverageTableRow(optionEM, testPart)
                Case 3
                    testPart = "COM"
                    rowNum += testCoverageTableRow(optionCOM, testPart)
                Case 4
                    testPart = "LDW"
                    rowNum += testCoverageTableRow(optionLDW, testPart)
                Case 5
                    testPart = "LKS"
                    rowNum += testCoverageTableRow(optionLKS, testPart)
                Case 6
                    testPart = "RDP"
                    rowNum += testCoverageTableRow(optionRDP, testPart)
                Case 7
                    testPart = "ELK"
                    rowNum += testCoverageTableRow(optionELK, testPart)
                Case 8
                    testPart = "TJA"
                    rowNum += testCoverageTableRow(optionTJA, testPart)
                Case 9
                    testPart = "SLA"
                    rowNum += testCoverageTableRow(optionSLA, testPart)
                Case 10
                    testPart = "HMA"
                    rowNum += testCoverageTableRow(optionHMA, testPart)
                Case 11
                    testPart = "Vehicle"
                    rowNum += testCoverageTableRow(optionVehicle, testPart)
                Case 12
                    testPart = "SIT"
                    rowNum += testCoverageTableRow(optionSIT, testPart)
                Case 13
                    testPart = "SRCheck"
                    rowNum += testCoverageTableRow(optionSRCheck, testPart)
            End Select

        Next

        table = dbDeclaration.doc.Tables.Add(dbDeclaration.doc.Bookmarks.Item("testCoverage").Range, rowNum, columnNum)

        rowNumTemp = 0
        For testPartID = 1 To 13
            Select Case testPartID
                Case 1
                    testPartState = variableDeclaration.dcom
                    testPart = "DCOM"
                Case 2
                    testPartState = variableDeclaration.em
                    testPart = "EM"
                Case 3
                    testPartState = variableDeclaration.com
                    testPart = "COM"

                Case 4
                    testPartState = variableDeclaration.ldw
                    testPart = "LDW"
                Case 5
                    testPartState = variableDeclaration.lks
                    testPart = "LKS"
                Case 6
                    testPartState = variableDeclaration.rdp
                    testPart = "RDP"

                Case 7
                    testPartState = variableDeclaration.elk
                    testPart = "ELK"
                Case 8
                    testPartState = variableDeclaration.tja
                    testPart = "TJA"
                Case 9
                    testPartState = variableDeclaration.sla
                    testPart = "SLA"

                Case 10
                    testPartState = variableDeclaration.hma
                    testPart = "HMA"
                Case 11
                    testPartState = variableDeclaration.vehicle
                    testPart = "Vehicle"
                Case 12
                    testPartState = variableDeclaration.sit
                    testPart = "SIT"
                Case 13
                    testPartState = variableDeclaration.srCheck
                    testPart = "SRCheck"
            End Select
            If testPartState = True Then
                rowNumTemp += 4
                With table
                    ' Style
                    .Range.ParagraphFormat.SpaceAfter = 6
                    .Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleSingle
                    .Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle
                    .Columns(1).SetWidth(ColumnWidth:=230, RulerStyle:=Word.WdRulerStyle.wdAdjustFirstColumn)
                    .Columns(2).SetWidth(ColumnWidth:=30, RulerStyle:=Word.WdRulerStyle.wdAdjustFirstColumn)


                    .Cell(rowNumTemp - 3, 1).Range.Font.Color = Word.WdColor.wdColorBlue

                    ' Information
                    .Cell(rowNumTemp - 3, 1).Range.Text = "LabT_" & testPart & "_" & release & "_" & version
                    .Cell(rowNumTemp - 3, 3).Range.Text = "Defect in CSCRM"
                    .Cell(rowNumTemp - 2, 1).Range.Text = "Total number of test cases executed"
                    .Cell(rowNumTemp - 2, 2).Range.Text = Int16.Parse(passed) + Int16.Parse(failed)
                    .Cell(rowNumTemp - 2, 3).Range.Text = defectId & " (" & defectKind & " defect)"
                    .Cell(rowNumTemp - 1, 1).Range.Text = "Passed"
                    .Cell(rowNumTemp - 1, 2).Range.Text = Int16.Parse(passed)
                    .Cell(rowNumTemp, 1).Range.Text = "Failed"
                    .Cell(rowNumTemp, 2).Range.Text = Int16.Parse(failed)


                End With
            End If
        Next

        For temp = 1 To rowNum
            With table
                .Cell(rowNumTemp - 3, 1).Merge(.Cell(rowNumTemp - 3, 2))
                ' .Cell(rowNumTemp - 2, 3).Merge(.Cell(rowNumTemp - 1, 3))
                If rowNumTemp <> 4 Then
                    .Split(.Rows(rowNumTemp - 3))
                    rowNumTemp -= 4
                Else
                    GoTo endsub
                End If
            End With
        Next
endsub:
    End Sub

    Public Sub ticketSummary()

    End Sub

    Public Sub labTSumary()
        Dim labtList As String

        labtList = ""
        With TestReport
            If .optionLabTDCOM.Enabled = True Then
                labtList = labtList & "LabT_DCOM" & Chr(10) & variableDeclaration.labtDCOM & Chr(10) & Chr(10)
            End If
            If .optionLabTEM.Enabled = True Then
                labtList = labtList & "LabT_EM" & Chr(10) & variableDeclaration.labtEM & Chr(10) & Chr(10)
            End If
            If .optionLabTCOM.Enabled = True Then
                labtList = labtList & "LabT_COM" & Chr(10) & variableDeclaration.labtCOM & Chr(10) & Chr(10)
            End If
            If .optionLabTLDW.Enabled = True Then
                labtList = labtList & "LabT_LDW" & Chr(10) & variableDeclaration.labtLDW & Chr(10) & Chr(10)
            End If
            If .optionLabTLKS.Enabled = True Then
                labtList = labtList & "LabT_LKS" & Chr(10) & variableDeclaration.labtLKS & Chr(10) & Chr(10)
            End If
            If .optionLabTRDP.Enabled = True Then
                labtList = labtList & "LabT_RDP" & Chr(10) & variableDeclaration.labtRDP & Chr(10) & Chr(10)
            End If
            If .optionDefectIdELKFull.Enabled = True Then
                labtList = labtList & "LabT_ELK" & Chr(10) & variableDeclaration.labtELK & Chr(10) & Chr(10)
            End If
            If .optionFailedELKFull.Enabled = True Then
                labtList = labtList & "LabT_TJA" & Chr(10) & variableDeclaration.labtTJA & Chr(10) & Chr(10)
            End If
            If .optionLabTSLA.Enabled = True Then
                labtList = labtList & "LabT_SLA" & Chr(10) & variableDeclaration.labtSLA & Chr(10) & Chr(10)
            End If
            If .optionLabTHMA.Enabled = True Then
                labtList = labtList & "LabT_HMA" & Chr(10) & variableDeclaration.labtHMA & Chr(10) & Chr(10)
            End If
            If .optionLabTVehicle.Enabled = True Then
                labtList = labtList & "LabT_Vehicle" & Chr(10) & variableDeclaration.labtVehicle & Chr(10) & Chr(10)
            End If
            If .optionLabTSIT.Enabled = True Then
                labtList = labtList & "SIT_docupedia" & Chr(10) & variableDeclaration.labtSIT & Chr(10) & Chr(10)
            End If
            If .optionLabTSRCheck.Enabled = True Then
                labtList = labtList & "SR Check" & Chr(10) & variableDeclaration.labtSRCheck & Chr(10) & Chr(10)
            End If
        End With

        With dbDeclaration.doc.Bookmarks
            .Item("labtList").Range.Text = labtList
        End With
    End Sub
    Function scopeTestStateFunction(scopeTestID As Integer) As Boolean
        ' Apply in scope of test

        Dim scopeTestState As Boolean
        Dim testPartState As Boolean
        Select Case scopeTestID
            Case 1
                scopeTestState = TestReport.optionDCOMFull.Checked
                testPartState = variableDeclaration.dcom
            Case 2
                scopeTestState = TestReport.optionDCOMRegression.Checked
                testPartState = variableDeclaration.dcom
            Case 3
                scopeTestState = TestReport.optionDCOMDelta.Checked
                testPartState = variableDeclaration.dcom

            Case 4
                scopeTestState = TestReport.optionEMFull.Checked
                testPartState = variableDeclaration.em
            Case 5
                scopeTestState = TestReport.optionEMRegression.Checked
                testPartState = variableDeclaration.em
            Case 6
                scopeTestState = TestReport.optionEMDelta.Checked
                testPartState = variableDeclaration.em

            Case 7
                scopeTestState = TestReport.optionCOMFull.Checked
                testPartState = variableDeclaration.com
            Case 8
                scopeTestState = TestReport.optionCOMRegression.Checked
                testPartState = variableDeclaration.com
            Case 9
                scopeTestState = TestReport.optionCOMDelta.Checked
                testPartState = variableDeclaration.com

            Case 10
                scopeTestState = TestReport.optionLDWFull.Checked
                testPartState = variableDeclaration.ldw
            Case 11
                scopeTestState = TestReport.optionLDWRegression.Checked
                testPartState = variableDeclaration.ldw
            Case 12
                scopeTestState = TestReport.optionLDWDelta.Checked
                testPartState = variableDeclaration.ldw

            Case 13
                scopeTestState = TestReport.optionLKSFull.Checked
                testPartState = variableDeclaration.lks
            Case 14
                scopeTestState = TestReport.optionLKSRegression.Checked
                testPartState = variableDeclaration.lks
            Case 15
                scopeTestState = TestReport.optionLKSDelta.Checked
                testPartState = variableDeclaration.lks

            Case 16
                scopeTestState = TestReport.optionRDPFull.Checked
                testPartState = variableDeclaration.rdp
            Case 17
                scopeTestState = TestReport.optionRDPRegression.Checked
                testPartState = variableDeclaration.rdp
            Case 18
                scopeTestState = TestReport.optionRDPDelta.Checked
                testPartState = variableDeclaration.rdp

            Case 19
                scopeTestState = TestReport.optionELKFull.Checked
                testPartState = variableDeclaration.elk
            Case 20
                scopeTestState = TestReport.optionELKRegression.Checked
                testPartState = variableDeclaration.elk
            Case 21
                scopeTestState = TestReport.optionELKDelta.Checked
                testPartState = variableDeclaration.elk

            Case 22
                scopeTestState = TestReport.optionTJAFull.Checked
                testPartState = variableDeclaration.tja
            Case 23
                scopeTestState = TestReport.optionTJARegression.Checked
                testPartState = variableDeclaration.tja
            Case 24
                scopeTestState = TestReport.optionTJADelta.Checked
                testPartState = variableDeclaration.tja

            Case 25
                scopeTestState = TestReport.optionSLAFull.Checked
                testPartState = variableDeclaration.sla
            Case 26
                scopeTestState = TestReport.optionSLARegression.Checked
                testPartState = variableDeclaration.sla
            Case 27
                scopeTestState = TestReport.optionSLADelta.Checked
                testPartState = variableDeclaration.sla

            Case 28
                scopeTestState = TestReport.optionHMAFull.Checked
                testPartState = variableDeclaration.hma
            Case 29
                scopeTestState = TestReport.optionHMARegression.Checked
                testPartState = variableDeclaration.hma
            Case 30
                scopeTestState = TestReport.optionHMADelta.Checked
                testPartState = variableDeclaration.hma

            Case 31
                scopeTestState = TestReport.optionVehicleFull.Checked
                testPartState = variableDeclaration.vehicle
            Case 32
                scopeTestState = TestReport.optionVehicleRegression.Checked
                testPartState = variableDeclaration.vehicle
            Case 33
                scopeTestState = TestReport.optionVehicleDelta.Checked
                testPartState = variableDeclaration.vehicle

            Case 34
                scopeTestState = TestReport.optionSITFull.Checked
                testPartState = variableDeclaration.sit
            Case 35
                scopeTestState = TestReport.optionSITRegression.Checked
                testPartState = variableDeclaration.sit
            Case 36
                scopeTestState = TestReport.optionSITDelta.Checked
                testPartState = variableDeclaration.sit

            Case 37
                scopeTestState = TestReport.optionSRCheckFull.Checked
                testPartState = variableDeclaration.srCheck
            Case 38
                scopeTestState = TestReport.optionSRCheckRegression.Checked
                testPartState = variableDeclaration.srCheck
            Case 39
                scopeTestState = TestReport.optionSRCheckDelta.Checked
                testPartState = variableDeclaration.srCheck

        End Select

        Return scopeTestState And testPartState
    End Function


    '    Function testPartInfo(testPart As String) As String()
    '        Dim version As String
    '        Dim passed As String
    '        Dim failed As String
    '        Dim defectId As String
    '        Dim defectKind As String

    '        version = ""
    '        passed = ""
    '        failed = ""
    '        defectId = ""
    '        defectKind = ""

    '        With TestReport
    '            Select Case testPart
    '                Case "DCOM"
    '                Case "EM"
    '                Case "COM"
    '                Case "LDW"
    '                Case "LKS"
    '                Case "RDP"
    '                Case "ELK"
    '                Case "TJA"
    '                Case "SLA"
    '                Case "HMA"
    '                Case "Vehicle"
    '                Case "SIT"
    '                Case "SRCheck"

    '            End Select
    '        End With

    '        testPartInfo = {version, passed, failed, defectId, defectKind}
    '    End Function

    Function testCoverageTableRow(inOptionTestPart() As Boolean, inTestPart As String) As Integer
        Dim rowNum As Integer
        Dim testPartState As Boolean
        Dim versionTestScope() As String = {"", "", ""}
        Dim optionTestPart() As Boolean = {inOptionTestPart(0), inOptionTestPart(1), inOptionTestPart(2)}

        rowNum = 0


        Select Case inTestPart
            Case "DCOM"
                testPartState = variableDeclaration.dcom
                versionTestScope(0) = variableDeclaration.versionDCOMFull
                versionTestScope(1) = variableDeclaration.versionDCOMRegression
                versionTestScope(2) = variableDeclaration.versionDCOMDelta
            Case "EM"
                testPartState = variableDeclaration.em
                versionTestScope(0) = variableDeclaration.versionEMFull
                versionTestScope(1) = variableDeclaration.versionEMRegression
                versionTestScope(2) = variableDeclaration.versionEMDelta
            Case "COM"
                testPartState = variableDeclaration.com
                versionTestScope(0) = variableDeclaration.versionCOMFull
                versionTestScope(1) = variableDeclaration.versionCOMRegression
                versionTestScope(2) = variableDeclaration.versionCOMDelta
            Case "LDW"
                testPartState = variableDeclaration.ldw
                versionTestScope(0) = variableDeclaration.versionLDWFull
                versionTestScope(1) = variableDeclaration.versionLDWRegression
                versionTestScope(2) = variableDeclaration.versionLDWDelta
            Case "LKS"
                testPartState = variableDeclaration.lks
                versionTestScope(0) = variableDeclaration.versionLKSFull
                versionTestScope(1) = variableDeclaration.versionLKSRegression
                versionTestScope(2) = variableDeclaration.versionLKSDelta
            Case "RDP"
                testPartState = variableDeclaration.rdp
                versionTestScope(0) = variableDeclaration.versionRDPFull
                versionTestScope(1) = variableDeclaration.versionRDPRegression
                versionTestScope(2) = variableDeclaration.versionRDPDelta
            Case "ELK"
                testPartState = variableDeclaration.elk
                versionTestScope(0) = variableDeclaration.versionELKFull
                versionTestScope(1) = variableDeclaration.versionELKRegression
                versionTestScope(2) = variableDeclaration.versionELKDelta
            Case "TJA"
                testPartState = variableDeclaration.tja
                versionTestScope(0) = variableDeclaration.versionTJAFull
                versionTestScope(1) = variableDeclaration.versionTJARegression
                versionTestScope(2) = variableDeclaration.versionTJADelta
            Case "SLA"
                testPartState = variableDeclaration.sla
                versionTestScope(0) = variableDeclaration.versionSLAFull
                versionTestScope(1) = variableDeclaration.versionSLARegression
                versionTestScope(2) = variableDeclaration.versionSLADelta
            Case "HMA"
                testPartState = variableDeclaration.hma
                versionTestScope(0) = variableDeclaration.versionHMAFull
                versionTestScope(1) = variableDeclaration.versionHMARegression
                versionTestScope(2) = variableDeclaration.versionHMADelta
            Case "Vehicle"
                testPartState = variableDeclaration.vehicle
                versionTestScope(0) = variableDeclaration.versionVehicleFull
                versionTestScope(1) = variableDeclaration.versionVehicleRegression
                versionTestScope(2) = variableDeclaration.versionVehicleDelta
            Case "SIT"
                testPartState = variableDeclaration.sit
                versionTestScope(0) = variableDeclaration.versionSITFull
                versionTestScope(1) = variableDeclaration.versionSITRegression
                versionTestScope(2) = variableDeclaration.versionSITDelta
            Case "SRCheck"
                testPartState = variableDeclaration.srCheck
                versionTestScope(0) = variableDeclaration.versionSRCheckFull
                versionTestScope(1) = variableDeclaration.versionSRCheckRegression
                versionTestScope(2) = variableDeclaration.versionSRCheckDelta

        End Select


        If testPartState = True Then
            If optionTestPart(0) = False And optionTestPart(1) = False And optionTestPart(2) = False Then
                rowNum = rowNum
            ElseIf optionTestPart(0) = False And optionTestPart(1) = False And optionTestPart(2) = True Then
                rowNum += 4
            ElseIf optionTestPart(0) = False And optionTestPart(1) = True And optionTestPart(2) = False Then
                rowNum += 4
            ElseIf optionTestPart(0) = False And optionTestPart(1) = True And optionTestPart(2) = True Then
                If versionTestScope(1) = versionTestScope(2) Then
                    rowNum += 4
                Else
                    rowNum += 8
                End If
            ElseIf optionTestPart(0) = True And optionTestPart(1) = False And optionTestPart(2) = False Then
                rowNum += 4
            ElseIf optionTestPart(0) = True And optionTestPart(1) = False And optionTestPart(2) = True Then
                If versionTestScope(0) = versionTestScope(2) Then
                    rowNum += 4
                Else
                    rowNum += 8
                End If
            ElseIf optionTestPart(0) = True And optionTestPart(1) = True And optionTestPart(2) = False Then
                If versionTestScope(0) = versionTestScope(1) Then
                    rowNum += 4
                Else
                    rowNum += 8
                End If
            ElseIf optionTestPart(0) = True And optionTestPart(1) = True And optionTestPart(2) = True Then
                If versionTestScope(0) = versionTestScope(1) And versionTestScope(1) = versionTestScope(2) Then
                    rowNum += 4
                ElseIf versionTestScope(0) = versionTestScope(1) And versionTestScope(1) <> versionTestScope(2) Then
                    rowNum += 8
                ElseIf versionTestScope(0) <> versionTestScope(1) And versionTestScope(1) = versionTestScope(2) Then
                    rowNum += 8
                ElseIf versionTestScope(0) <> versionTestScope(1) And versionTestScope(1) <> versionTestScope(2) And versionTestScope(0) = versionTestScope(2) Then
                    rowNum += 8
                ElseIf versionTestScope(0) <> versionTestScope(1) And versionTestScope(1) <> versionTestScope(2) And versionTestScope(0) <> versionTestScope(2) Then
                    rowNum += 12
                End If
            End If
        Else
            rowNum = rowNum
        End If

        testCoverageTableRow = rowNum
    End Function
End Class
