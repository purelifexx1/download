﻿Public Class browse
    Public Shared variableDeclaration As New variableDeclaration()


    Public Sub browseFolderButton()
        On Error GoTo err
        Dim folderLocation As FolderBrowserDialog = New FolderBrowserDialog

        With folderLocation
            If .ShowDialog() <> DialogResult.Cancel Then 'Any folder is selected
                TestReport.ouputReportLocation.Text = .SelectedPath
            Else ' else dialog is cancelled
                TestReport.ouputReportLocation.Text = "" ' when cancelled set blank as file path.
            End If
        End With
err:
        Exit Sub
    End Sub
End Class
