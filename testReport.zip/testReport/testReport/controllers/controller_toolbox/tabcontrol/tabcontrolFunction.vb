﻿Public Class tabcontrolFunction
    Public Sub parentTabPageSelection(tabControlID As Integer, tabPageID As Integer)
        Dim tabControl As Object
        Dim tabPage As Object
        tabControl = 0
        tabPage = 0
        With TestReport
            .TabControl1.Visible = True
            Select Case tabControlID
                Case 1
                    tabControl = .TabControl1
                Case 2
                    tabControl = .TabControl2
                Case 3
                    tabControl = .TabControl3
                Case 4
                    tabControl = .TabControl4
                Case 5
                    tabControl = .TabControl5
                Case 6
                    tabControl = .TabControl6
                Case 7
                    tabControl = .TabControl7
                Case 8
                    tabControl = .TabControl8
                Case 9
                    tabControl = .TabControl9
                Case 10
                    tabControl = .TabControl10
                Case 11
                    tabControl = .TabControl11
                Case 12
                    tabControl = .TabControl12
                Case 13
                    tabControl = .TabControl13
                Case 14
                    tabControl = .TabControl14
            End Select
        End With

        ' Select parent tab page
        tabControl.SelectedIndex = tabPageID - 1
    End Sub
    Public Sub childTabPageSelection(childTabPageObject As String)

        Dim enabledState As Boolean
        Dim tabControl As Object
        Dim checkBoxState As Object
        tabControl = 0
        checkBoxState = 0
        With TestReport
            Select Case childTabPageObject
                Case "dcomFull"
                    checkBoxState = TestReport.optionDCOMFull.Checked
                Case "dcomRegression"
                    checkBoxState = TestReport.optionDCOMRegression.Checked
                Case "dcomDelta"
                    checkBoxState = TestReport.optionDCOMDelta.Checked

                Case "emFull"
                    checkBoxState = TestReport.optionEMFull.Checked
                Case "emRegression"
                    checkBoxState = TestReport.optionEMRegression.Checked
                Case "emDelta"
                    checkBoxState = TestReport.optionEMDelta.Checked

                Case "comFull"
                    checkBoxState = TestReport.optionCOMFull.Checked
                Case "comRegression"
                    checkBoxState = TestReport.optionCOMRegression.Checked
                Case "comDelta"
                    checkBoxState = TestReport.optionCOMDelta.Checked

                Case "ldwFull"
                    checkBoxState = TestReport.optionLDWFull.Checked
                Case "ldwRegression"
                    checkBoxState = TestReport.optionLDWRegression.Checked
                Case "ldwDelta"
                    checkBoxState = TestReport.optionLDWDelta.Checked

                Case "lksFull"
                    checkBoxState = TestReport.optionLKSFull.Checked
                Case "lksRegression"
                    checkBoxState = TestReport.optionLKSRegression.Checked
                Case "lksDelta"
                    checkBoxState = TestReport.optionLKSDelta.Checked

                Case "rdpFull"
                    checkBoxState = TestReport.optionRDPFull.Checked
                Case "rdpRegression"
                    checkBoxState = TestReport.optionRDPRegression.Checked
                Case "rdpDelta"
                    checkBoxState = TestReport.optionRDPDelta.Checked

                Case "elkFull"
                    checkBoxState = TestReport.optionELKFull.Checked
                Case "elkRegression"
                    checkBoxState = TestReport.optionELKRegression.Checked
                Case "elkDelta"
                    checkBoxState = TestReport.optionELKDelta.Checked

                Case "tjaFull"
                    checkBoxState = TestReport.optionTJAFull.Checked
                Case "tjaRegression"
                    checkBoxState = TestReport.optionTJARegression.Checked
                Case "tjaDelta"
                    checkBoxState = TestReport.optionTJADelta.Checked

                Case "slaFull"
                    checkBoxState = TestReport.optionSLAFull.Checked
                Case "slaRegression"
                    checkBoxState = TestReport.optionSLARegression.Checked
                Case "slaDelta"
                    checkBoxState = TestReport.optionSLADelta.Checked

                Case "hmaFull"
                    checkBoxState = TestReport.optionHMAFull.Checked
                Case "hmaRegression"
                    checkBoxState = TestReport.optionHMARegression.Checked
                Case "hmaDelta"
                    checkBoxState = TestReport.optionHMADelta.Checked

                Case "vehicleFull"
                    checkBoxState = TestReport.optionVehicleFull.Checked
                Case "vehicleRegression"
                    checkBoxState = TestReport.optionVehicleRegression.Checked
                Case "vehicleDelta"
                    checkBoxState = TestReport.optionVehicleDelta.Checked

                Case "sitFull"
                    checkBoxState = TestReport.optionSITFull.Checked
                Case "sitRegression"
                    checkBoxState = TestReport.optionSITRegression.Checked
                Case "sitDelta"
                    checkBoxState = TestReport.optionSITDelta.Checked

                Case "srCheckFull"
                    checkBoxState = TestReport.optionSRCheckFull.Checked
                Case "srCheckRegression"
                    checkBoxState = TestReport.optionSRCheckRegression.Checked
                Case "srCheckDelta"
                    checkBoxState = TestReport.optionSRCheckDelta.Checked

            End Select

            If checkBoxState = True Then
                enabledState = True
            Else
                enabledState = False
            End If

            Select Case childTabPageObject
                Case "dcomFull"
                    .TabControl2.TabPages(0).Enabled = enabledState
                    .TabControl2.SelectedIndex = 0
                    .optionLabTDCOM.Enabled = enabledState
                Case "dcomRegression"
                    .TabControl2.TabPages(1).Enabled = enabledState
                    .TabControl2.SelectedIndex = 1
                    .optionLabTDCOM.Enabled = enabledState
                Case "dcomDelta"
                    .TabControl2.TabPages(2).Enabled = enabledState
                    .TabControl2.SelectedIndex = 2
                    .optionLabTDCOM.Enabled = enabledState

                Case "emFull"
                    .TabControl3.TabPages(0).Enabled = enabledState
                    .TabControl3.SelectedIndex = 0
                    .optionLabTEM.Enabled = enabledState
                Case "emRegression"
                    .TabControl3.TabPages(1).Enabled = enabledState
                    .TabControl3.SelectedIndex = 1
                    .optionLabTEM.Enabled = enabledState
                Case "emDelta"
                    .TabControl3.TabPages(2).Enabled = enabledState
                    .TabControl3.SelectedIndex = 2
                    .optionLabTEM.Enabled = enabledState

                Case "comFull"
                    .TabControl4.TabPages(0).Enabled = enabledState
                    .TabControl4.SelectedIndex = 0
                    .optionLabTCOM.Enabled = enabledState
                Case "comRegression"
                    .TabControl4.TabPages(1).Enabled = enabledState
                    .TabControl4.SelectedIndex = 1
                    .optionLabTCOM.Enabled = enabledState
                Case "comDelta"
                    .TabControl4.TabPages(2).Enabled = enabledState
                    .TabControl4.SelectedIndex = 2
                    .optionLabTCOM.Enabled = enabledState

                Case "ldwFull"
                    .TabControl5.TabPages(0).Enabled = enabledState
                    .TabControl5.SelectedIndex = 0
                    .optionLabTLDW.Enabled = enabledState
                Case "ldwRegression"
                    .TabControl5.TabPages(1).Enabled = enabledState
                    .TabControl5.SelectedIndex = 1
                    .optionLabTLDW.Enabled = enabledState
                Case "ldwDelta"
                    .TabControl5.TabPages(2).Enabled = enabledState
                    .TabControl5.SelectedIndex = 2
                    .optionLabTLDW.Enabled = enabledState

                Case "lksFull"
                    .TabControl6.TabPages(0).Enabled = enabledState
                    .TabControl6.SelectedIndex = 0
                    .optionLabTLKS.Enabled = enabledState
                Case "lksRegression"
                    .TabControl6.TabPages(1).Enabled = enabledState
                    .TabControl6.SelectedIndex = 1
                    .optionLabTLKS.Enabled = enabledState
                Case "lksDelta"
                    .TabControl6.TabPages(2).Enabled = enabledState
                    .TabControl6.SelectedIndex = 2
                    .optionLabTLKS.Enabled = enabledState

                Case "rdpFull"
                    .TabControl7.TabPages(0).Enabled = enabledState
                    .TabControl7.SelectedIndex = 0
                    .optionLabTRDP.Enabled = enabledState
                Case "rdpRegression"
                    .TabControl7.TabPages(1).Enabled = enabledState
                    .TabControl7.SelectedIndex = 1
                    .optionLabTRDP.Enabled = enabledState
                Case "rdpDelta"
                    .TabControl7.TabPages(2).Enabled = enabledState
                    .TabControl7.SelectedIndex = 2
                    .optionLabTRDP.Enabled = enabledState

                Case "elkFull"
                    .TabControl8.TabPages(0).Enabled = enabledState
                    .TabControl8.SelectedIndex = 0
                    .optionLabTELK.Enabled = enabledState
                Case "elkRegression"
                    .TabControl8.TabPages(1).Enabled = enabledState
                    .TabControl8.SelectedIndex = 1
                    .optionLabTELK.Enabled = enabledState
                Case "elkDelta"
                    .TabControl8.TabPages(2).Enabled = enabledState
                    .TabControl8.SelectedIndex = 2
                    .optionLabTELK.Enabled = enabledState

                Case "tjaFull"
                    .TabControl9.TabPages(0).Enabled = enabledState
                    .TabControl9.SelectedIndex = 0
                    .optionFailedELKFull.Enabled = enabledState

                Case "tjaRegression"
                    .TabControl9.TabPages(1).Enabled = enabledState
                    .TabControl9.SelectedIndex = 1
                    .optionFailedELKFull.Enabled = enabledState
                Case "tjaDelta"
                    .TabControl9.TabPages(2).Enabled = enabledState
                    .TabControl9.SelectedIndex = 2
                    .optionFailedELKFull.Enabled = enabledState

                Case "slaFull"
                    .TabControl10.TabPages(0).Enabled = enabledState
                    .TabControl10.SelectedIndex = 0
                    .optionLabTSLA.Enabled = enabledState
                Case "slaRegression"
                    .TabControl10.TabPages(1).Enabled = enabledState
                    .TabControl10.SelectedIndex = 1
                    .optionLabTSLA.Enabled = enabledState
                Case "slaDelta"
                    .TabControl10.TabPages(2).Enabled = enabledState
                    .TabControl10.SelectedIndex = 2
                    .optionLabTSLA.Enabled = enabledState

                Case "hmaFull"
                    .TabControl11.TabPages(0).Enabled = enabledState
                    .TabControl11.SelectedIndex = 0
                    .optionLabTHMA.Enabled = enabledState
                Case "hmaRegression"
                    .TabControl11.TabPages(1).Enabled = enabledState
                    .TabControl11.SelectedIndex = 1
                    .optionLabTHMA.Enabled = enabledState
                Case "hmaDelta"
                    .TabControl11.TabPages(2).Enabled = enabledState
                    .TabControl11.SelectedIndex = 2
                    .optionLabTHMA.Enabled = enabledState

                Case "vehicleFull"
                    .TabControl12.TabPages(0).Enabled = enabledState
                    .TabControl12.SelectedIndex = 0
                    .optionLabTVehicle.Enabled = enabledState
                Case "vehicleRegression"
                    .TabControl12.TabPages(1).Enabled = enabledState
                    .TabControl12.SelectedIndex = 1
                    .optionLabTVehicle.Enabled = enabledState
                Case "vehicleDelta"
                    .TabControl12.TabPages(2).Enabled = enabledState
                    .TabControl12.SelectedIndex = 2
                    .optionLabTVehicle.Enabled = enabledState

                Case "sitFull"
                    .TabControl13.TabPages(0).Enabled = enabledState
                    .TabControl13.SelectedIndex = 0
                    .optionLabTSIT.Enabled = enabledState
                Case "sitRegression"
                    .TabControl13.TabPages(1).Enabled = enabledState
                    .TabControl13.SelectedIndex = 1
                    .optionLabTSIT.Enabled = enabledState
                Case "sitDelta"
                    .TabControl13.TabPages(2).Enabled = enabledState
                    .TabControl13.SelectedIndex = 2
                    .optionLabTSIT.Enabled = enabledState

                Case "srCheckFull"
                    .TabControl14.TabPages(0).Enabled = enabledState
                    .TabControl14.SelectedIndex = 0
                    .optionLabTSRCheck.Enabled = enabledState
                Case "srCheckRegression"
                    .TabControl14.TabPages(1).Enabled = enabledState
                    .TabControl14.SelectedIndex = 1
                    .optionLabTSRCheck.Enabled = enabledState
                Case "srCheckDelta"
                    .TabControl14.TabPages(2).Enabled = enabledState
                    .TabControl14.SelectedIndex = 2
                    .optionLabTSRCheck.Enabled = enabledState
            End Select

        End With


    End Sub
    Public Sub childTabPageDisable(index As Integer)
        Dim tabControl As Object
        Dim textBox As Object

        tabControl = 0
        textBox = 0
        Select Case index
            Case 1
                tabControl = TestReport.TabControl2
                textBox = TestReport.optionLabTDCOM
            Case 2
                tabControl = TestReport.TabControl3
                textBox = TestReport.optionLabTEM
            Case 3
                tabControl = TestReport.TabControl4
                textBox = TestReport.optionLabTCOM
            Case 4
                tabControl = TestReport.TabControl5
                textBox = TestReport.optionLabTLDW
            Case 5
                tabControl = TestReport.TabControl6
                textBox = TestReport.optionLabTLKS
            Case 6
                tabControl = TestReport.TabControl7
                textBox = TestReport.optionLabTRDP
            Case 7
                tabControl = TestReport.TabControl8
                textBox = TestReport.optionLabTELK
            Case 8
                tabControl = TestReport.TabControl9
                textBox = TestReport.optionFailedELKFull
            Case 9
                tabControl = TestReport.TabControl10
                textBox = TestReport.optionLabTSLA
            Case 10
                tabControl = TestReport.TabControl11
                textBox = TestReport.optionLabTHMA
            Case 11
                tabControl = TestReport.TabControl12
                textBox = TestReport.optionLabTVehicle
            Case 12
                tabControl = TestReport.TabControl13
                textBox = TestReport.optionLabTSIT
            Case 13
                tabControl = TestReport.TabControl14
                textBox = TestReport.optionLabTSRCheck
        End Select

        tabControl.TabPages(0).Enabled = False
        tabControl.TabPages(1).Enabled = False
        tabControl.TabPages(2).Enabled = False
        textBox.Enabled = False

    End Sub
    Public Sub hideParentTabControl()
        Dim index As Integer
        Dim checkBox As Boolean
        Dim cnt As Integer
        index = 0
        checkBox = 0
        cnt = 0
        With TestReport
            For index = 1 To 13
                Select Case index
                    Case 1
                        checkBox = .swDCOM.Checked
                    Case 2
                        checkBox = .swEM.Checked
                    Case 3
                        checkBox = .swCOM.Checked
                    Case 4
                        checkBox = .swLDW.Checked
                    Case 5
                        checkBox = .swLKS.Checked
                    Case 6
                        checkBox = .swRDP.Checked
                    Case 7
                        checkBox = .swELK.Checked
                    Case 8
                        checkBox = .swTJA.Checked
                    Case 9
                        checkBox = .swSLA.Checked
                    Case 10
                        checkBox = .swHMA.Checked
                    Case 11
                        checkBox = .swVehicle.Checked
                    Case 12
                        checkBox = .swSIT.Checked
                    Case 13
                        checkBox = .swSRCheck.Checked

                End Select

                If checkBox = True Then
                    cnt = cnt + 1
                End If
            Next

            If cnt = 0 Then
                .TabControl1.Visible = False
            End If

        End With

    End Sub


End Class
