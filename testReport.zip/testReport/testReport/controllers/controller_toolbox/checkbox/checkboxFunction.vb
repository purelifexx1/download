﻿Public Class checkboxFunction

    Public Shared tabcontrolFunction As New tabcontrolFunction()
    Public Sub checkboxBehavior(index As Integer)
        Dim checkbox As Object
        Dim panel As Object
        Dim optionPanel As Object
        checkbox = 0
        panel = 0
        optionPanel = 0

        With TestReport
            Select Case index
                Case 1
                    checkbox = .swDCOM
                    panel = .Panel15
                    optionPanel = .Panel28
                Case 2
                    checkbox = .swEM
                    panel = .Panel16
                    optionPanel = .Panel29
                Case 3
                    checkbox = .swCOM
                    panel = .Panel17
                    optionPanel = .Panel30
                Case 4
                    checkbox = .swLDW
                    panel = .Panel18
                    optionPanel = .Panel31
                Case 5
                    checkbox = .swLKS
                    panel = .Panel19
                    optionPanel = .Panel32
                Case 6
                    checkbox = .swRDP
                    panel = .Panel20
                    optionPanel = .Panel33
                Case 7
                    checkbox = .swELK
                    panel = .Panel21
                    optionPanel = .Panel34
                Case 8
                    checkbox = .swTJA
                    panel = .Panel22
                    optionPanel = .Panel35
                Case 9
                    checkbox = .swSLA
                    panel = .Panel23
                    optionPanel = .Panel36
                Case 10
                    checkbox = .swHMA
                    panel = .Panel24
                    optionPanel = .Panel37
                Case 11
                    checkbox = .swVehicle
                    panel = .Panel25
                    optionPanel = .Panel38
                Case 12
                    checkbox = .swSIT
                    panel = .Panel26
                    optionPanel = .Panel39
                Case 13
                    checkbox = .swSRCheck
                    panel = .Panel27
                    optionPanel = .Panel40
            End Select
        End With

        tabcontrolFunction.childTabPageDisable(index)
        If checkbox.checked = True Then
            panel.Visible = True
            optionPanel.visible = False
        Else
            panel.Visible = False
            tabcontrolFunction.hideParentTabControl()
        End If


    End Sub
End Class
