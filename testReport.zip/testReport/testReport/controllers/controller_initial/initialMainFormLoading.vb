﻿Public Class initialMainFormLoading
    Public Shared variableDeclaration As New variableDeclaration()
    Public Shared checkboxFunction As New checkboxFunction()
    Public Shared model_DBImport As New model_DBImport()

    Public Sub initialMainFormLoading()

        checkboxFunction.checkboxBehavior(1)
        checkboxFunction.checkboxBehavior(2)
        checkboxFunction.checkboxBehavior(3)
        checkboxFunction.checkboxBehavior(4)
        checkboxFunction.checkboxBehavior(5)
        checkboxFunction.checkboxBehavior(6)
        checkboxFunction.checkboxBehavior(7)
        checkboxFunction.checkboxBehavior(8)
        checkboxFunction.checkboxBehavior(9)
        checkboxFunction.checkboxBehavior(10)
        checkboxFunction.checkboxBehavior(11)
        checkboxFunction.checkboxBehavior(12)
        checkboxFunction.checkboxBehavior(13)

        With TestReport

            initialComboBoxList()

            .TabControl1.Visible = False


            .terminal.Text = "Hello world!" & Chr(10) & "Hello world!" & Chr(10) & "Hello world!" & Chr(10) & "Hello world!" & Chr(10) & "Hello world!" & Chr(10)
        End With


    End Sub

    Public Sub initialComboBoxList()

        Dim projectIndex As Integer
        Dim versionIndex As Integer
        Dim levelOfTestingIndex As Integer
        Dim testCoordinatorIndex As Integer
        Dim ptStateIndex As Integer
        Dim defectKindIndex As Integer
        Dim defectStateIndex As Integer

        Dim projectNum As Integer = 1
        Dim versionNum As Integer = 40
        Dim levelOfTestingNum As Integer = 1
        Dim testCoordinatorNum As Integer = 1
        Dim ptStateNum As Integer = 39
        Dim defectKindNum As Integer = 39
        Dim defectStateNum As Integer = 39

        Dim projectList As Object
        Dim versionList As Object
        Dim levelOfTestingList As Object
        Dim testCoordinatorList As Object
        Dim ptStateList As Object
        Dim defectKindList As Object
        Dim defectStateList As Object

        Dim projectID() As Object = {
            TestReport.swProject
        }

        Dim versionID() As Object = {
            TestReport.swVersion,
            TestReport.optionVersionDCOMFull,
            TestReport.optionVersionDCOMRegression,
            TestReport.optionVersionDCOMDelta,
            TestReport.optionVersionEMFull,
            TestReport.optionVersionEMRegression,
            TestReport.optionVersionEMDelta,
            TestReport.optionVersionCOMFull,
            TestReport.optionVersionCOMRegression,
            TestReport.optionVersionCOMDelta,
            TestReport.optionVersionLDWFull,
            TestReport.optionVersionLDWRegression,
            TestReport.optionVersionLDWDelta,
            TestReport.optionVersionLKSFull,
            TestReport.optionVersionLKSRegression,
            TestReport.optionVersionLKSDelta,
            TestReport.optionVersionRDPFull,
            TestReport.optionVersionRDPRegression,
            TestReport.optionVersionRDPDelta,
            TestReport.optionVersionELKFull,
            TestReport.optionVersionELKRegression,
            TestReport.optionVersionELKDelta,
            TestReport.optionVersionTJAFull,
            TestReport.optionVersionTJARegression,
            TestReport.optionVersionTJADelta,
            TestReport.optionVersionSLAFull,
            TestReport.optionVersionSLARegression,
            TestReport.optionVersionSLADelta,
            TestReport.optionVersionHMAFull,
            TestReport.optionVersionHMARegression,
            TestReport.optionVersionHMADelta,
            TestReport.optionVersionVehicleFull,
            TestReport.optionVersionVehicleRegression,
            TestReport.optionVersionVehicleDelta,
            TestReport.optionVersionSITFull,
            TestReport.optionVersionSITRegression,
            TestReport.optionVersionSITDelta,
            TestReport.optionVersionSRCheckFull,
            TestReport.optionVersionSRCheckRegression,
            TestReport.optionVersionSRCheckDelta
        }

        Dim levelOfTestingID() As Object = {
            TestReport.levelOfTesting
        }

        Dim testCoordinatorID() As Object = {
            TestReport.testCoordinator
        }

        Dim ptStateID() As Object = {
            TestReport.optionPtStateDCOMFull,
            TestReport.optionPtStateDCOMRegression,
            TestReport.optionPtStateDCOMDelta,
            TestReport.optionPtStateEMFull,
            TestReport.optionPtStateEMRegression,
            TestReport.optionPtStateEMDelta,
            TestReport.optionPtStateCOMFull,
            TestReport.optionPtStateCOMRegression,
            TestReport.optionPtStateCOMDelta,
            TestReport.optionPtStateLDWFull,
            TestReport.optionPtStateLDWRegression,
            TestReport.optionPtStateLDWDelta,
            TestReport.optionPtStateLKSFull,
            TestReport.optionPtStateLKSRegression,
            TestReport.optionPtStateLKSDelta,
            TestReport.optionPtStateRDPFull,
            TestReport.optionPtStateRDPRegression,
            TestReport.optionPtStateRDPDelta,
            TestReport.optionPtStateELKFull,
            TestReport.optionPtStateELKRegression,
            TestReport.optionPtStateELKDelta,
            TestReport.optionPtStateTJAFull,
            TestReport.optionPtStateTJARegression,
            TestReport.optionPtStateTJADelta,
            TestReport.optionPtStateSLAFull,
            TestReport.optionPtStateSLARegression,
            TestReport.optionPtStateSLADelta,
            TestReport.optionPtStateHMAFull,
            TestReport.optionPtStateHMARegression,
            TestReport.optionPtStateHMADelta,
            TestReport.optionPtStateVehicleFull,
            TestReport.optionPtStateVehicleRegression,
            TestReport.optionPtStateVehicleDelta,
            TestReport.optionPtStateSITFull,
            TestReport.optionPtStateSITRegression,
            TestReport.optionPtStateSITDelta,
            TestReport.optionPtStateSRCheckFull,
            TestReport.optionPtStateSRCheckRegression,
            TestReport.optionPtStateSRCheckDelta
        }

        Dim defectStateID() As Object = {
            TestReport.optionDefectStateDCOMFull,
            TestReport.optionDefectStateDCOMRegression,
            TestReport.optionDefectStateDCOMDelta,
            TestReport.optionDefectStateEMFull,
            TestReport.optionDefectStateEMRegression,
            TestReport.optionDefectStateEMDelta,
            TestReport.optionDefectStateCOMFull,
            TestReport.optionDefectStateCOMRegression,
            TestReport.optionDefectStateCOMDelta,
            TestReport.optionDefectStateLDWFull,
            TestReport.optionDefectStateLDWRegression,
            TestReport.optionDefectStateLDWDelta,
            TestReport.optionDefectStateLKSFull,
            TestReport.optionDefectStateLKSRegression,
            TestReport.optionDefectStateLKSDelta,
            TestReport.optionDefectStateRDPFull,
            TestReport.optionDefectStateRDPRegression,
            TestReport.optionDefectStateRDPDelta,
            TestReport.optionDefectStateELKFull,
            TestReport.optionDefectStateELKRegression,
            TestReport.optionDefectStateELKDelta,
            TestReport.optionDefectStateTJAFull,
            TestReport.optionDefectStateTJARegression,
            TestReport.optionDefectStateTJADelta,
            TestReport.optionDefectStateSLAFull,
            TestReport.optionDefectStateSLARegression,
            TestReport.optionDefectStateSLADelta,
            TestReport.optionDefectStateHMAFull,
            TestReport.optionDefectStateHMARegression,
            TestReport.optionDefectStateHMADelta,
            TestReport.optionDefectStateVehicleFull,
            TestReport.optionDefectStateVehicleRegression,
            TestReport.optionDefectStateVehicleDelta,
            TestReport.optionDefectStateSITFull,
            TestReport.optionDefectStateSITRegression,
            TestReport.optionDefectStateSITDelta,
            TestReport.optionDefectStateSRCheckFull,
            TestReport.optionDefectStateSRCheckRegression,
            TestReport.optionDefectStateSRCheckDelta
        }

        Dim defectKindID() As Object = {
            TestReport.optionDefectKindDCOMFull,
            TestReport.optionDefectKindDCOMRegression,
            TestReport.optionDefectKindDCOMDelta,
            TestReport.optionDefectKindEMFull,
            TestReport.optionDefectKindEMRegression,
            TestReport.optionDefectKindEMDelta,
            TestReport.optionDefectKindCOMFull,
            TestReport.optionDefectKindCOMRegression,
            TestReport.optionDefectKindCOMDelta,
            TestReport.optionDefectKindLDWFull,
            TestReport.optionDefectKindLDWRegression,
            TestReport.optionDefectKindLDWDelta,
            TestReport.optionDefectKindLKSFull,
            TestReport.optionDefectKindLKSRegression,
            TestReport.optionDefectKindLKSDelta,
            TestReport.optionDefectKindRDPFull,
            TestReport.optionDefectKindRDPRegression,
            TestReport.optionDefectKindRDPDelta,
            TestReport.optionDefectKindELKFull,
            TestReport.optionDefectKindELKRegression,
            TestReport.optionDefectKindELKDelta,
            TestReport.optionDefectKindTJAFull,
            TestReport.optionDefectKindTJARegression,
            TestReport.optionDefectKindTJADelta,
            TestReport.optionDefectKindSLAFull,
            TestReport.optionDefectKindSLARegression,
            TestReport.optionDefectKindSLADelta,
            TestReport.optionDefectKindHMAFull,
            TestReport.optionDefectKindHMARegression,
            TestReport.optionDefectKindHMADelta,
            TestReport.optionDefectKindVehicleFull,
            TestReport.optionDefectKindVehicleRegression,
            TestReport.optionDefectKindVehicleDelta,
            TestReport.optionDefectKindSITFull,
            TestReport.optionDefectKindSITRegression,
            TestReport.optionDefectKindSITDelta,
            TestReport.optionDefectKindSRCheckFull,
            TestReport.optionDefectKindSRCheckRegression,
            TestReport.optionDefectKindSRCheckDelta
        }

        For projectIndex = 0 To projectNum - 1
            projectList = projectID(projectIndex)
            With projectList
                .Items.Add("BAIC")
                .Items.Add("BYD")
                .Items.Add("CA")
                .Items.Add("CTCS")
                .Items.Add("CHERY")
                .Items.Add("FOTON")
                .Items.Add("GAC")
                .Items.Add("GEELY")
                .Items.Add("GWM")
                .Items.Add("HMAC")
                .Items.Add("JAC")
                .Items.Add("JMC")
                .Items.Add("Karry")
                .Items.Add("SAIC")
                .Items.Add("SGMW")
                .Items.Add("Sokon")
                .Items.Add("WM")
                .Items.Add("Zotye")
            End With
        Next

        For versionIndex = 0 To versionNum - 1
            versionList = versionID(versionIndex)
            With versionList
                .Items.Add("RC00")
                .Items.Add("RC01")
                .Items.Add("RC02")
                .Items.Add("RC03")
                .Items.Add("RC04")
                .Items.Add("RC05")
                .Items.Add("RC06")
                .Items.Add("RC07")
                .Items.Add("RC08")
                .Items.Add("RC09")
                .Items.Add("RC10")
                .Items.Add("RC11")
                .Items.Add("RC12")
                .Items.Add("RC13")
                .Items.Add("RC14")
                .Items.Add("RC15")
                .Items.Add("RC16")
                .Items.Add("RC17")
                .Items.Add("RC18")
                .Items.Add("RC19")
                .Items.Add("RC20")
            End With
        Next

        For levelOfTestingIndex = 0 To levelOfTestingNum - 1
            levelOfTestingList = levelOfTestingID(levelOfTestingIndex)
            With levelOfTestingList
                .Items.Add("System Test")
            End With
        Next

        For testCoordinatorIndex = 0 To testCoordinatorNum - 1
            testCoordinatorList = testCoordinatorID(testCoordinatorIndex)
            With testCoordinatorList
                .Items.Add("Nguyen Hoang (RBVH/EDA23)")
                .Items.Add("Vuong Dieu Huyen (RBVH/EDA23)")
            End With
        Next

        For ptStateIndex = 0 To ptStateNum - 1
            ptStateList = ptStateID(ptStateIndex)
            With ptStateList
                .Items.Add("New")
                .Items.Add("Committed")
                .Items.Add("Closed")
            End With
        Next

        For defectStateIndex = 0 To defectStateNum - 1
            defectStateList = defectStateID(defectStateIndex)
            With defectStateList
                .Items.Add("New")
                .Items.Add("Confirmed")
                .Items.Add("Closed")
            End With
        Next

        For defectKindIndex = 0 To defectKindNum - 1
            defectKindList = defectKindID(defectKindIndex)
            With defectKindList
                .Items.Add("Requirement")
                .Items.Add("Software")
            End With
        Next
    End Sub
End Class

