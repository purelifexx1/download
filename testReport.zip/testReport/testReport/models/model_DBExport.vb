﻿Public Class model_DBExport
    Public Shared variableDeclaration As New variableDeclaration()
    Public Shared dbDeclaration As New dbDeclaration()
    Public Sub model_ExportDataToDB()
        variableDeclaration.assign_variable()
        dbDeclaration.dbDeclaration()
        ' Save GUI data in database

        dbDeclaration.dbProject.Value = variableDeclaration.project
        dbDeclaration.dbVariant.Value = variableDeclaration.swVariant
        dbDeclaration.dbRelease.Value = variableDeclaration.release
        dbDeclaration.dbVersion.Value = variableDeclaration.version
        dbDeclaration.dbLevelOfTesting.Value = variableDeclaration.testingLevel
        dbDeclaration.dbDocumentOwner.Value = variableDeclaration.documentOwner
        dbDeclaration.dbModifiedBy.Value = variableDeclaration.modifiedBy
        dbDeclaration.dbTestCoordinator.Value = variableDeclaration.testCoordinator
        dbDeclaration.dbDocumentVersion.Value = variableDeclaration.documentVersion
        dbDeclaration.dbStartDate.Value = variableDeclaration.startDate
        dbDeclaration.dbEndDate.Value = variableDeclaration.endDate
        dbDeclaration.dbReleaseDate.Value = variableDeclaration.releaseDate
        dbDeclaration.dbDelivery.Value = variableDeclaration.delivery
        dbDeclaration.dbSource.Value = variableDeclaration.source
        dbDeclaration.dbCoresi.Value = variableDeclaration.coresi

        dbDeclaration.dbDCOM.Value = variableDeclaration.dcom
        dbDeclaration.dbEM.Value = variableDeclaration.em
        dbDeclaration.dbCOM.Value = variableDeclaration.com
        dbDeclaration.dbLDW.Value = variableDeclaration.ldw
        dbDeclaration.dbLKS.Value = variableDeclaration.lks
        dbDeclaration.dbRDP.Value = variableDeclaration.rdp
        dbDeclaration.dbELK.Value = variableDeclaration.elk
        dbDeclaration.dbTJA.Value = variableDeclaration.tja
        dbDeclaration.dbSLA.Value = variableDeclaration.sla
        dbDeclaration.dbHMA.Value = variableDeclaration.hma
        dbDeclaration.dbVehicle.Value = variableDeclaration.vehicle
        dbDeclaration.dbSIT.Value = variableDeclaration.sit
        dbDeclaration.dbSRCheck.Value = variableDeclaration.srCheck

        dbDeclaration.dbDCOMFull.Value = variableDeclaration.dcomFull
        dbDeclaration.dbDCOMRegression.Value = variableDeclaration.dcomRegression
        dbDeclaration.dbDCOMDelta.Value = variableDeclaration.dcomDelta
        dbDeclaration.dbEMFull.Value = variableDeclaration.emFull
        dbDeclaration.dbEMRegression.Value = variableDeclaration.emRegression
        dbDeclaration.dbEMDelta.Value = variableDeclaration.emDelta
        dbDeclaration.dbCOMFull.Value = variableDeclaration.comFull
        dbDeclaration.dbCOMRegression.Value = variableDeclaration.comRegression
        dbDeclaration.dbCOMDelta.Value = variableDeclaration.comDelta
        dbDeclaration.dbLDWFull.Value = variableDeclaration.ldwFull
        dbDeclaration.dbLDWRegression.Value = variableDeclaration.ldwRegression
        dbDeclaration.dbLDWDelta.Value = variableDeclaration.ldwDelta
        dbDeclaration.dbLKSFull.Value = variableDeclaration.lksFull
        dbDeclaration.dbLKSRegression.Value = variableDeclaration.lksRegression
        dbDeclaration.dbLKSDelta.Value = variableDeclaration.lksDelta
        dbDeclaration.dbRDPFull.Value = variableDeclaration.rdpFull
        dbDeclaration.dbRDPRegression.Value = variableDeclaration.rdpRegression
        dbDeclaration.dbRDPDelta.Value = variableDeclaration.rdpDelta
        dbDeclaration.dbELKFull.Value = variableDeclaration.elkFull
        dbDeclaration.dbELKRegression.Value = variableDeclaration.elkRegression
        dbDeclaration.dbELKDelta.Value = variableDeclaration.elkDelta
        dbDeclaration.dbTJAFull.Value = variableDeclaration.tjaFull
        dbDeclaration.dbTJARegression.Value = variableDeclaration.tjaRegression
        dbDeclaration.dbTJADelta.Value = variableDeclaration.tjaDelta
        dbDeclaration.dbSLAFull.Value = variableDeclaration.slaFull
        dbDeclaration.dbSLARegression.Value = variableDeclaration.slaRegression
        dbDeclaration.dbSLADelta.Value = variableDeclaration.slaDelta
        dbDeclaration.dbHMAFull.Value = variableDeclaration.hmaFull
        dbDeclaration.dbHMARegression.Value = variableDeclaration.hmaRegression
        dbDeclaration.dbHMADelta.Value = variableDeclaration.hmaDelta
        dbDeclaration.dbVehicleFull.Value = variableDeclaration.vehicleFull
        dbDeclaration.dbVehicleRegression.Value = variableDeclaration.vehicleRegression
        dbDeclaration.dbVehicleDelta.Value = variableDeclaration.vehicleDelta
        dbDeclaration.dbSITFull.Value = variableDeclaration.sitFull
        dbDeclaration.dbSITRegression.Value = variableDeclaration.sitRegression
        dbDeclaration.dbSITDelta.Value = variableDeclaration.sitDelta
        dbDeclaration.dbSRCheckFull.Value = variableDeclaration.srCheckFull
        dbDeclaration.dbSRCheckRegression.Value = variableDeclaration.srCheckRegression
        dbDeclaration.dbSRCheckDelta.Value = variableDeclaration.srCheckDelta

        dbDeclaration.dbLabtDCOM.Value = variableDeclaration.labtDCOM
        dbDeclaration.dbLabtEM.Value = variableDeclaration.labtEM
        dbDeclaration.dbLabtCOM.Value = variableDeclaration.labtCOM
        dbDeclaration.dbLabtLDW.Value = variableDeclaration.labtLDW
        dbDeclaration.dbLabtLKS.Value = variableDeclaration.labtLKS
        dbDeclaration.dbLabtRDP.Value = variableDeclaration.labtRDP
        dbDeclaration.dbLabtELK.Value = variableDeclaration.labtELK
        dbDeclaration.dbLabtTJA.Value = variableDeclaration.labtTJA
        dbDeclaration.dbLabtSLA.Value = variableDeclaration.labtSLA
        dbDeclaration.dbLabtHMA.Value = variableDeclaration.labtHMA
        dbDeclaration.dbLabtVehicle.Value = variableDeclaration.labtVehicle
        dbDeclaration.dbLabtSIT.Value = variableDeclaration.labtSIT
        dbDeclaration.dbLabtSRCheck.Value = variableDeclaration.labtSRCheck
        dbDeclaration.dbOutputReportLocation.Value = variableDeclaration.ouputReportLocation

        dbDeclaration.dbVersionDCOMFull.Value = variableDeclaration.versionDCOMFull
        dbDeclaration.dbPassedDCOMFull.Value = variableDeclaration.passedDCOMFull
        dbDeclaration.dbFailedDCOMFull.Value = variableDeclaration.failedDCOMFull
        dbDeclaration.dbPtIdDCOMFull.Value = variableDeclaration.ptIdDCOMFull
        dbDeclaration.dbPtStateDCOMFull.Value = variableDeclaration.ptStateDCOMFull
        dbDeclaration.dbDefectIdDCOMFull.Value = variableDeclaration.defectIdDCOMFull
        dbDeclaration.dbDefectStateDCOMFull.Value = variableDeclaration.defectStateDCOMFull
        dbDeclaration.dbDefectKindDCOMFull.Value = variableDeclaration.defectKindDCOMFull

        dbDeclaration.dbVersionDCOMRegression.Value = variableDeclaration.versionDCOMRegression
        dbDeclaration.dbPassedDCOMRegression.Value = variableDeclaration.passedDCOMRegression
        dbDeclaration.dbFailedDCOMRegression.Value = variableDeclaration.failedDCOMRegression
        dbDeclaration.dbPtIdDCOMRegression.Value = variableDeclaration.ptIdDCOMRegression
        dbDeclaration.dbPtStateDCOMRegression.Value = variableDeclaration.ptStateDCOMRegression
        dbDeclaration.dbDefectIdDCOMRegression.Value = variableDeclaration.defectIdDCOMRegression
        dbDeclaration.dbDefectStateDCOMRegression.Value = variableDeclaration.defectStateDCOMRegression
        dbDeclaration.dbDefectKindDCOMRegression.Value = variableDeclaration.defectKindDCOMRegression

        dbDeclaration.dbVersionDCOMDelta.Value = variableDeclaration.versionDCOMDelta
        dbDeclaration.dbPassedDCOMDelta.Value = variableDeclaration.passedDCOMDelta
        dbDeclaration.dbFailedDCOMDelta.Value = variableDeclaration.failedDCOMDelta
        dbDeclaration.dbPtIdDCOMDelta.Value = variableDeclaration.ptIdDCOMDelta
        dbDeclaration.dbPtStateDCOMDelta.Value = variableDeclaration.ptStateDCOMDelta
        dbDeclaration.dbDefectIdDCOMDelta.Value = variableDeclaration.defectIdDCOMDelta
        dbDeclaration.dbDefectStateDCOMDelta.Value = variableDeclaration.defectStateDCOMDelta
        dbDeclaration.dbDefectKindDCOMDelta.Value = variableDeclaration.defectKindDCOMDelta

        dbDeclaration.dbVersionEMFull.Value = variableDeclaration.versionEMFull
        dbDeclaration.dbPassedEMFull.Value = variableDeclaration.passedEMFull
        dbDeclaration.dbFailedEMFull.Value = variableDeclaration.failedEMFull
        dbDeclaration.dbPtIdEMFull.Value = variableDeclaration.ptIdEMFull
        dbDeclaration.dbPtStateEMFull.Value = variableDeclaration.ptStateEMFull
        dbDeclaration.dbDefectIdEMFull.Value = variableDeclaration.defectIdEMFull
        dbDeclaration.dbDefectStateEMFull.Value = variableDeclaration.defectStateEMFull
        dbDeclaration.dbDefectKindEMFull.Value = variableDeclaration.defectKindEMFull

        dbDeclaration.dbVersionEMRegression.Value = variableDeclaration.versionEMRegression
        dbDeclaration.dbPassedEMRegression.Value = variableDeclaration.passedEMRegression
        dbDeclaration.dbFailedEMRegression.Value = variableDeclaration.failedEMRegression
        dbDeclaration.dbPtIdEMRegression.Value = variableDeclaration.ptIdEMRegression
        dbDeclaration.dbPtStateEMRegression.Value = variableDeclaration.ptStateEMRegression
        dbDeclaration.dbDefectIdEMRegression.Value = variableDeclaration.defectIdEMRegression
        dbDeclaration.dbDefectStateEMRegression.Value = variableDeclaration.defectStateEMRegression
        dbDeclaration.dbDefectKindEMRegression.Value = variableDeclaration.defectKindEMRegression

        dbDeclaration.dbVersionEMDelta.Value = variableDeclaration.versionEMDelta
        dbDeclaration.dbPassedEMDelta.Value = variableDeclaration.passedEMDelta
        dbDeclaration.dbFailedEMDelta.Value = variableDeclaration.failedEMDelta
        dbDeclaration.dbPtIdEMDelta.Value = variableDeclaration.ptIdEMDelta
        dbDeclaration.dbPtStateEMDelta.Value = variableDeclaration.ptStateEMDelta
        dbDeclaration.dbDefectIdEMDelta.Value = variableDeclaration.defectIdEMDelta
        dbDeclaration.dbDefectStateEMDelta.Value = variableDeclaration.defectStateEMDelta
        dbDeclaration.dbDefectKindEMDelta.Value = variableDeclaration.defectKindEMDelta

        dbDeclaration.dbVersionCOMFull.Value = variableDeclaration.versionCOMFull
        dbDeclaration.dbPassedCOMFull.Value = variableDeclaration.passedCOMFull
        dbDeclaration.dbFailedCOMFull.Value = variableDeclaration.failedCOMFull
        dbDeclaration.dbPtIdCOMFull.Value = variableDeclaration.ptIdCOMFull
        dbDeclaration.dbPtStateCOMFull.Value = variableDeclaration.ptStateCOMFull
        dbDeclaration.dbDefectIdCOMFull.Value = variableDeclaration.defectIdCOMFull
        dbDeclaration.dbDefectStateCOMFull.Value = variableDeclaration.defectStateCOMFull
        dbDeclaration.dbDefectKindCOMFull.Value = variableDeclaration.defectKindCOMFull

        dbDeclaration.dbVersionCOMRegression.Value = variableDeclaration.versionCOMRegression
        dbDeclaration.dbPassedCOMRegression.Value = variableDeclaration.passedCOMRegression
        dbDeclaration.dbFailedCOMRegression.Value = variableDeclaration.failedCOMRegression
        dbDeclaration.dbPtIdCOMRegression.Value = variableDeclaration.ptIdCOMRegression
        dbDeclaration.dbPtStateCOMRegression.Value = variableDeclaration.ptStateCOMRegression
        dbDeclaration.dbDefectIdCOMRegression.Value = variableDeclaration.defectIdCOMRegression
        dbDeclaration.dbDefectStateCOMRegression.Value = variableDeclaration.defectStateCOMRegression
        dbDeclaration.dbDefectKindCOMRegression.Value = variableDeclaration.defectKindCOMRegression

        dbDeclaration.dbVersionCOMDelta.Value = variableDeclaration.versionCOMDelta
        dbDeclaration.dbPassedCOMDelta.Value = variableDeclaration.passedCOMDelta
        dbDeclaration.dbFailedCOMDelta.Value = variableDeclaration.failedCOMDelta
        dbDeclaration.dbPtIdCOMDelta.Value = variableDeclaration.ptIdCOMDelta
        dbDeclaration.dbPtStateCOMDelta.Value = variableDeclaration.ptStateCOMDelta
        dbDeclaration.dbDefectIdCOMDelta.Value = variableDeclaration.defectIdCOMDelta
        dbDeclaration.dbDefectStateCOMDelta.Value = variableDeclaration.defectStateCOMDelta
        dbDeclaration.dbDefectKindCOMDelta.Value = variableDeclaration.defectKindCOMDelta

        dbDeclaration.dbVersionLDWFull.Value = variableDeclaration.versionLDWFull
        dbDeclaration.dbPassedLDWFull.Value = variableDeclaration.passedLDWFull
        dbDeclaration.dbFailedLDWFull.Value = variableDeclaration.failedLDWFull
        dbDeclaration.dbPtIdLDWFull.Value = variableDeclaration.ptIdLDWFull
        dbDeclaration.dbPtStateLDWFull.Value = variableDeclaration.ptStateLDWFull
        dbDeclaration.dbDefectIdLDWFull.Value = variableDeclaration.defectIdLDWFull
        dbDeclaration.dbDefectStateLDWFull.Value = variableDeclaration.defectStateLDWFull
        dbDeclaration.dbDefectKindLDWFull.Value = variableDeclaration.defectKindLDWFull

        dbDeclaration.dbVersionLDWRegression.Value = variableDeclaration.versionLDWRegression
        dbDeclaration.dbPassedLDWRegression.Value = variableDeclaration.passedLDWRegression
        dbDeclaration.dbFailedLDWRegression.Value = variableDeclaration.failedLDWRegression
        dbDeclaration.dbPtIdLDWRegression.Value = variableDeclaration.ptIdLDWRegression
        dbDeclaration.dbPtStateLDWRegression.Value = variableDeclaration.ptStateLDWRegression
        dbDeclaration.dbDefectIdLDWRegression.Value = variableDeclaration.defectIdLDWRegression
        dbDeclaration.dbDefectStateLDWRegression.Value = variableDeclaration.defectStateLDWRegression
        dbDeclaration.dbDefectKindLDWRegression.Value = variableDeclaration.defectKindLDWRegression

        dbDeclaration.dbVersionLDWDelta.Value = variableDeclaration.versionLDWDelta
        dbDeclaration.dbPassedLDWDelta.Value = variableDeclaration.passedLDWDelta
        dbDeclaration.dbFailedLDWDelta.Value = variableDeclaration.failedLDWDelta
        dbDeclaration.dbPtIdLDWDelta.Value = variableDeclaration.ptIdLDWDelta
        dbDeclaration.dbPtStateLDWDelta.Value = variableDeclaration.ptStateLDWDelta
        dbDeclaration.dbDefectIdLDWDelta.Value = variableDeclaration.defectIdLDWDelta
        dbDeclaration.dbDefectStateLDWDelta.Value = variableDeclaration.defectStateLDWDelta
        dbDeclaration.dbDefectKindLDWDelta.Value = variableDeclaration.defectKindLDWDelta

        dbDeclaration.dbVersionLKSFull.Value = variableDeclaration.versionLKSFull
        dbDeclaration.dbPassedLKSFull.Value = variableDeclaration.passedLKSFull
        dbDeclaration.dbFailedLKSFull.Value = variableDeclaration.failedLKSFull
        dbDeclaration.dbPtIdLKSFull.Value = variableDeclaration.ptIdLKSFull
        dbDeclaration.dbPtStateLKSFull.Value = variableDeclaration.ptStateLKSFull
        dbDeclaration.dbDefectIdLKSFull.Value = variableDeclaration.defectIdLKSFull
        dbDeclaration.dbDefectStateLKSFull.Value = variableDeclaration.defectStateLKSFull
        dbDeclaration.dbDefectKindLKSFull.Value = variableDeclaration.defectKindLKSFull

        dbDeclaration.dbVersionLKSRegression.Value = variableDeclaration.versionLKSRegression
        dbDeclaration.dbPassedLKSRegression.Value = variableDeclaration.passedLKSRegression
        dbDeclaration.dbFailedLKSRegression.Value = variableDeclaration.failedLKSRegression
        dbDeclaration.dbPtIdLKSRegression.Value = variableDeclaration.ptIdLKSRegression
        dbDeclaration.dbPtStateLKSRegression.Value = variableDeclaration.ptStateLKSRegression
        dbDeclaration.dbDefectIdLKSRegression.Value = variableDeclaration.defectIdLKSRegression
        dbDeclaration.dbDefectStateLKSRegression.Value = variableDeclaration.defectStateLKSRegression
        dbDeclaration.dbDefectKindLKSRegression.Value = variableDeclaration.defectKindLKSRegression

        dbDeclaration.dbVersionLKSDelta.Value = variableDeclaration.versionLKSDelta
        dbDeclaration.dbPassedLKSDelta.Value = variableDeclaration.passedLKSDelta
        dbDeclaration.dbFailedLKSDelta.Value = variableDeclaration.failedLKSDelta
        dbDeclaration.dbPtIdLKSDelta.Value = variableDeclaration.ptIdLKSDelta
        dbDeclaration.dbPtStateLKSDelta.Value = variableDeclaration.ptStateLKSDelta
        dbDeclaration.dbDefectIdLKSDelta.Value = variableDeclaration.defectIdLKSDelta
        dbDeclaration.dbDefectStateLKSDelta.Value = variableDeclaration.defectStateLKSDelta
        dbDeclaration.dbDefectKindLKSDelta.Value = variableDeclaration.defectKindLKSDelta

        dbDeclaration.dbVersionRDPFull.Value = variableDeclaration.versionRDPFull
        dbDeclaration.dbPassedRDPFull.Value = variableDeclaration.passedRDPFull
        dbDeclaration.dbFailedRDPFull.Value = variableDeclaration.failedRDPFull
        dbDeclaration.dbPtIdRDPFull.Value = variableDeclaration.ptIdRDPFull
        dbDeclaration.dbPtStateRDPFull.Value = variableDeclaration.ptStateRDPFull
        dbDeclaration.dbDefectIdRDPFull.Value = variableDeclaration.defectIdRDPFull
        dbDeclaration.dbDefectStateRDPFull.Value = variableDeclaration.defectStateRDPFull
        dbDeclaration.dbDefectKindRDPFull.Value = variableDeclaration.defectKindRDPFull

        dbDeclaration.dbVersionRDPRegression.Value = variableDeclaration.versionRDPRegression
        dbDeclaration.dbPassedRDPRegression.Value = variableDeclaration.passedRDPRegression
        dbDeclaration.dbFailedRDPRegression.Value = variableDeclaration.failedRDPRegression
        dbDeclaration.dbPtIdRDPRegression.Value = variableDeclaration.ptIdRDPRegression
        dbDeclaration.dbPtStateRDPRegression.Value = variableDeclaration.ptStateRDPRegression
        dbDeclaration.dbDefectIdRDPRegression.Value = variableDeclaration.defectIdRDPRegression
        dbDeclaration.dbDefectStateRDPRegression.Value = variableDeclaration.defectStateRDPRegression
        dbDeclaration.dbDefectKindRDPRegression.Value = variableDeclaration.defectKindRDPRegression

        dbDeclaration.dbVersionRDPDelta.Value = variableDeclaration.versionRDPDelta
        dbDeclaration.dbPassedRDPDelta.Value = variableDeclaration.passedRDPDelta
        dbDeclaration.dbFailedRDPDelta.Value = variableDeclaration.failedRDPDelta
        dbDeclaration.dbPtIdRDPDelta.Value = variableDeclaration.ptIdRDPDelta
        dbDeclaration.dbPtStateRDPDelta.Value = variableDeclaration.ptStateRDPDelta
        dbDeclaration.dbDefectIdRDPDelta.Value = variableDeclaration.defectIdRDPDelta
        dbDeclaration.dbDefectStateRDPDelta.Value = variableDeclaration.defectStateRDPDelta
        dbDeclaration.dbDefectKindRDPDelta.Value = variableDeclaration.defectKindRDPDelta

        dbDeclaration.dbVersionELKFull.Value = variableDeclaration.versionELKFull
        dbDeclaration.dbPassedELKFull.Value = variableDeclaration.passedELKFull
        dbDeclaration.dbFailedELKFull.Value = variableDeclaration.failedELKFull
        dbDeclaration.dbPtIdELKFull.Value = variableDeclaration.ptIdELKFull
        dbDeclaration.dbPtStateELKFull.Value = variableDeclaration.ptStateELKFull
        dbDeclaration.dbDefectIdELKFull.Value = variableDeclaration.defectIdELKFull
        dbDeclaration.dbDefectStateELKFull.Value = variableDeclaration.defectStateELKFull
        dbDeclaration.dbDefectKindELKFull.Value = variableDeclaration.defectKindELKFull

        dbDeclaration.dbVersionELKRegression.Value = variableDeclaration.versionELKRegression
        dbDeclaration.dbPassedELKRegression.Value = variableDeclaration.passedELKRegression
        dbDeclaration.dbFailedELKRegression.Value = variableDeclaration.failedELKRegression
        dbDeclaration.dbPtIdELKRegression.Value = variableDeclaration.ptIdELKRegression
        dbDeclaration.dbPtStateELKRegression.Value = variableDeclaration.ptStateELKRegression
        dbDeclaration.dbDefectIdELKRegression.Value = variableDeclaration.defectIdELKRegression
        dbDeclaration.dbDefectStateELKRegression.Value = variableDeclaration.defectStateELKRegression
        dbDeclaration.dbDefectKindELKRegression.Value = variableDeclaration.defectKindELKRegression

        dbDeclaration.dbVersionELKDelta.Value = variableDeclaration.versionELKDelta
        dbDeclaration.dbPassedELKDelta.Value = variableDeclaration.passedELKDelta
        dbDeclaration.dbFailedELKDelta.Value = variableDeclaration.failedELKDelta
        dbDeclaration.dbPtIdELKDelta.Value = variableDeclaration.ptIdELKDelta
        dbDeclaration.dbPtStateELKDelta.Value = variableDeclaration.ptStateELKDelta
        dbDeclaration.dbDefectIdELKDelta.Value = variableDeclaration.defectIdELKDelta
        dbDeclaration.dbDefectStateELKDelta.Value = variableDeclaration.defectStateELKDelta
        dbDeclaration.dbDefectKindELKDelta.Value = variableDeclaration.defectKindELKDelta

        dbDeclaration.dbVersionTJAFull.Value = variableDeclaration.versionTJAFull
        dbDeclaration.dbPassedTJAFull.Value = variableDeclaration.passedTJAFull
        dbDeclaration.dbFailedTJAFull.Value = variableDeclaration.failedTJAFull
        dbDeclaration.dbPtIdTJAFull.Value = variableDeclaration.ptIdTJAFull
        dbDeclaration.dbPtStateTJAFull.Value = variableDeclaration.ptStateTJAFull
        dbDeclaration.dbDefectIdTJAFull.Value = variableDeclaration.defectIdTJAFull
        dbDeclaration.dbDefectStateTJAFull.Value = variableDeclaration.defectStateTJAFull
        dbDeclaration.dbDefectKindTJAFull.Value = variableDeclaration.defectKindTJAFull

        dbDeclaration.dbVersionTJARegression.Value = variableDeclaration.versionTJARegression
        dbDeclaration.dbPassedTJARegression.Value = variableDeclaration.passedTJARegression
        dbDeclaration.dbFailedTJARegression.Value = variableDeclaration.failedTJARegression
        dbDeclaration.dbPtIdTJARegression.Value = variableDeclaration.ptIdTJARegression
        dbDeclaration.dbPtStateTJARegression.Value = variableDeclaration.ptStateTJARegression
        dbDeclaration.dbDefectIdTJARegression.Value = variableDeclaration.defectIdTJARegression
        dbDeclaration.dbDefectStateTJARegression.Value = variableDeclaration.defectStateTJARegression
        dbDeclaration.dbDefectKindTJARegression.Value = variableDeclaration.defectKindTJARegression

        dbDeclaration.dbVersionTJADelta.Value = variableDeclaration.versionTJADelta
        dbDeclaration.dbPassedTJADelta.Value = variableDeclaration.passedTJADelta
        dbDeclaration.dbFailedTJADelta.Value = variableDeclaration.failedTJADelta
        dbDeclaration.dbPtIdTJADelta.Value = variableDeclaration.ptIdTJADelta
        dbDeclaration.dbPtStateTJADelta.Value = variableDeclaration.ptStateTJADelta
        dbDeclaration.dbDefectIdTJADelta.Value = variableDeclaration.defectIdTJADelta
        dbDeclaration.dbDefectStateTJADelta.Value = variableDeclaration.defectStateTJADelta
        dbDeclaration.dbDefectKindTJADelta.Value = variableDeclaration.defectKindTJADelta

        dbDeclaration.dbVersionSLAFull.Value = variableDeclaration.versionSLAFull
        dbDeclaration.dbPassedSLAFull.Value = variableDeclaration.passedSLAFull
        dbDeclaration.dbFailedSLAFull.Value = variableDeclaration.failedSLAFull
        dbDeclaration.dbPtIdSLAFull.Value = variableDeclaration.ptIdSLAFull
        dbDeclaration.dbPtStateSLAFull.Value = variableDeclaration.ptStateSLAFull
        dbDeclaration.dbDefectIdSLAFull.Value = variableDeclaration.defectIdSLAFull
        dbDeclaration.dbDefectStateSLAFull.Value = variableDeclaration.defectStateSLAFull
        dbDeclaration.dbDefectKindSLAFull.Value = variableDeclaration.defectKindSLAFull

        dbDeclaration.dbVersionSLARegression.Value = variableDeclaration.versionSLARegression
        dbDeclaration.dbPassedSLARegression.Value = variableDeclaration.passedSLARegression
        dbDeclaration.dbFailedSLARegression.Value = variableDeclaration.failedSLARegression
        dbDeclaration.dbPtIdSLARegression.Value = variableDeclaration.ptIdSLARegression
        dbDeclaration.dbPtStateSLARegression.Value = variableDeclaration.ptStateSLARegression
        dbDeclaration.dbDefectIdSLARegression.Value = variableDeclaration.defectIdSLARegression
        dbDeclaration.dbDefectStateSLARegression.Value = variableDeclaration.defectStateSLARegression
        dbDeclaration.dbDefectKindSLARegression.Value = variableDeclaration.defectKindSLARegression

        dbDeclaration.dbVersionSLADelta.Value = variableDeclaration.versionSLADelta
        dbDeclaration.dbPassedSLADelta.Value = variableDeclaration.passedSLADelta
        dbDeclaration.dbFailedSLADelta.Value = variableDeclaration.failedSLADelta
        dbDeclaration.dbPtIdSLADelta.Value = variableDeclaration.ptIdSLADelta
        dbDeclaration.dbPtStateSLADelta.Value = variableDeclaration.ptStateSLADelta
        dbDeclaration.dbDefectIdSLADelta.Value = variableDeclaration.defectIdSLADelta
        dbDeclaration.dbDefectStateSLADelta.Value = variableDeclaration.defectStateSLADelta
        dbDeclaration.dbDefectKindSLADelta.Value = variableDeclaration.defectKindSLADelta

        dbDeclaration.dbVersionHMAFull.Value = variableDeclaration.versionHMAFull
        dbDeclaration.dbPassedHMAFull.Value = variableDeclaration.passedHMAFull
        dbDeclaration.dbFailedHMAFull.Value = variableDeclaration.failedHMAFull
        dbDeclaration.dbPtIdHMAFull.Value = variableDeclaration.ptIdHMAFull
        dbDeclaration.dbPtStateHMAFull.Value = variableDeclaration.ptStateHMAFull
        dbDeclaration.dbDefectIdHMAFull.Value = variableDeclaration.defectIdHMAFull
        dbDeclaration.dbDefectStateHMAFull.Value = variableDeclaration.defectStateHMAFull
        dbDeclaration.dbDefectKindHMAFull.Value = variableDeclaration.defectKindHMAFull

        dbDeclaration.dbVersionHMARegression.Value = variableDeclaration.versionHMARegression
        dbDeclaration.dbPassedHMARegression.Value = variableDeclaration.passedHMARegression
        dbDeclaration.dbFailedHMARegression.Value = variableDeclaration.failedHMARegression
        dbDeclaration.dbPtIdHMARegression.Value = variableDeclaration.ptIdHMARegression
        dbDeclaration.dbPtStateHMARegression.Value = variableDeclaration.ptStateHMARegression
        dbDeclaration.dbDefectIdHMARegression.Value = variableDeclaration.defectIdHMARegression
        dbDeclaration.dbDefectStateHMARegression.Value = variableDeclaration.defectStateHMARegression
        dbDeclaration.dbDefectKindHMARegression.Value = variableDeclaration.defectKindHMARegression

        dbDeclaration.dbVersionHMADelta.Value = variableDeclaration.versionHMADelta
        dbDeclaration.dbPassedHMADelta.Value = variableDeclaration.passedHMADelta
        dbDeclaration.dbFailedHMADelta.Value = variableDeclaration.failedHMADelta
        dbDeclaration.dbPtIdHMADelta.Value = variableDeclaration.ptIdHMADelta
        dbDeclaration.dbPtStateHMADelta.Value = variableDeclaration.ptStateHMADelta
        dbDeclaration.dbDefectIdHMADelta.Value = variableDeclaration.defectIdHMADelta
        dbDeclaration.dbDefectStateHMADelta.Value = variableDeclaration.defectStateHMADelta
        dbDeclaration.dbDefectKindHMADelta.Value = variableDeclaration.defectKindHMADelta

        dbDeclaration.dbVersionVehicleFull.Value = variableDeclaration.versionVehicleFull
        dbDeclaration.dbPassedVehicleFull.Value = variableDeclaration.passedVehicleFull
        dbDeclaration.dbFailedVehicleFull.Value = variableDeclaration.failedVehicleFull
        dbDeclaration.dbPtIdVehicleFull.Value = variableDeclaration.ptIdVehicleFull
        dbDeclaration.dbPtStateVehicleFull.Value = variableDeclaration.ptStateVehicleFull
        dbDeclaration.dbDefectIdVehicleFull.Value = variableDeclaration.defectIdVehicleFull
        dbDeclaration.dbDefectStateVehicleFull.Value = variableDeclaration.defectStateVehicleFull
        dbDeclaration.dbDefectKindVehicleFull.Value = variableDeclaration.defectKindVehicleFull

        dbDeclaration.dbVersionVehicleRegression.Value = variableDeclaration.versionVehicleRegression
        dbDeclaration.dbPassedVehicleRegression.Value = variableDeclaration.passedVehicleRegression
        dbDeclaration.dbFailedVehicleRegression.Value = variableDeclaration.failedVehicleRegression
        dbDeclaration.dbPtIdVehicleRegression.Value = variableDeclaration.ptIdVehicleRegression
        dbDeclaration.dbPtStateVehicleRegression.Value = variableDeclaration.ptStateVehicleRegression
        dbDeclaration.dbDefectIdVehicleRegression.Value = variableDeclaration.defectIdVehicleRegression
        dbDeclaration.dbDefectStateVehicleRegression.Value = variableDeclaration.defectStateVehicleRegression
        dbDeclaration.dbDefectKindVehicleRegression.Value = variableDeclaration.defectKindVehicleRegression

        dbDeclaration.dbVersionVehicleDelta.Value = variableDeclaration.versionVehicleDelta
        dbDeclaration.dbPassedVehicleDelta.Value = variableDeclaration.passedVehicleDelta
        dbDeclaration.dbFailedVehicleDelta.Value = variableDeclaration.failedVehicleDelta
        dbDeclaration.dbPtIdVehicleDelta.Value = variableDeclaration.ptIdVehicleDelta
        dbDeclaration.dbPtStateVehicleDelta.Value = variableDeclaration.ptStateVehicleDelta
        dbDeclaration.dbDefectIdVehicleDelta.Value = variableDeclaration.defectIdVehicleDelta
        dbDeclaration.dbDefectStateVehicleDelta.Value = variableDeclaration.defectStateVehicleDelta
        dbDeclaration.dbDefectKindVehicleDelta.Value = variableDeclaration.defectKindVehicleDelta

        dbDeclaration.dbVersionSITFull.Value = variableDeclaration.versionSITFull
        dbDeclaration.dbPassedSITFull.Value = variableDeclaration.passedSITFull
        dbDeclaration.dbFailedSITFull.Value = variableDeclaration.failedSITFull
        dbDeclaration.dbPtIdSITFull.Value = variableDeclaration.ptIdSITFull
        dbDeclaration.dbPtStateSITFull.Value = variableDeclaration.ptStateSITFull
        dbDeclaration.dbDefectIdSITFull.Value = variableDeclaration.defectIdSITFull
        dbDeclaration.dbDefectStateSITFull.Value = variableDeclaration.defectStateSITFull
        dbDeclaration.dbDefectKindSITFull.Value = variableDeclaration.defectKindSITFull

        dbDeclaration.dbVersionSITRegression.Value = variableDeclaration.versionSITRegression
        dbDeclaration.dbPassedSITRegression.Value = variableDeclaration.passedSITRegression
        dbDeclaration.dbFailedSITRegression.Value = variableDeclaration.failedSITRegression
        dbDeclaration.dbPtIdSITRegression.Value = variableDeclaration.ptIdSITRegression
        dbDeclaration.dbPtStateSITRegression.Value = variableDeclaration.ptStateSITRegression
        dbDeclaration.dbDefectIdSITRegression.Value = variableDeclaration.defectIdSITRegression
        dbDeclaration.dbDefectStateSITRegression.Value = variableDeclaration.defectStateSITRegression
        dbDeclaration.dbDefectKindSITRegression.Value = variableDeclaration.defectKindSITRegression

        dbDeclaration.dbVersionSITDelta.Value = variableDeclaration.versionSITDelta
        dbDeclaration.dbPassedSITDelta.Value = variableDeclaration.passedSITDelta
        dbDeclaration.dbFailedSITDelta.Value = variableDeclaration.failedSITDelta
        dbDeclaration.dbPtIdSITDelta.Value = variableDeclaration.ptIdSITDelta
        dbDeclaration.dbPtStateSITDelta.Value = variableDeclaration.ptStateSITDelta
        dbDeclaration.dbDefectIdSITDelta.Value = variableDeclaration.defectIdSITDelta
        dbDeclaration.dbDefectStateSITDelta.Value = variableDeclaration.defectStateSITDelta
        dbDeclaration.dbDefectKindSITDelta.Value = variableDeclaration.defectKindSITDelta

        dbDeclaration.dbVersionSRCheckFull.Value = variableDeclaration.versionSRCheckFull
        dbDeclaration.dbPassedSRCheckFull.Value = variableDeclaration.passedSRCheckFull
        dbDeclaration.dbFailedSRCheckFull.Value = variableDeclaration.failedSRCheckFull
        dbDeclaration.dbPtIdSRCheckFull.Value = variableDeclaration.ptIdSRCheckFull
        dbDeclaration.dbPtStateSRCheckFull.Value = variableDeclaration.ptStateSRCheckFull
        dbDeclaration.dbDefectIdSRCheckFull.Value = variableDeclaration.defectIdSRCheckFull
        dbDeclaration.dbDefectStateSRCheckFull.Value = variableDeclaration.defectStateSRCheckFull
        dbDeclaration.dbDefectKindSRCheckFull.Value = variableDeclaration.defectKindSRCheckFull

        dbDeclaration.dbVersionSRCheckRegression.Value = variableDeclaration.versionSRCheckRegression
        dbDeclaration.dbPassedSRCheckRegression.Value = variableDeclaration.passedSRCheckRegression
        dbDeclaration.dbFailedSRCheckRegression.Value = variableDeclaration.failedSRCheckRegression
        dbDeclaration.dbPtIdSRCheckRegression.Value = variableDeclaration.ptIdSRCheckRegression
        dbDeclaration.dbPtStateSRCheckRegression.Value = variableDeclaration.ptStateSRCheckRegression
        dbDeclaration.dbDefectIdSRCheckRegression.Value = variableDeclaration.defectIdSRCheckRegression
        dbDeclaration.dbDefectStateSRCheckRegression.Value = variableDeclaration.defectStateSRCheckRegression
        dbDeclaration.dbDefectKindSRCheckRegression.Value = variableDeclaration.defectKindSRCheckRegression

        dbDeclaration.dbVersionSRCheckDelta.Value = variableDeclaration.versionSRCheckDelta
        dbDeclaration.dbPassedSRCheckDelta.Value = variableDeclaration.passedSRCheckDelta
        dbDeclaration.dbFailedSRCheckDelta.Value = variableDeclaration.failedSRCheckDelta
        dbDeclaration.dbPtIdSRCheckDelta.Value = variableDeclaration.ptIdSRCheckDelta
        dbDeclaration.dbPtStateSRCheckDelta.Value = variableDeclaration.ptStateSRCheckDelta
        dbDeclaration.dbDefectIdSRCheckDelta.Value = variableDeclaration.defectIdSRCheckDelta
        dbDeclaration.dbDefectStateSRCheckDelta.Value = variableDeclaration.defectStateSRCheckDelta
        dbDeclaration.dbDefectKindSRCheckDelta.Value = variableDeclaration.defectKindSRCheckDelta

        dbDeclaration.dbWB.SaveAs(dbDeclaration.dbPath)
        dbDeclaration.dbWB.Close()
        dbDeclaration.msexcelApp.Quit()
    End Sub
End Class
